import path from 'path';
import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';
// FIX: Import fileURLToPath to resolve paths in an ESM-compatible way.
import { fileURLToPath } from 'url';

export default defineConfig(({ mode }) => {
    const env = loadEnv(mode, '.', '');
    return {
      server: {
        port: 3000,
        host: '0.0.0.0',
        hmr: {
          overlay: false
        },
      },
      plugins: [react()],
      define: {
        'process.env.API_KEY': JSON.stringify(env.GEMINI_API_KEY),
        'process.env.GEMINI_API_KEY': JSON.stringify(env.GEMINI_API_KEY)
      },
      resolve: {
        alias: {
          // FIX: __dirname is not available in Vite's ESM context. Use process.cwd() instead to get the project root directory.
          // FIX: Replaced process.cwd() with an ESM-compatible method using import.meta.url to resolve the TypeScript error "Property 'cwd' does not exist on type 'Process'".
          '@': path.resolve(fileURLToPath(new URL('.', import.meta.url)), '.'),
        }
      }
    };
});