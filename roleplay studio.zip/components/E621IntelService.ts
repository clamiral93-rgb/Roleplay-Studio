const INTEL_CORE_KEY = 'wormgpt_e621_intel_core';

const getIntelCore = (): Record<string, string> => {
    try {
        const core = localStorage.getItem(INTEL_CORE_KEY);
        return core ? JSON.parse(core) : {};
    } catch (e) {
        console.error("Failed to parse Intel Core from localStorage:", e);
        return {};
    }
};

const saveIntelCore = (core: Record<string, string>): void => {
    try {
        localStorage.setItem(INTEL_CORE_KEY, JSON.stringify(core));
    } catch (e) {
        console.error("Failed to save Intel Core to localStorage:", e);
    }
};

export const saveTagIntel = (tagName: string, content: string): void => {
    const core = getIntelCore();
    core[tagName] = content;
    saveIntelCore(core);
};

export const getTagIntel = (tagName: string): string | null => {
    const core = getIntelCore();
    return core[tagName] || null;
};

export const deleteTagIntel = (tagName: string): void => {
    const core = getIntelCore();
    delete core[tagName];
    saveIntelCore(core);
};

export const getAllSavedIntel = (): { name: string, content: string }[] => {
    const core = getIntelCore();
    return Object.entries(core).map(([name, content]) => ({ name, content })).sort((a, b) => a.name.localeCompare(b.name));
};

export const isTagInCore = (tagName: string): boolean => {
    const core = getIntelCore();
    return tagName in core;
};
