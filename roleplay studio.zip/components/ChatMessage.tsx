import React, { useState, useEffect, useRef, memo } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { Message, Role, MultiResponse, MessagePart } from '../types';
import { WormIcon, UserIcon, CopyIcon, MoreOptionsIcon, CheckIcon, DeleteIcon, EditIcon, ContinueIcon, ExecuteIcon, RegenerateIcon, CloseIcon, InfoIcon, MicIcon, PencilOffIcon, SpinnerIcon } from './Icons';
import { getLargeData } from './DBService';

interface ChatMessageProps {
  message: Message;
  isLoading?: boolean;
  isLastMessage: boolean;
  isEditing: boolean;
  editMode?: 'restart' | 'no-restart';
  userAvatar?: string | null;
  modelAvatar?: string | null;
  onDelete: (messageId: string) => void;
  onStartEdit: (messageId: string, mode: 'restart' | 'no-restart') => void;
  onSaveEdit: (messageId: string, newText: string) => void;
  onCancelEdit: () => void;
  onContinue: () => void;
  onRegenerate: (messageId: string) => void;
  onImageClick: (src: string) => void;
  onExecute: (message: Message) => void;
  onSelectBestResponse: (messageId: string, responseId: string) => void;
  onShowInfo: (messageId: string) => void;
  onSpeak: (text: string) => void;
}

const CodeBlock = ({ node, inline, className, children, ...props }: any) => {
    const [copied, setCopied] = useState(false);
    const match = /language-(\w+)/.exec(className || '');
    const codeText = String(children).replace(/\n$/, '');

    const handleCopy = () => {
        navigator.clipboard.writeText(codeText);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
    };

    return !inline && match ? (
        <div className="bg-black rounded-lg my-2 relative max-w-full overflow-hidden border border-gray-700">
            <div className="flex justify-between items-center px-4 py-2 bg-gray-800 rounded-t-lg sticky top-0 z-10 w-full border-b border-gray-700">
                <span className="text-gray-400 text-xs font-mono">{match[1]}</span>
                <button onClick={handleCopy} className="flex items-center text-xs text-gray-400 hover:text-white bg-gray-700 px-2 py-1 rounded">
                    {copied ? <CheckIcon className="w-3 h-3 mr-1" /> : <CopyIcon className="w-3 h-3 mr-1" />}
                    {copied ? 'Copied' : 'Copy'}
                </button>
            </div>
            <div className="relative">
                <pre className="p-4 overflow-auto max-h-96 text-sm custom-scrollbar">
                    <code className={className} {...props}>
                        {children}
                    </code>
                </pre>
            </div>
        </div>
    ) : (
        <code className="bg-gray-700 rounded px-1 py-0.5 text-sm break-words font-mono text-purple-300" {...props}>
            {children}
        </code>
    );
};

const InlineDataPart: React.FC<{ part: MessagePart, onImageClick: (src: string) => void }> = ({ part, onImageClick }) => {
    const [dataUrl, setDataUrl] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        let isMounted = true;
        const loadData = async () => {
            setIsLoading(true);
            if (part.inlineData?.data) { // Handle legacy data still in localStorage
                setDataUrl(`data:${part.inlineData.mimeType};base64,${part.inlineData.data}`);
            } else if (part.inlineData?.dbKey !== undefined) {
                try {
                    const base64Data = await getLargeData(part.inlineData.dbKey);
                    if (isMounted && base64Data) {
                        setDataUrl(`data:${part.inlineData.mimeType};base64,${base64Data}`);
                    }
                } catch (e) {
                    console.error("Failed to load data from IndexedDB", e);
                }
            }
            if (isMounted) setIsLoading(false);
        };

        loadData();
        return () => { isMounted = false; };
    }, [part]);

    if (isLoading) {
        return <div className="max-w-xs mt-2 rounded-lg bg-gray-800 animate-pulse h-32 w-32 flex items-center justify-center"><SpinnerIcon /></div>;
    }
    
    if (!dataUrl) return null;

    if (part.inlineData?.mimeType.startsWith('image/')) {
        return (
            <button onClick={() => onImageClick(dataUrl)} className="block cursor-pointer hover:opacity-90 transition-opacity focus:outline-none">
                <img src={dataUrl} alt="uploaded content" className="max-w-xs rounded-lg mt-2 border border-gray-700 shadow-md"/>
            </button>
        );
    }
    
    return null;
}

const GalleryImagePart: React.FC<{ 
    part: MessagePart, 
    onImageClick: (src: string) => void,
    isOverlay?: boolean,
    overlayText?: string,
    onOverlayClick?: () => void
}> = ({ part, onImageClick, isOverlay, overlayText, onOverlayClick }) => {
    const [dataUrl, setDataUrl] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        let isMounted = true;
        const loadData = async () => {
            setIsLoading(true);
            if (part.inlineData?.data) {
                setDataUrl(`data:${part.inlineData.mimeType};base64,${part.inlineData.data}`);
            } else if (part.inlineData?.dbKey !== undefined) {
                try {
                     const base64Data = await getLargeData(part.inlineData.dbKey);
                     if (isMounted && base64Data) {
                         setDataUrl(`data:${part.inlineData.mimeType};base64,${base64Data}`);
                     }
                } catch (e) {
                     console.error("Failed to load data from IndexedDB", e);
                }
            }
            if (isMounted) setIsLoading(false);
        };

        loadData();
        return () => { isMounted = false; };
    }, [part]);

    if (isLoading) {
        return (
            <div className="w-full h-full flex items-center justify-center bg-gray-800 animate-pulse min-h-[96px]">
                <SpinnerIcon className="w-4 h-4 text-gray-500 animate-spin" />
            </div>
        );
    }
    
    if (!dataUrl) return null;

    if (isOverlay) {
        return (
            <button className="relative w-full h-full cursor-pointer overflow-hidden focus:outline-none border-0 p-0 m-0" onClick={onOverlayClick}>
                <img src={dataUrl} alt="uploaded content" className="w-full h-full object-cover filter brightness-[0.4] transition-all duration-300 hover:scale-105"/>
                <div className="absolute inset-0 flex items-center justify-center bg-black/20">
                    <span className="text-white text-lg font-bold font-sans tracking-wide">{overlayText}</span>
                </div>
            </button>
        );
    }

    return (
        <button onClick={() => onImageClick(dataUrl)} className="w-full h-full cursor-pointer overflow-hidden focus:outline-none border-0 p-0 m-0">
            <img src={dataUrl} alt="uploaded content" className="w-full h-full object-cover transition-transform duration-300 hover:scale-105"/>
        </button>
    );
};

const ImageGallery: React.FC<{ parts: MessagePart[], onImageClick: (src: string) => void }> = ({ parts, onImageClick }) => {
    const [isExpanded, setIsExpanded] = useState(false);
    
    if (parts.length === 1) {
        return <InlineDataPart part={parts[0]} onImageClick={onImageClick} />;
    }

    const limit = 4;
    const hasMore = parts.length > limit;
    
    // We only display the first 4 if not expanded
    const visibleParts = isExpanded ? parts : parts.slice(0, limit);
    
    return (
        <div className="mt-2 w-full max-w-lg">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {visibleParts.map((part, index) => {
                    const isLastVisibleInCollapsed = !isExpanded && hasMore && index === limit - 1;
                    return (
                        <div key={index} className="relative aspect-square overflow-hidden rounded-lg border border-gray-700 bg-gray-900 group">
                            <GalleryImagePart 
                                part={part} 
                                onImageClick={onImageClick} 
                                isOverlay={isLastVisibleInCollapsed}
                                overlayText={`+${parts.length - limit + 1}`}
                                onOverlayClick={() => setIsExpanded(true)}
                            />
                        </div>
                    );
                })}
            </div>
            {hasMore && (
                <button 
                    onClick={() => setIsExpanded(!isExpanded)} 
                    className="mt-2 text-xs text-purple-400 hover:text-purple-300 font-medium transition-colors focus:outline-none"
                >
                    {isExpanded ? 'Collapse images' : `Show all ${parts.length} images`}
                </button>
            )}
        </div>
    );
};

const SingleMessageContent: React.FC<{ parts: Message['parts'], onImageClick: (src: string) => void, isLoading?: boolean }> = ({ parts, onImageClick, isLoading }) => {
    const blinkingCursor = isLoading ? (
        <span className="inline-block w-0.5 h-5 animate-pulse ml-1" style={{backgroundColor: 'var(--color-text-primary)'}}></span>
    ) : null;
  
    const groupedElements: React.ReactNode[] = [];
    let currentImageGroup: MessagePart[] = [];

    const flushImageGroup = (key: string | number) => {
        if (currentImageGroup.length > 0) {
            groupedElements.push(
                <ImageGallery key={`gallery-${key}`} parts={currentImageGroup} onImageClick={onImageClick} />
            );
            currentImageGroup = [];
        }
    };

    parts.forEach((part, index) => {
        if (part.inlineData?.mimeType.startsWith('image/')) {
            currentImageGroup.push(part);
        } else {
            flushImageGroup(index);
            if (part.text) {
                const cleanText = part.text.replace(/:::SYSTEM_CONTEXT:::[\s\S]*?:::END_SYSTEM_CONTEXT:::/g, '');
                if (cleanText || parts.length === 1) {
                    groupedElements.push(
                        <div key={index} className="prose prose-invert prose-sm max-w-none break-words overflow-x-auto">
                            <ReactMarkdown
                                remarkPlugins={[remarkGfm]}
                                components={{ 
                                    code: CodeBlock,
                                    a: ({node: _, ...props}) => <a {...props} target="_blank" rel="noopener noreferrer" />,
                                }}
                            >
                                {cleanText}
                            </ReactMarkdown>
                        </div>
                    );
                }
            } else if (part.inlineData) {
                // For any other non-image inlineData
                groupedElements.push(<InlineDataPart key={index} part={part} onImageClick={onImageClick} />);
            }
        }
    });
    flushImageGroup('end');

    return (
        <>
            <div className="flex flex-col min-w-0 overflow-hidden space-y-2">
              {groupedElements}
            </div>
            {isLoading && parts.every(p => !p.text && !p.inlineData) && blinkingCursor}
            {parts.some(p => p.text) && isLoading && blinkingCursor}
        </>
    )
}

const ChatMessageInternal: React.FC<ChatMessageProps> = ({ 
    message, 
    isLoading = false, 
    isLastMessage,
    isEditing,
    editMode = 'restart',
    userAvatar,
    modelAvatar,
    onDelete, 
    onStartEdit,
    onSaveEdit,
    onCancelEdit,
    onContinue, 
    onRegenerate,
    onImageClick, 
    onExecute,
    onSelectBestResponse,
    onShowInfo,
    onSpeak,
}) => {
  const isModel = message.role === Role.MODEL;
  const [menuOpen, setMenuOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
      const handleClickOutside = (event: MouseEvent) => {
          if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
              setMenuOpen(false);
          }
      };
      if (menuOpen) document.addEventListener('mousedown', handleClickOutside);
      return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [menuOpen]);
  
  const getTextContent = () => message.parts.map(p => p.text || '').join('\n')
        .replace(/:::SYSTEM_CONTEXT:::[\s\S]*?:::END_SYSTEM_CONTEXT:::/g, '');
  
  const [editedText, setEditedText] = useState(getTextContent());
  const editInputRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    setEditedText(getTextContent());
  }, [message]);

  useEffect(() => {
    if (isEditing && editInputRef.current) {
      editInputRef.current.focus();
      editInputRef.current.style.height = 'auto';
      editInputRef.current.style.height = `${editInputRef.current.scrollHeight}px`;
    }
  }, [isEditing]);

  const hasExecutableCode = isModel && /```html|```css|```javascript|```js/.test(getTextContent());

  const handleCopy = () => {
      let textToCopy = getTextContent();
      if (message.multiResponses) {
          textToCopy = message.multiResponses.map(r => `--- Response from ${r.model} ---\n${r.parts.map(p => p.text).join('\n')}`).join('\n\n');
      }
      navigator.clipboard.writeText(textToCopy);
      setMenuOpen(false);
  };
  
  const handleDelete = () => { onDelete(message.id); setMenuOpen(false); };
  const handleModifyRestart = () => { onStartEdit(message.id, 'restart'); setMenuOpen(false); };
  const handleModifyNoRestart = () => { onStartEdit(message.id, 'no-restart'); setMenuOpen(false); };
  const handleSave = () => { onSaveEdit(message.id, editedText); }
  const handleContinue = () => { onContinue(); setMenuOpen(false); }
  const handleExecute = () => { onExecute(message); setMenuOpen(false); }
  const handleRegenerate = () => { onRegenerate(message.id); setMenuOpen(false); }
  const handleShowInfo = () => { onShowInfo(message.id); setMenuOpen(false); };
  const handleSpeak = () => { onSpeak(getTextContent()); setMenuOpen(false); };

  const renderAvatar = () => {
      if (isModel) {
          if (modelAvatar) {
              return <img src={modelAvatar} alt="AI" className="w-8 h-8 rounded-full object-cover shadow-lg" />;
          }
          return (
              <div className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 shadow-lg" style={{backgroundColor: 'var(--color-accent-secondary)'}}>
                  <WormIcon className="w-5 h-5 text-white" />
              </div>
          );
      } else {
          if (userAvatar) {
              return <img src={userAvatar} alt="User" className="w-8 h-8 rounded-full object-cover shadow-lg" />;
          }
          return (
               <div className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 shadow-lg bg-gray-600">
                  <UserIcon className="w-5 h-5 text-gray-300" />
               </div>
          );
      }
  };

  if (isEditing) {
    return (
        <div className="flex w-full justify-start">
            <div className="group flex items-start gap-3 w-full">
                {renderAvatar()}
                <div className="relative w-full max-w-2xl flex flex-col gap-2">
                    <textarea
                        ref={editInputRef}
                        value={editedText}
                        onChange={(e) => {
                            setEditedText(e.target.value)
                            e.target.style.height = 'auto';
                            e.target.style.height = `${e.target.scrollHeight}px`;
                        }}
                        className="w-full text-gray-200 p-3 rounded-lg focus:outline-none focus:ring-2 resize-none"
                        style={{backgroundColor: isModel ? 'var(--color-bubble-model)' : 'var(--color-bubble-user)'}}
                    />
                    <div className="flex items-center justify-end gap-2">
                        <button onClick={onCancelEdit} className="px-3 py-1 bg-gray-700 rounded-md text-sm hover:bg-gray-600">Cancel</button>
                        <button onClick={handleSave} className="px-3 py-1 rounded-md text-sm text-white" style={{backgroundColor: 'var(--color-accent-secondary)'}}>
                            {editMode === 'restart' ? 'Save & Submit' : 'Save Changes'}
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
  }

  return (
    <div className={`flex w-full ${isModel ? 'justify-start' : 'justify-end'}`}>
        <div className="group flex items-start gap-3 max-w-2xl">
            {isModel && renderAvatar()}
            
            <div className={`relative flex flex-col ${isModel ? 'items-start' : 'items-end'}`}>
                <div className="p-3 rounded-lg flex-1" style={{backgroundColor: isModel ? 'var(--color-bubble-model)' : 'var(--color-bubble-user)', borderBottomLeftRadius: isModel ? '0.125rem' : '0.5rem', borderBottomRightRadius: isModel ? '0.5rem' : '0.125rem' }}>
                    {message.multiResponses && !message.selectionMade ? (
                        <div className="space-y-4">
                            <p className="text-xs text-gray-400">Multiple responses generated. Select the best one:</p>
                            {message.multiResponses.map(resp => (
                                <div key={resp.id} className="border-t border-gray-600 pt-3">
                                    <p className="text-xs font-bold text-purple-400 mb-2">{resp.model}</p>
                                    <SingleMessageContent parts={resp.parts} onImageClick={onImageClick} />
                                    <button onClick={() => onSelectBestResponse(message.id, resp.id)} className="mt-2 px-3 py-1 bg-purple-600 hover:bg-purple-700 text-white rounded text-xs">Select this response</button>
                                </div>
                            ))}
                        </div>
                    ) : (
                        <SingleMessageContent parts={message.parts} onImageClick={onImageClick} isLoading={isLastMessage && isLoading} />
                    )}
                </div>

                {isModel && message.groundingChunks && message.groundingChunks.length > 0 && (
                  <div className="mt-2 text-xs text-gray-400 max-w-full w-full">
                    <p className="font-bold mb-1">Sources:</p>
                    <ul className="list-disc list-inside space-y-1">
                      {/* FIX: Add check for chunk.web.uri before rendering to prevent invalid links */}
                      {message.groundingChunks.map((chunk, i) =>
                        chunk.web && chunk.web.uri ? (
                          <li key={i} className="truncate">
                            <a href={chunk.web.uri} target="_blank" rel="noopener noreferrer" className="text-purple-400 hover:underline">
                              {chunk.web.title || chunk.web.uri}
                            </a>
                          </li>
                        ) : null
                      )}
                    </ul>
                  </div>
                )}

                <div className={`mt-1 flex items-center gap-1 transition-opacity opacity-0 group-hover:opacity-100 ${isModel ? 'justify-start' : 'justify-end'}`}>
                    {!isModel && (
                        <button onClick={handleModifyRestart} className="p-1 rounded hover:bg-gray-700 text-gray-500 hover:text-white" title="Edit & Resubmit">
                            <EditIcon />
                        </button>
                    )}
                    {isModel && (
                        <button onClick={handleModifyNoRestart} className="p-1 rounded hover:bg-gray-700 text-gray-500 hover:text-white" title="Edit Message">
                            <EditIcon />
                        </button>
                    )}
                    {isModel && isLastMessage && !isLoading && (
                        <button onClick={handleRegenerate} className="p-1 rounded hover:bg-gray-700 text-gray-500 hover:text-white" title="Regenerate Response">
                            <RegenerateIcon />
                        </button>
                    )}
                     <div ref={menuRef} className="relative">
                        <button onClick={() => setMenuOpen(!menuOpen)} className="p-1 rounded hover:bg-gray-700 text-gray-500 hover:text-white"><MoreOptionsIcon /></button>
                        {menuOpen && (
                            <div className="absolute bottom-full mb-1 w-48 bg-[#1C1C1E] border border-gray-700 rounded-md shadow-lg py-1 z-20" style={{ right: isModel ? 'auto' : 0, left: isModel ? 0 : 'auto' }}>
                                <button onClick={handleCopy} className="flex items-center w-full text-left px-3 py-2 text-xs hover:bg-gray-700"><CopyIcon className="w-4 h-4 mr-2"/>Copy</button>
                                {!isModel && <button onClick={handleModifyNoRestart} className="flex items-center w-full text-left px-3 py-2 text-xs hover:bg-gray-700"><PencilOffIcon className="w-4 h-4 mr-2"/>Modify (No Restart)</button>}
                                {isModel && isLastMessage && isLoading === false && <button onClick={handleContinue} className="flex items-center w-full text-left px-3 py-2 text-xs hover:bg-gray-700"><ContinueIcon className="w-4 h-4 mr-2"/>Continue</button>}
                                {hasExecutableCode && <button onClick={handleExecute} className="flex items-center w-full text-left px-3 py-2 text-xs hover:bg-gray-700"><ExecuteIcon className="w-4 h-4 mr-2"/>Execute Code</button>}
                                {isModel && <button onClick={handleSpeak} className="flex items-center w-full text-left px-3 py-2 text-xs hover:bg-gray-700"><MicIcon className="w-4 h-4 mr-2"/>Speak</button>}
                                {message.context && <button onClick={handleShowInfo} className="flex items-center w-full text-left px-3 py-2 text-xs hover:bg-gray-700"><InfoIcon className="w-4 h-4 mr-2"/>Show Info</button>}
                                <button onClick={handleDelete} className="flex items-center w-full text-left px-3 py-2 text-xs text-red-400 hover:bg-red-900/30"><DeleteIcon className="w-4 h-4 mr-2"/>Delete</button>
                            </div>
                        )}
                    </div>
                </div>
            </div>
            {!isModel && renderAvatar()}
        </div>
    </div>
  );
};

export const ChatMessage = memo(ChatMessageInternal);