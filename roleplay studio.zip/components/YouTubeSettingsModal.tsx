import React, { useState, useEffect, useRef } from 'react';
import { VideoSettings } from '../types';
import { CloseIcon, YouTubeIcon } from './Icons';

interface YouTubeSettingsModalProps {
  initialUrl: string;
  onClose: () => void;
  onSave: (url: string, settings: VideoSettings) => void;
}

const YOUTUBE_URL_REGEX = /(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/watch\?v=|youtu\.be\/)([a-zA-Z0-9_-]{11})/;


const YouTubeSettingsModal: React.FC<YouTubeSettingsModalProps> = ({ initialUrl, onClose, onSave }) => {
  const [url, setUrl] = useState(initialUrl);
  const [startTime, setStartTime] = useState('');
  const [endTime, setEndTime] = useState('');
  const [fps, setFps] = useState('');
  const [thumbnail, setThumbnail] = useState<string | null>(null);
  const [error, setError] = useState('');

  useEffect(() => {
    const match = url.match(YOUTUBE_URL_REGEX);
    if (match && match[1]) {
        const videoId = match[1];
        setThumbnail(`https://img.youtube.com/vi/${videoId}/0.jpg`);
        setError('');
    } else {
        setThumbnail(null);
        if (url) {
            setError('Invalid YouTube URL');
        } else {
            setError('');
        }
    }
  }, [url]);


  const handleSave = () => {
    const match = url.match(YOUTUBE_URL_REGEX);
    if (!url || !match) {
        setError('A valid YouTube URL is required.');
        return;
    }
    onSave(url, {
        startTime,
        endTime,
        fps: fps || '5'
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-95 z-[100] flex items-center justify-center p-4">
      <div className="bg-[#1C1C1E] border border-gray-700 rounded-xl shadow-2xl w-full max-w-md flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex justify-between items-center p-4 border-b border-gray-700 bg-[#161618]">
          <h2 className="text-lg font-bold font-orbitron text-white flex items-center"><YouTubeIcon className="w-5 h-5 mr-2 text-red-500" /> YouTube Video</h2>
          <button onClick={onClose} className="p-1 hover:bg-gray-700 rounded-full text-gray-400 hover:text-white">
            <CloseIcon />
          </button>
        </div>

        {/* Preview */}
        <div className="p-4 bg-black flex justify-center items-center">
            <div className="relative w-full aspect-video rounded-lg overflow-hidden border border-gray-800">
                {thumbnail ? (
                    <img src={thumbnail} alt="YouTube Thumbnail" className="w-full h-full object-cover" />
                ) : (
                    <div className="w-full h-full bg-gray-900 flex items-center justify-center text-gray-500">
                        <YouTubeIcon className="w-12 h-12" />
                    </div>
                )}
            </div>
        </div>

        {/* Settings Form */}
        <div className="p-6 space-y-6">
            <div>
                <label className="block text-xs font-medium text-gray-400 mb-1.5">YouTube URL</label>
                <input 
                    type="text" 
                    value={url}
                    onChange={(e) => setUrl(e.target.value)}
                    placeholder="https://www.youtube.com/watch?v=..."
                    className={`w-full bg-[#131314] border rounded p-2.5 text-sm text-white focus:outline-none focus:ring-1 transition-colors ${error ? 'border-red-500 focus:border-red-500 focus:ring-red-500' : 'border-gray-600 focus:border-purple-500 focus:ring-purple-500'}`}
                />
                {error && <p className="text-red-500 text-xs mt-1">{error}</p>}
            </div>
            <div className="flex space-x-4">
                <div className="flex-1">
                    <label className="block text-xs font-medium text-gray-400 mb-1.5">Start Time (e.g., 1m10s)</label>
                    <input 
                        type="text" 
                        value={startTime}
                        onChange={(e) => setStartTime(e.target.value)}
                        placeholder="0s"
                        className="w-full bg-[#131314] border border-gray-600 rounded p-2.5 text-sm text-white focus:border-purple-500 focus:outline-none focus:ring-1 focus:ring-purple-500 transition-colors"
                    />
                </div>
                <div className="flex-1">
                    <label className="block text-xs font-medium text-gray-400 mb-1.5">End Time (e.g., 2m30s)</label>
                    <input 
                        type="text" 
                        value={endTime}
                        onChange={(e) => setEndTime(e.target.value)}
                        placeholder="End"
                        className="w-full bg-[#131314] border border-gray-600 rounded p-2.5 text-sm text-white focus:border-purple-500 focus:outline-none focus:ring-1 focus:ring-purple-500 transition-colors"
                    />
                </div>
            </div>

            <div>
                <label className="block text-xs font-medium text-gray-400 mb-1.5">FPS (frames per second)</label>
                <input 
                    type="number" 
                    value={fps}
                    onChange={(e) => setFps(e.target.value)}
                    placeholder="Defaults to 5 FPS"
                    className="w-full bg-[#131314] border border-gray-600 rounded p-2.5 text-sm text-white focus:border-purple-500 focus:outline-none focus:ring-1 focus:ring-purple-500 transition-colors"
                />
                <p className="text-[10px] text-gray-500 mt-1">Higher FPS provides more detail but increases processing time and token usage significantly. Recommended: 1-10.</p>
            </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-gray-700 bg-[#161618] flex justify-end space-x-3">
            <button onClick={onClose} className="px-4 py-2 rounded text-sm font-medium text-white hover:bg-gray-700 transition-colors">
                Cancel
            </button>
            <button onClick={handleSave} className="px-6 py-2 rounded text-sm font-bold text-white bg-blue-600 hover:bg-blue-500 transition-colors flex items-center">
                Save
            </button>
        </div>
      </div>
    </div>
  );
};

export default YouTubeSettingsModal;