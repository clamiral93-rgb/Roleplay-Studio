import React, { useState, useRef, useEffect } from 'react';
import { CloseIcon } from './Icons';

interface FloatingYouTubePlayerProps {
  videoId: string;
  onClose: () => void;
}

const FloatingYouTubePlayer: React.FC<FloatingYouTubePlayerProps> = ({ videoId, onClose }) => {
  const [position, setPosition] = useState({ x: window.innerWidth / 2 - 280, y: window.innerHeight / 2 - 157 });
  const [isDragging, setIsDragging] = useState(false);
  const dragStartPos = useRef({ x: 0, y: 0 });
  const playerRef = useRef<HTMLDivElement>(null);

  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    dragStartPos.current = {
      x: e.clientX - position.x,
      y: e.clientY - position.y,
    };
  };

  const handleMouseMove = (e: MouseEvent) => {
    if (!isDragging) return;
    setPosition({
      x: e.clientX - dragStartPos.current.x,
      y: e.clientY - dragStartPos.current.y,
    });
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  useEffect(() => {
    if (isDragging) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleMouseUp);
    } else {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    }
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isDragging]);

  return (
    <div
      ref={playerRef}
      className="fixed z-50 w-[560px] h-[315px] bg-black border border-purple-500/30 rounded-lg shadow-2xl flex flex-col overflow-hidden"
      style={{ left: `${position.x}px`, top: `${position.y}px` }}
    >
      <div
        className="h-8 bg-gray-900 flex justify-between items-center px-2 cursor-move"
        onMouseDown={handleMouseDown}
      >
        <span className="text-xs text-gray-400 font-mono">YouTube Player</span>
        <button onClick={onClose} className="p-1 rounded-full hover:bg-gray-700">
          <CloseIcon className="w-4 h-4" />
        </button>
      </div>
      <div className="flex-grow">
        <iframe
          width="100%"
          height="100%"
          src={`https://www.youtube.com/embed/${videoId}?autoplay=1`}
          title="YouTube video player"
          frameBorder="0"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowFullScreen
        ></iframe>
      </div>
    </div>
  );
};

export default FloatingYouTubePlayer;
