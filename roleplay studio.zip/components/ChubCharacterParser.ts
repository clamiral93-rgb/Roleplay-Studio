import { ChubCharacter } from '../types';

export const parseCharacterFromPng = async (arrayBuffer: ArrayBuffer): Promise<any> => {
    const view = new DataView(arrayBuffer);
    const byteLength = arrayBuffer.byteLength;

    // Check PNG signature
    if (byteLength < 8) {
        throw new Error('File is too small to be a PNG');
    }
    const signature = [0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A];
    for (let i = 0; i < 8; i++) {
        if (view.getUint8(i) !== signature[i]) {
            throw new Error('Invalid PNG signature');
        }
    }

    let offset = 8;
    const textDecoder = new TextDecoder('utf-8');

    while (offset < byteLength - 12) {
        const length = view.getUint32(offset);
        const chunkType = textDecoder.decode(new Uint8Array(arrayBuffer, offset + 4, 4));

        if (chunkType === 'tEXt' || chunkType === 'iTXt') {
            const chunkData = new Uint8Array(arrayBuffer, offset + 8, length);
            
            if (chunkType === 'tEXt') {
                // Find single null separator for tEXt: keyword \x00 text
                let nullIdx = -1;
                for (let i = 0; i < length; i++) {
                    if (chunkData[i] === 0) {
                        nullIdx = i;
                        break;
                    }
                }

                if (nullIdx !== -1) {
                    const keyword = textDecoder.decode(chunkData.subarray(0, nullIdx));
                    if (keyword.toLowerCase() === 'chara' || keyword.toLowerCase() === 'character') {
                        const textBytes = chunkData.subarray(nullIdx + 1);
                        const rawText = textDecoder.decode(textBytes);
                        
                        try {
                            // Try parsing direct JSON
                            if (rawText.trim().startsWith('{')) {
                                return JSON.parse(rawText);
                            }
                            // Otherwise, assume Base64 encoded JSON
                            const decoded = atob(rawText.trim());
                            return JSON.parse(decoded);
                        } catch (e) {
                            console.error('Failed to parse Tavern JSON from tEXt content:', e);
                        }
                    }
                }
            } else if (chunkType === 'iTXt') {
                // Find Keyword (null terminated)
                let keywordNullIdx = -1;
                for (let i = 0; i < length; i++) {
                    if (chunkData[i] === 0) {
                        keywordNullIdx = i;
                        break;
                    }
                }

                if (keywordNullIdx !== -1) {
                    const keyword = textDecoder.decode(chunkData.subarray(0, keywordNullIdx));
                    if (keyword.toLowerCase() === 'chara' || keyword.toLowerCase() === 'character') {
                        // iTXt structure remains:
                        // Compression flag (1 byte) -> offset keywordNullIdx + 1
                        // Compression method (1 byte) -> offset keywordNullIdx + 2
                        // Language tag (0-terminated) -> offset keywordNullIdx + 3 onwards
                        // Translated keyword (0-terminated) -> after Lang Tag
                        // Text -> after Translated Keyword
                        const compressionFlag = chunkData[keywordNullIdx + 1];
                        
                        // We skip language tag and translated keyword to get to text.
                        let idx = keywordNullIdx + 3;
                        // Skip language tag
                        while (idx < length && chunkData[idx] !== 0) {
                            idx++;
                        }
                        idx++; // skip null
                        
                        // Skip translated keyword
                        while (idx < length && chunkData[idx] !== 0) {
                            idx++;
                        }
                        idx++; // skip null

                        if (idx < length) {
                            const textBytes = chunkData.subarray(idx);
                            
                            if (compressionFlag === 0) {
                                // Uncompressed
                                const rawText = textDecoder.decode(textBytes);
                                try {
                                    if (rawText.trim().startsWith('{')) {
                                        return JSON.parse(rawText);
                                    }
                                    const decoded = atob(rawText.trim());
                                    return JSON.parse(decoded);
                                } catch (e) {
                                    console.error('Failed to parse Tavern JSON from iTXt content:', e);
                                }
                            } else {
                                console.warn('Compressed iTXt is currently not supported. Please paste the JSON instead.');
                            }
                        }
                    }
                }
            }
        }

        offset += 4 + 4 + length + 4; // Length(4) + Type(4) + Data(length) + CRC(4)
    }

    throw new Error('No compatible Tavern character card metadata found in PNG "chara" or "character" text chunks.');
};

export const parseCharacterCardJson = (json: any, fallbackName: string = 'Unnamed Character'): ChubCharacter => {
    // Determine format: V1 (flat fields) vs V2 (fields under .data)
    const data = json.data ? json.data : json;
    
    const id = json.id || Math.random().toString(36).substring(2, 11);
    const name = data.name || data.chara_name || fallbackName;
    const tagline = data.tagline || '';
    const description = data.description || '';
    const personality = data.personality || '';
    const scenario = data.scenario || '';
    const first_mes = data.first_mes || data.chara_greeting || '';
    const mes_example = data.mes_example || '';
    const system_prompt = data.system_prompt || '';
    const creator_notes = data.creator_notes || data.creatorNotes || '';
    const alternate_greetings = Array.isArray(data.alternate_greetings) ? data.alternate_greetings : [];
    const post_history_instructions = data.post_history_instructions || '';
    const character_note = data.character_note || data.char_note || data.extensions?.depth_prompt?.prompt || '';
    const character_note_depth = data.character_note_depth || data.char_note_depth || data.extensions?.depth_prompt?.depth || 4;

    return {
        id,
        name,
        tagline,
        description,
        personality,
        scenario,
        first_mes,
        mes_example,
        system_prompt,
        creator_notes,
        alternate_greetings,
        post_history_instructions,
        character_note,
        character_note_depth: Number(character_note_depth) || 4
    };
};

export const replacePlaceholders = (text: string, charName: string, userName: string): string => {
    if (!text) return '';
    return text
        .replace(/\{\{char\}\}/g, charName)
        .replace(/\{\{user\}\}/g, userName);
};

export const buildCharacterSystemInstruction = (
    char: ChubCharacter, 
    userPersona: any | null, 
    activePreset?: any,
    lorebookContext?: string
): string => {
    const charName = char.name;
    const userName = userPersona?.name || 'User';
    
    const replace = (text: string) => replacePlaceholders(text, charName, userName);

    const personality = replace(char.personality);
    const description = replace(char.description);
    const scenario = replace(char.scenario);
    const systemPrompt = replace(char.system_prompt);
    const mesExample = replace(char.mes_example || '');
    const postHelp = replace(char.post_history_instructions || '');
    const charNote = replace(char.character_note || '');

    const presetPreHistory = activePreset?.pre_history_instructions ? replace(activePreset.pre_history_instructions) : '';
    const presetPostHistory = activePreset?.post_history_instructions ? replace(activePreset.post_history_instructions) : '';
    const presetPromptNote = activePreset?.prompt_note ? replace(activePreset.prompt_note) : '';

    const parts = [
        presetPreHistory ? `[PRE-HISTORY INSTRUCTIONS:\n${presetPreHistory}]` : '',
        `You are roleplaying as ${charName}. You must stay in character at all times and speak, think, react exactly like ${charName} based on the description and personality below.`,
        `You are roleplaying with ${userName}.`,
        userPersona?.description ? `[User Persona Details for ${userName}:\n${replace(userPersona.description)}]` : '',
        personality ? `[Character Personality:\n${personality}]` : '',
        description ? `[Character Background & Lore:\n${description}]` : '',
        scenario ? `[Scene Scenario:\n${scenario}]` : '',
        systemPrompt ? `[Style Instructions:\n${systemPrompt}]` : '',
        mesExample ? `[Example Dialogue & Tone Guidelines:\n${mesExample}]` : '',
        charNote ? `[Character's Active Note (Priority Rules at Depth ${char.character_note_depth || 4}):\n${charNote}]` : '',
        lorebookContext ? `[ACTIVE LOREBOOK KNOWLEDGE:\n${lorebookContext}]` : '',
        presetPromptNote ? `[PROMPT NOTE (Depth ${activePreset?.prompt_note_depth || 0}):\n${presetPromptNote}]` : '',
        postHelp ? `[Post-History Rules:\n${postHelp}]` : '',
        presetPostHistory ? `[ADDITIONAL PROMPT RULES:\n${presetPostHistory}]` : '',
        `Write in deep, detailed literary style matching the character. Always stay in-character, using rich prose, character thoughts, and actions enclosed in asterisks *like this* if appropriate, or standard narration. Never break character.`
    ];
    return parts.filter(Boolean).join('\n\n');
};

export const getLorebookContext = (
    messages: any[], 
    lorebooks: any[], 
    activePreset?: any
): string => {
    if (!lorebooks || lorebooks.length === 0) return '';

    const scanDepth = activePreset?.lorebook_scan_depth ?? 2;
    const tokenBudget = activePreset?.lorebook_token_budget ?? 512;
    const matchWholeWords = activePreset?.match_whole_words ?? false;

    // Get messages to scan
    const messagesToScan = messages.slice(-scanDepth);
    const textToScan = messagesToScan.map(m => m.parts?.map((p: any) => p.text || '').join(' ') || '').join(' ');

    if (!textToScan.trim()) return '';

    let triggeredEntries: { key: string; content: string; priority: number }[] = [];

    // Loop over all active/enabled lorebooks
    for (const book of lorebooks) {
        if (!book.entries) continue;
        for (const entry of book.entries) {
            if (!entry.enabled) continue;
            
            let triggered = entry.constant || false;
            if (!triggered && entry.keys) {
                for (const key of entry.keys) {
                    if (!key.trim()) continue;
                    const cleanKey = key.trim().toLowerCase();
                    if (matchWholeWords) {
                        const regex = new RegExp(`\\b${cleanKey}\\b`, 'i');
                        if (regex.test(textToScan)) {
                            triggered = true;
                            break;
                        }
                    } else {
                        if (textToScan.toLowerCase().includes(cleanKey)) {
                            triggered = true;
                            break;
                        }
                    }
                }
            }

            if (triggered) {
                triggeredEntries.push({
                    key: entry.keys?.[0] || 'Constant',
                    content: entry.content,
                    priority: entry.priority ?? 10
                });
            }
        }
    }

    if (triggeredEntries.length === 0) return '';

    // Sort by priority desc
    triggeredEntries.sort((a, b) => b.priority - a.priority);

    // Compile content up to token budget (approx 1 char = 0.25 tokens, so budget * 4 chars)
    let currentLength = 0;
    const maxChars = tokenBudget * 4;
    let compiledParts: string[] = [];

    for (const entry of triggeredEntries) {
        const part = `- ${entry.key}: ${entry.content}`;
        if (currentLength + part.length > maxChars) break;
        compiledParts.push(part);
        currentLength += part.length;
    }

    return compiledParts.join('\n\n');
};
