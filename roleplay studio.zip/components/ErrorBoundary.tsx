import React, { ErrorInfo, ReactNode } from 'react';
import { BugIcon } from './Icons';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error?: Error;
}

// FIX: Changed `extends Component<...>` to `extends React.Component<...>` to resolve type ambiguity.
class ErrorBoundary extends React.Component<Props, State> {
  // FIX: Removed 'public' access modifiers, which are default and can sometimes cause issues with specific TypeScript or linter configurations.
  state: State = {
    hasError: false,
  };

  static getDerivedStateFromError(error: Error): State {
    // Update state so the next render will show the fallback UI.
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    // You can also log the error to an error reporting service
    console.error("Uncaught error:", error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      // You can render any custom fallback UI
      return (
        <div className="flex h-screen w-full flex-col items-center justify-center bg-[#131314] p-4 text-center text-red-400">
          <BugIcon className="h-16 w-16 text-red-500" />
          <h1 className="mt-4 text-2xl font-bold font-orbitron">SYSTEM FAILURE</h1>
          <p className="mt-2 text-gray-400">
            WormGPT has encountered a critical error. Your conversation data is safe.
          </p>
          <button
            onClick={() => window.location.reload()}
            className="mt-6 rounded-lg bg-red-600 px-6 py-2 font-bold text-white hover:bg-red-700"
          >
            Reboot Interface
          </button>
          <details className="mt-6 w-full max-w-2xl text-left">
            <summary className="cursor-pointer text-sm text-gray-500">
              Show Error Details
            </summary>
            <pre className="mt-2 overflow-auto rounded-lg bg-black p-4 text-xs text-gray-300">
              {this.state.error?.toString()}
              {this.state.error?.stack}
            </pre>
          </details>
        </div>
      );
    }

    // FIX: Correctly access props via `this.props` in a class component.
    return this.props.children;
  }
}

export default ErrorBoundary;
