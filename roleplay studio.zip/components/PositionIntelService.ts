const COMPENDIUM_KEY = 'wormgpt_position_compendium';

export const savePositionCompendium = (content: string): void => {
    try {
        localStorage.setItem(COMPENDIUM_KEY, content);
    } catch (e) {
        console.error("Failed to save Position Compendium to localStorage:", e);
    }
};

export const getPositionCompendium = (): string | null => {
    try {
        return localStorage.getItem(COMPENDIUM_KEY);
    } catch (e) {
        console.error("Failed to retrieve Position Compendium from localStorage:", e);
        return null;
    }
};

export const deletePositionCompendium = (): void => {
    try {
        localStorage.removeItem(COMPENDIUM_KEY);
    } catch (e) {
        console.error("Failed to delete Position Compendium from localStorage:", e);
    }
};
