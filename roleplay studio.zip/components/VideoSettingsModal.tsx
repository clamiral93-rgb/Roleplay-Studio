import React, { useState, useEffect, useRef } from 'react';
import { AttachedFile, VideoSettings } from '../types';
import { CloseIcon } from './Icons';

interface VideoSettingsModalProps {
  file: AttachedFile | null; // Can be null when closing
  onClose: () => void;
  onSave: (settings: VideoSettings) => void;
}

const VideoSettingsModal: React.FC<VideoSettingsModalProps> = ({ file, onClose, onSave }) => {
  const [startTime, setStartTime] = useState(file?.videoSettings?.startTime || '');
  const [endTime, setEndTime] = useState(file?.videoSettings?.endTime || '');
  const [fps, setFps] = useState(file?.videoSettings?.fps || '1');
  const videoRef = useRef<HTMLVideoElement>(null);

  // Auto-fill end time with duration if empty
  useEffect(() => {
    const video = videoRef.current;
    if (video && file) {
        video.onloadedmetadata = () => {
            if (!endTime && !file.videoSettings?.endTime) {
                // Optional: set default, currently leaving blank as "End" implies full duration
            }
        };
    }
  }, [file]);

  const handleSave = () => {
    onSave({
        startTime,
        endTime,
        fps: fps || '1' // Default to 1 if empty
    });
    onClose();
  };

  const handleFpsChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let value = e.target.value;
    if (value) {
        const numValue = parseInt(value, 10);
        if (numValue > 24) {
            value = '24';
        }
        if (numValue < 1 && value !== '') {
            value = '1';
        }
    }
    setFps(value);
  }

  if (!file) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-95 z-[100] flex items-center justify-center p-4">
      <div className="bg-[#1C1C1E] border border-gray-700 rounded-xl shadow-2xl w-full max-w-md flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex justify-between items-center p-4 border-b border-gray-700 bg-[#161618]">
          <h2 className="text-lg font-bold font-orbitron text-white">Video settings</h2>
          <button onClick={onClose} className="p-1 hover:bg-gray-700 rounded-full text-gray-400 hover:text-white">
            <CloseIcon />
          </button>
        </div>

        {/* Video Preview */}
        <div className="p-4 bg-black flex justify-center items-center">
            {file.preview ? (
                <div className="relative w-full aspect-video rounded-lg overflow-hidden border border-gray-800">
                    <video 
                        ref={videoRef}
                        src={file.preview} 
                        controls 
                        className="w-full h-full object-contain"
                    />
                </div>
            ) : (
                <div className="w-full aspect-video bg-gray-900 rounded flex items-center justify-center text-gray-500">
                    No Preview
                </div>
            )}
        </div>

        {/* Settings Form */}
        <div className="p-6 space-y-6">
            <div className="flex space-x-4">
                <div className="flex-1">
                    <label className="block text-xs font-medium text-gray-400 mb-1.5">Start Time (e.g., 1m10s)</label>
                    <input 
                        type="text" 
                        value={startTime}
                        onChange={(e) => setStartTime(e.target.value)}
                        placeholder="0s"
                        className="w-full bg-[#131314] border border-gray-600 rounded p-2.5 text-sm text-white focus:border-purple-500 focus:outline-none focus:ring-1 focus:ring-purple-500 transition-colors"
                    />
                </div>
                <div className="flex-1">
                    <label className="block text-xs font-medium text-gray-400 mb-1.5">End Time (e.g., 2m30s)</label>
                    <input 
                        type="text" 
                        value={endTime}
                        onChange={(e) => setEndTime(e.target.value)}
                        placeholder="End"
                        className="w-full bg-[#131314] border border-gray-600 rounded p-2.5 text-sm text-white focus:border-purple-500 focus:outline-none focus:ring-1 focus:ring-purple-500 transition-colors"
                    />
                </div>
            </div>

            <div>
                <label className="block text-xs font-medium text-gray-400 mb-1.5">FPS (frames per second)</label>
                <input 
                    type="number" 
                    value={fps}
                    onChange={handleFpsChange}
                    min="1"
                    max="24"
                    placeholder="Defaults to 1 FPS"
                    className="w-full bg-[#131314] border border-gray-600 rounded p-2.5 text-sm text-white focus:border-purple-500 focus:outline-none focus:ring-1 focus:ring-purple-500 transition-colors"
                />
                <p className="text-[10px] text-gray-500 mt-1">Higher FPS provides more detail but payload increases. Max 2MB total. Recommended: 1-5.</p>
            </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-gray-700 bg-[#161618] flex justify-end space-x-3">
            <button onClick={onClose} className="px-4 py-2 rounded text-sm font-medium text-white hover:bg-gray-700 transition-colors">
                Cancel
            </button>
            <button onClick={handleSave} className="px-6 py-2 rounded text-sm font-bold text-white bg-purple-600 hover:bg-purple-500 transition-colors flex items-center">
                Save
            </button>
        </div>
      </div>
    </div>
  );
};

export default VideoSettingsModal;