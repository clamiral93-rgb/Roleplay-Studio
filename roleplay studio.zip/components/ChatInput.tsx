import React, { useState, KeyboardEvent, useRef, useEffect, forwardRef } from 'react';
import { PlusIcon, MicIcon, SendIcon, FileTextIcon, CloseIcon, PDFIcon, VideoIcon, PaintBrushIcon, GlobeIcon, ActivityIcon, ImageIcon, E621Icon, CodeIcon, WarningIcon, SpinnerIcon, AudioIcon } from './Icons';
import { AttachedFile, MessagePart } from '../types';
import * as pdfjsLib from 'pdfjs-dist';

pdfjsLib.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjsLib.version}/pdf.worker.min.js`;

const generateFileId = () => `file_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;

const fileToContent = (file: File): Promise<string> =>
  new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve((reader.result as string).split(',')[1]);
    reader.onerror = (error) => reject(error);
  });
  
const DataPayloadEstimator: React.FC<{ text: string; files: AttachedFile[] }> = ({ text, files }) => {
  const [totalSize, setTotalSize] = useState(0);

  useEffect(() => {
    let size = 0;
    size += new Blob([text]).size;

    files.forEach(file => {
      // For videos, the size is determined by processedData, not the original file
      if (file.type === 'video' && file.processedData) {
        file.processedData.forEach(part => {
          if (part.inlineData?.data) {
            size += part.inlineData.data.length * 0.75;
          }
        });
      } else if (file.file) {
        size += file.file.size;
      }
    });
    setTotalSize(size);
  }, [text, files]);

  const MAX_SIZE = 50 * 1024 * 1024;
  const DANGER_THRESHOLD = 45 * 1024 * 1024;
  const WARNING_THRESHOLD = 35 * 1024 * 1024;

  const percentage = Math.min((totalSize / MAX_SIZE) * 100, 100);
  
  let barColor = 'bg-green-500';
  let textColor = 'text-green-400';
  let label = 'Payload Estimate';

  if (totalSize > DANGER_THRESHOLD) {
    barColor = 'bg-red-500';
    textColor = 'text-red-400';
    label = 'CRITICAL: CRASH POSSIBLE';
  } else if (totalSize > WARNING_THRESHOLD) {
    barColor = 'bg-yellow-500';
    textColor = 'text-yellow-400';
    label = 'High Memory Usage';
  }

  const formatBytes = (bytes: number) => {
    if (bytes < 0) bytes = 0;
    if (bytes === 0) return '0 B';
    const k = 1024;
    const dm = 1;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
  };

  return (
    <div className="px-2 pb-2 text-xs font-mono">
      <div className="flex justify-between items-center mb-1">
        <span className={`flex items-center transition-colors ${textColor}`}>
            {totalSize > DANGER_THRESHOLD && <WarningIcon className="w-4 h-4 mr-1 animate-pulse" />}
            {label}
        </span>
        <span className={`transition-colors ${textColor}`}>{formatBytes(totalSize)} / 50 MB</span>
      </div>
      <div className="w-full bg-black rounded-full h-1.5 border border-gray-800 overflow-hidden">
        <div className={`h-full rounded-full transition-all duration-300 ${barColor}`} style={{ width: `${percentage}%` }}></div>
      </div>
    </div>
  );
};


interface ChatInputProps {
  input: string;
  setInput: React.Dispatch<React.SetStateAction<string>>;
  attachedFiles: AttachedFile[];
  setAttachedFiles: (files: AttachedFile[] | ((prev: AttachedFile[]) => AttachedFile[])) => void;
  onAddFiles: (files: AttachedFile[]) => void;
  onSendMessage: (parts: MessagePart[]) => void;
  isLoading: boolean;
  processingMessage?: string;
  onOpenImageGenerator: () => void;
  onEditImage: (file: AttachedFile) => void;
  onConfigureVideo: (file: AttachedFile) => void;
  onOpenScraper: () => void;
  onOpenDstat: () => void;
  onOpenE621Wiki: () => void;
  onOpenCodeExecutor: () => void;
  googleSearchEnabled: boolean;
  setGoogleSearchEnabled: React.Dispatch<React.SetStateAction<boolean>>;
}

const ChatInput = forwardRef<HTMLTextAreaElement, ChatInputProps>(({ input, setInput, attachedFiles, setAttachedFiles, onAddFiles, onSendMessage, isLoading, processingMessage, onOpenImageGenerator, onEditImage, onConfigureVideo, onOpenScraper, onOpenDstat, onOpenE621Wiki, onOpenCodeExecutor, googleSearchEnabled, setGoogleSearchEnabled }, ref) => {
  const [isListening, setIsListening] = useState(false);
  const [isMenuOpen, setMenuOpen] = useState(false);
  const recognitionRef = useRef<any>(null);
  
  const imageInputRef = useRef<HTMLInputElement>(null);
  const videoInputRef = useRef<HTMLInputElement>(null);
  const audioInputRef = useRef<HTMLInputElement>(null);
  const anyFileInputRef = useRef<HTMLInputElement>(null);
  
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = false;
      recognitionRef.current.interimResults = false;
      recognitionRef.current.lang = 'en-US';
      recognitionRef.current.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setInput(prev => prev ? `${prev} ${transcript}` : transcript);
        setIsListening(false);
      };
      recognitionRef.current.onerror = (event: any) => { setIsListening(false); };
    }
  }, [setInput]);

  useEffect(() => {
    const handleClickOutside = (event: globalThis.MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) setMenuOpen(false);
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);
  
  const handleSubmit = async () => {
    if (isLoading || (!input.trim() && attachedFiles.every(f => f.processingStatus !== 'done' && !f.content))) return;
    
    const parts: MessagePart[] = [];
    if(input.trim()) parts.push({ text: input });

    for (const file of attachedFiles) {
        if(file.type === 'text' && file.content) {
            parts.push({ text: `\n[Attached File: ${file.name}]\n\`\`\`\n${file.content}\n\`\`\`` });
        }
    }
    
    onSendMessage(parts);
  };

  const handleKeyPress = (event: KeyboardEvent<HTMLTextAreaElement>) => {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      handleSubmit();
    }
  };

  const toggleListening = () => {
    if (!recognitionRef.current) return;
    if (isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
    } else {
      recognitionRef.current.start();
      setIsListening(true);
    }
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (!files) return;

    const filePromises = Array.from(files).map(async (file: File) => {
      
      let fileType: AttachedFile['type'] = 'other';
      if (file.type.startsWith('image/')) fileType = 'image';
      else if (file.type.startsWith('video/')) fileType = 'video';
      else if (file.type.startsWith('audio/')) fileType = 'audio';
      else if (file.type === 'application/pdf') fileType = 'pdf';
      else if (file.type.startsWith('text/')) fileType = 'text';
      
      return new Promise<AttachedFile>(async (resolve) => {
        const fileObject: AttachedFile = { id: generateFileId(), file, name: file.name, type: fileType };

        try {
            if (fileType === 'image' || fileType === 'audio' || fileType === 'video' || fileType === 'pdf') {
                if(fileType === 'image' || fileType === 'video') fileObject.preview = URL.createObjectURL(file);
                fileObject.content = await fileToContent(file);
            } else if (fileType === 'text') {
                fileObject.content = await file.text();
            }
        } catch (e) {
            console.error("Error processing file:", e);
        } finally {
            resolve(fileObject);
        }
      });
    });
    
    Promise.all(filePromises).then((newFiles) => onAddFiles(newFiles));
    if(event.target) event.target.value = ''; 
  };
  
  const removeFile = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const fileToRemove = attachedFiles.find(f => f.id === id);
    if (fileToRemove && fileToRemove.preview) {
        URL.revokeObjectURL(fileToRemove.preview);
    }
    setAttachedFiles(prev => prev.filter(f => f.id !== id));
  };

  const isSendButtonDisabled = isLoading || (!input.trim() && attachedFiles.every(f => f.processingStatus !== 'done' && !f.content));

  return (
    <>
    <div className={`rounded-xl p-2 flex flex-col transition-all duration-300 ${isLoading ? 'ring-2 ring-purple-500 animate-pulse' : 'focus-within:ring-2 ring-purple-500'}`} style={{backgroundColor: 'var(--color-panel)'}}>
        
        <DataPayloadEstimator text={input} files={attachedFiles} />

        {attachedFiles.length > 0 && (
            <div className="p-2 flex flex-wrap gap-2 border-b border-gray-700 mb-2">
                {attachedFiles.map(file => {
                    let FileIcon;
                    if (file.type === 'pdf') {
                        FileIcon = <PDFIcon className="h-6 w-6 text-red-500" />;
                    } else if (file.type === 'audio') {
                        FileIcon = <AudioIcon className="h-6 w-6 text-yellow-500" />;
                    } else {
                        FileIcon = <FileTextIcon className="w-6 h-6" />;
                    }
                    const canEdit = file.type === 'image';
                    const canConfigure = file.type === 'video';
                    const isClickable = canEdit || canConfigure;
                    
                    const handleClick = () => {
                        if (canEdit) onEditImage(file);
                        else if (canConfigure) onConfigureVideo(file);
                    }

                    return (
                        <div key={file.id} className={`relative w-16 h-16 bg-gray-900 rounded-md group ${isClickable ? 'cursor-pointer hover:ring-2 ring-purple-500' : ''}`} onClick={handleClick} title={isClickable ? `Configure ${file.name}` : file.name} >
                           { (file.type === 'image' || file.type === 'video') && file.preview ? ( <img src={file.preview} alt="preview" className="w-full h-full object-cover rounded-md"/> ) : ( <div className="w-full h-full flex items-center justify-center p-1">{FileIcon}</div> )}
                           
                            {file.processingStatus === 'processing' && (
                                <div className="absolute inset-0 bg-black/80 flex flex-col items-center justify-center rounded-md">
                                    <SpinnerIcon className="w-6 h-6 text-purple-400" />
                                    <p className="text-xs text-purple-400 mt-1">{file.processingProgress}%</p>
                                </div>
                            )}

                            {file.processingStatus === 'error' && (
                                <div title={file.errorMessage} className="absolute inset-0 bg-red-900/80 flex items-center justify-center rounded-md">
                                    <WarningIcon className="w-6 h-6 text-red-300" />
                                </div>
                            )}

                           <button onClick={(e) => removeFile(file.id, e)} className="absolute -top-1.5 -right-1.5 bg-gray-800 rounded-full p-0.5 text-white opacity-0 group-hover:opacity-100 transition-opacity z-10 hover:bg-red-600"> <CloseIcon className="h-3 w-3"/> </button>
                        </div>
                    );
                })}
            </div>
        )}
        
        <div className="flex items-end space-x-1.5">
            <div ref={menuRef} className="relative">
                <button onClick={() => setMenuOpen(!isMenuOpen)} disabled={isLoading} className="p-2 hover:bg-gray-700 rounded-full flex-shrink-0 disabled:opacity-50 disabled:cursor-not-allowed text-gray-400 hover:text-white"> <PlusIcon /> </button>
                {isMenuOpen && ( <div className="absolute bottom-full mb-2 w-52 border rounded-md shadow-lg py-1 left-0 z-50 overflow-hidden" style={{backgroundColor: 'var(--color-panel)', borderColor: 'var(--color-border)'}}> <button onClick={() => { imageInputRef.current?.click(); setMenuOpen(false); }} className="flex items-center w-full text-left px-4 py-3 text-xs text-gray-200 hover:bg-gray-700 border-b border-gray-700/50"> <ImageIcon className="mr-3 w-4 h-4 text-green-400" /> Upload Image </button> <button onClick={() => { videoInputRef.current?.click(); setMenuOpen(false); }} className="flex items-center w-full text-left px-4 py-3 text-xs text-gray-200 hover:bg-gray-700 border-b border-gray-700/50"> <VideoIcon className="mr-3 w-4 h-4 text-red-400" /> Upload Video </button> <button onClick={() => { audioInputRef.current?.click(); setMenuOpen(false); }} className="flex items-center w-full text-left px-4 py-3 text-xs text-gray-200 hover:bg-gray-700 border-b border-gray-700/50"> <AudioIcon className="mr-3 w-4 h-4 text-yellow-400" /> Upload Audio </button> <button onClick={() => { anyFileInputRef.current?.click(); setMenuOpen(false); }} className="flex items-center w-full text-left px-4 py-3 text-xs text-gray-400 hover:bg-gray-700 mb-1"> <PlusIcon className="mr-3 w-4 h-4" /> Upload Other File </button> <div className="border-t border-gray-700 my-1"></div> <button onClick={() => { onOpenImageGenerator(); setMenuOpen(false); }} className="flex items-center w-full text-left px-4 py-2 text-xs text-purple-400 hover:bg-gray-700"><PaintBrushIcon className="mr-3 w-4 h-4" /> Generate Image</button> <button onClick={() => { onOpenCodeExecutor(); setMenuOpen(false); }} className="flex items-center w-full text-left px-4 py-2 text-xs text-green-400 hover:bg-gray-700"><CodeIcon className="mr-3 w-4 h-4" /> Code Executor</button> <button onClick={() => { onOpenE621Wiki(); setMenuOpen(false); }} className="flex items-center w-full text-left px-4 py-2 text-xs text-blue-400 hover:bg-gray-700"><E621Icon className="mr-3 w-4 h-4" /> e621 Wiki Lookup</button> <button onClick={() => { onOpenScraper(); setMenuOpen(false); }} className="flex items-center w-full text-left px-4 py-2 text-xs text-blue-400 hover:bg-gray-700"><GlobeIcon className="mr-3 w-4 h-4" /> Website Scraper</button> <button onClick={() => { onOpenDstat(); setMenuOpen(false); }} className="flex items-center w-full text-left px-4 py-2 text-xs text-red-500 hover:bg-gray-700"><ActivityIcon className="mr-3 w-4 h-4 animate-pulse" /> Dstat Monitor</button> </div> )}
            </div>

            <input type="file" ref={imageInputRef} onChange={handleFileChange} className="hidden" accept="image/*" multiple />
            <input type="file" ref={videoInputRef} onChange={handleFileChange} className="hidden" accept="video/*" multiple />
            <input type="file" ref={audioInputRef} onChange={handleFileChange} className="hidden" accept="audio/*" multiple />
            <input type="file" ref={anyFileInputRef} onChange={handleFileChange} className="hidden" multiple />

            <textarea ref={ref} value={input} onChange={(e) => { setInput(e.target.value); const textarea = e.currentTarget; textarea.style.height = 'auto'; textarea.style.height = `${textarea.scrollHeight}px`; }} onKeyDown={handleKeyPress} placeholder={isLoading ? (processingMessage || "Waiting for response...") : "Enter your command..."} className="flex-grow bg-transparent border-0 outline-none focus:ring-0 text-gray-200 placeholder-gray-500 resize-none max-h-48 p-2 text-sm" rows={1} disabled={isLoading} />
            <button onClick={toggleListening} disabled={isLoading} className={`p-2 hover:bg-gray-700 rounded-full flex-shrink-0 disabled:opacity-50 disabled:cursor-not-allowed ${isListening ? 'text-purple-500' : 'text-gray-400'}`}> <MicIcon /> </button>
            <button onClick={() => setGoogleSearchEnabled(!googleSearchEnabled)} disabled={isLoading} className={`p-2 rounded-full flex-shrink-0 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 ${googleSearchEnabled ? 'bg-purple-600 text-white hover:bg-purple-700 shadow-md shadow-purple-500/20' : 'bg-black text-gray-400 hover:bg-gray-900 border border-gray-800'}`} title={googleSearchEnabled ? "Disable Google Search" : "Enable Google Search"}> <GlobeIcon className="w-4 h-4" /> </button>
            <button onClick={handleSubmit} disabled={isSendButtonDisabled} className="p-2 rounded-full disabled:bg-gray-600 disabled:cursor-not-allowed transition-colors flex-shrink-0" style={{backgroundColor: !isSendButtonDisabled ? 'var(--color-accent-secondary)' : undefined}} > <SendIcon /> </button>
        </div>
    </div>
    </>
  );
});

export default ChatInput;