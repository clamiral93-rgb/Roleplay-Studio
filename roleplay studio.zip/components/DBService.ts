const DB_NAME = 'WormGPT-Assets';
const STORE_NAME = 'large_data';
const APP_STATE_STORE = 'app_state';
const DB_VERSION = 2;

let db: IDBDatabase | null = null;

const openDB = (): Promise<IDBDatabase> => {
  return new Promise((resolve, reject) => {
    if (db) {
      return resolve(db);
    }

    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = () => {
      const dbInstance = request.result;
      if (!dbInstance.objectStoreNames.contains(STORE_NAME)) {
        dbInstance.createObjectStore(STORE_NAME, { autoIncrement: true });
      }
      if (!dbInstance.objectStoreNames.contains(APP_STATE_STORE)) {
        dbInstance.createObjectStore(APP_STATE_STORE, { keyPath: 'key' });
      }
    };

    request.onsuccess = () => {
      db = request.result;
      resolve(db);
    };

    request.onerror = () => {
      console.error('IndexedDB error:', request.error);
      reject('Error opening IndexedDB.');
    };
  });
};

export const storeLargeData = async (data: string): Promise<IDBValidKey> => {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(STORE_NAME, 'readwrite');
    const store = transaction.objectStore(STORE_NAME);
    const request = store.add(data);

    request.onsuccess = () => {
      resolve(request.result);
    };

    request.onerror = () => {
      console.error('Error storing data in IndexedDB:', request.error);
      reject('Failed to store data.');
    };
  });
};

export const getLargeData = async (key: IDBValidKey): Promise<string | null> => {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(STORE_NAME, 'readonly');
    const store = transaction.objectStore(STORE_NAME);
    const request = store.get(key);

    request.onsuccess = () => {
      resolve(request.result || null);
    };

    request.onerror = () => {
      console.error('Error retrieving data from IndexedDB:', request.error);
      reject('Failed to retrieve data.');
    };
  });
};

export const deleteLargeData = async (key: IDBValidKey): Promise<void> => {
    const db = await openDB();
    return new Promise((resolve, reject) => {
        const transaction = db.transaction(STORE_NAME, 'readwrite');
        const store = transaction.objectStore(STORE_NAME);
        const request = store.delete(key);
        
        request.onsuccess = () => {
            resolve();
        };

        request.onerror = () => {
            console.error('Error deleting data from IndexedDB:', request.error);
            reject('Failed to delete data.');
        };
    });
};

export const clearAllLargeData = async (): Promise<void> => {
    const db = await openDB();
    return new Promise((resolve, reject) => {
        const transaction = db.transaction(STORE_NAME, 'readwrite');
        const store = transaction.objectStore(STORE_NAME);
        const request = store.clear();

        request.onsuccess = () => {
            console.log("IndexedDB store cleared successfully.");
            resolve();
        };
        request.onerror = () => {
            console.error('Error clearing IndexedDB store:', request.error);
            reject('Failed to clear data store.');
        };
    });
};

export const saveAppState = async (key: string, value: any): Promise<void> => {
    const db = await openDB();
    return new Promise((resolve, reject) => {
        const transaction = db.transaction(APP_STATE_STORE, 'readwrite');
        const store = transaction.objectStore(APP_STATE_STORE);
        const request = store.put({ key, value });
        request.onsuccess = () => resolve();
        request.onerror = () => {
            console.error(`Error saving app state for key "${key}":`, request.error);
            reject(`Failed to save state for ${key}.`);
        };
    });
};

export const getAppState = async <T>(key: string): Promise<T | null> => {
    const db = await openDB();
    return new Promise((resolve, reject) => {
        const transaction = db.transaction(APP_STATE_STORE, 'readonly');
        const store = transaction.objectStore(APP_STATE_STORE);
        const request = store.get(key);
        request.onsuccess = () => resolve(request.result?.value ?? null);
        request.onerror = () => {
            console.error(`Error retrieving app state for key "${key}":`, request.error);
            reject(`Failed to retrieve state for ${key}.`);
        };
    });
};
