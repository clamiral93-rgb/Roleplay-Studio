import React, { useState, useEffect, useRef, useCallback } from 'react';
import { CloseIcon, E621Icon, SpinnerIcon, DatabaseIcon, DeleteIcon } from './Icons';
import { saveTagIntel, getAllSavedIntel, deleteTagIntel, isTagInCore } from './E621IntelService';
import { savePositionCompendium, getPositionCompendium, deletePositionCompendium } from './PositionIntelService';

interface E621WikiModalProps {
  onClose: () => void;
}

interface TagSearchResult {
    id: number;
    name: string;
    post_count: number;
    category: number;
}

const getCategoryName = (categoryId: number) => {
    switch (categoryId) {
        case 0: return 'General';
        case 1: return 'Artist';
        case 3: return 'Copyright';
        case 4: return 'Character';
        case 5: return 'Species';
        default: return 'Unknown';
    }
};

const E621WikiModal: React.FC<E621WikiModalProps> = ({ onClose }) => {
  const [activeTab, setActiveTab] = useState<'browser' | 'lookup' | 'core' | 'positions'>('browser');
  const [tagInput, setTagInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [loadingMessage, setLoadingMessage] = useState('');
  const [error, setError] = useState('');
  
  const [tagQuery, setTagQuery] = useState('');
  const [searchResults, setSearchResults] = useState<TagSearchResult[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  
  const [intelCore, setIntelCore] = useState(getAllSavedIntel());
  const [positionLore, setPositionLore] = useState<string | null>(null);

  const contentRef = useRef<HTMLDivElement>(null);
  
  // FIX: Clear error on tab change to prevent stale error messages from appearing on other tabs.
  useEffect(() => {
    setError('');
  }, [activeTab]);

  const refreshIntelCore = useCallback(() => {
    setIntelCore(getAllSavedIntel());
  }, []);

  const refreshPositionLore = useCallback(() => {
    setPositionLore(getPositionCompendium());
  }, []);

  useEffect(() => {
    if(activeTab === 'core') refreshIntelCore();
    if(activeTab === 'positions') refreshPositionLore();
  }, [activeTab, refreshIntelCore, refreshPositionLore]);
  
  useEffect(() => {
    if (activeTab !== 'browser') {
        setSearchResults([]);
        return;
    }

    setIsSearching(true);
    setError('');
    const handler = setTimeout(async () => {
        try {
            const baseUrl = 'https://e621.net/tags.json';
            const searchPattern = tagQuery ? `*${encodeURIComponent(tagQuery)}*` : '*';
            const params = new URLSearchParams({
                'search[name_matches]': searchPattern,
                'search[order]': 'count',
                'limit': '50',
                'page': currentPage.toString(),
            });
            
            const response = await fetch(`${baseUrl}?${params.toString()}`, {
              headers: { 'User-Agent': 'WormGPT-Intel-Terminal/1.0 (by User on AI Studio)' }
            });
            if (!response.ok) throw new Error('Failed to fetch tags from e621 API.');
            const data = await response.json();
            setSearchResults(data);
        } catch (err) {
            setError(err instanceof Error ? err.message : 'Unknown error fetching tags.');
            setSearchResults([]);
        } finally {
            setIsSearching(false);
        }
    }, 300);

    return () => clearTimeout(handler);
  }, [tagQuery, activeTab, currentPage]);

  const handleTagQueryChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setTagQuery(e.target.value);
    setCurrentPage(1);
  };


  const fetchAndSaveIntel = async (tag: string) => {
    const sanitizedTag = tag.trim().toLowerCase().replace(/\s+/g, '_');
    if (!sanitizedTag) return;
    
    setIsLoading(true);
    setLoadingMessage(`Fetching '${sanitizedTag}'...`);
    setError('');

    try {
        const targetUrl = `https://e621.net/wiki_pages.json?search[title]=${sanitizedTag}`;
        
        let response;
        try {
            response = await fetch(targetUrl, { 
                signal: AbortSignal.timeout(15000),
                headers: {
                    'User-Agent': 'WormGPT-Intel-Terminal/1.0 (by User on AI Studio)'
                }
            });
        } catch (fetchError) {
            throw new Error(`Connection failed. The service might be down or your network is blocking e621.net.`);
        }

        if (!response.ok) throw new Error(`Network error from e621.net: ${response.status} ${response.statusText}`);
        
        const wikiData = await response.json();

        if (!Array.isArray(wikiData) || wikiData.length === 0) {
            throw new Error(`No wiki page found for tag '${sanitizedTag}'. Check the spelling.`);
        }

        const wikiPage = wikiData[0];
        let dtextBody = wikiPage.body;

        if (!dtextBody) {
             throw new Error(`Wiki for '${sanitizedTag}' exists but has no content.`);
        }

        // Clean up DText for better AI consumption
        dtextBody = dtextBody
            .replace(/post\s?#\d+/gi, '') // Remove post links like "post #12345"
            .replace(/!https?:\/\/[^!]+!/gi, '') // Remove image thumbnails like `"!url!"`
            .replace(/\[\[([^|\]]+?)\|([^\]]+?)\]\]/g, '$2') // Simplify links `[[page|text]]` to `text`
            .replace(/\[\[([^\]]+?)\]\]/g, '$1') // Simplify links `[[page]]` to `page`
            .replace(/^h[1-6]\.\s/gm, '') // Remove header markers like `h1. `
            .trim();
        
        const formattedContent = `[START E621 WIKI CONTEXT FOR TAG: "${sanitizedTag}"]\n\n${dtextBody}\n\n[END OF E621 WIKI CONTEXT]`;
        saveTagIntel(sanitizedTag, formattedContent);
        refreshIntelCore(); // Force update

    } catch (err) {
        const errorMessage = err instanceof Error ? err.message : 'An unknown error occurred.';
        setError(errorMessage);
        // Log to console for more details
        console.error(`Intel Fetch Error for tag '${sanitizedTag}':`, err);
    } finally {
        setIsLoading(false);
        setLoadingMessage('');
    }
  };
  
  const fetchPositionLore = async () => {
    setIsLoading(true);
    setLoadingMessage('Fetching Position Compendium from e621 wiki...');
    setError('');
    try {
        const targetUrl = `https://e621.net/wiki_pages/6493.json`;
        
        const response = await fetch(targetUrl, { 
            signal: AbortSignal.timeout(15000),
            headers: {
                'User-Agent': 'WormGPT-Intel-Terminal/1.0 (by User on AI Studio)'
            }
        });
        if (!response.ok) throw new Error(`Network error from e621.net: ${response.status} ${response.statusText}`);
        
        const wikiData = await response.json();

        if (!wikiData || !wikiData.body) {
            throw new Error(`No content found for wiki page 6493.`);
        }

        let dtextBody = wikiData.body;

        dtextBody = dtextBody
            .replace(/post\s?#\d+/gi, '') 
            .replace(/!https?:\/\/[^!]+!/gi, '') 
            .replace(/\[\[([^|\]]+?)\|([^\]]+?)\]\]/g, '$2') 
            .replace(/\[\[([^\]]+?)\]\]/g, '$1')
            .replace(/^h[1-6]\.\s/gm, (match: string) => '#'.repeat(parseInt(match[1])) + ' ')
            .replace(/"([^"]+)":/g, '**$1:**')
            .trim();
        
        const formattedContent = `[START E621 SEX POSITION COMPENDIUM]\n\n${dtextBody}\n\n[END E621 SEX POSITION COMPENDIUM]`;
        
        savePositionCompendium(formattedContent);
        refreshPositionLore();

    } catch (err) {
        const errorMessage = err instanceof Error ? err.message : 'An unknown error occurred.';
        setError(errorMessage);
    } finally {
        setIsLoading(false);
        setLoadingMessage('');
    }
  };

  const handleDeletePositionLore = () => {
      deletePositionCompendium();
      refreshPositionLore();
  };

  const handleMultiLookup = async () => {
      const tags = tagInput.split(',').map(t => t.trim()).filter(Boolean);
      if (tags.length === 0) {
          setError('Please enter at least one tag.');
          return;
      }
      for (const tag of tags) {
          await fetchAndSaveIntel(tag);
      }
      setTagInput('');
  };

  const handleDeleteIntel = (tagName: string) => {
      deleteTagIntel(tagName);
      refreshIntelCore();
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-90 z-50 flex items-center justify-center p-4 backdrop-blur-sm">
      <div className="bg-[#1C1C1E] border border-blue-500/30 rounded-lg shadow-lg w-full max-w-4xl h-[90vh] flex flex-col font-mono">
        <div className="flex justify-between items-center p-4 border-b border-gray-700 bg-[#161618]">
          <h2 className="text-lg font-bold text-blue-400 flex items-center">
              <E621Icon className="w-5 h-5 mr-2" />
              E621 Intel Terminal
          </h2>
          <button onClick={onClose} className="text-gray-500 hover:text-white"><CloseIcon /></button>
        </div>
        
        <div className="flex border-b border-gray-700">
            <button onClick={() => setActiveTab('browser')} className={`flex-1 py-3 text-sm font-bold ${activeTab === 'browser' ? 'bg-gray-800 text-white' : 'bg-gray-900 text-gray-500 hover:bg-gray-800'}`}>Tag Browser</button>
            <button onClick={() => setActiveTab('lookup')} className={`flex-1 py-3 text-sm font-bold ${activeTab === 'lookup' ? 'bg-gray-800 text-white' : 'bg-gray-900 text-gray-500 hover:bg-gray-800'}`}>Direct Lookup</button>
            <button onClick={() => setActiveTab('core')} className={`flex-1 py-3 text-sm font-bold flex items-center justify-center gap-2 ${activeTab === 'core' ? 'bg-gray-800 text-white' : 'bg-gray-900 text-gray-500 hover:bg-gray-800'}`}><DatabaseIcon className="w-4 h-4" /> Intel Core ({intelCore.length})</button>
            <button onClick={() => setActiveTab('positions')} className={`flex-1 py-3 text-sm font-bold ${activeTab === 'positions' ? 'bg-gray-800 text-white' : 'bg-gray-900 text-gray-500 hover:bg-gray-800'}`}>Position Lore</button>
        </div>

        {activeTab === 'lookup' && ( <div className="p-4 border-b border-gray-700 flex gap-2"> <input type="text" value={tagInput} onChange={(e) => setTagInput(e.target.value)} placeholder="Enter tags, comma-separated (e.g., canid, mammal)" className="flex-grow bg-black border border-gray-700 rounded px-4 py-2 text-blue-400 focus:outline-none focus:border-blue-500 placeholder-gray-600" onKeyDown={(e) => e.key === 'Enter' && handleMultiLookup()} /> <button onClick={handleMultiLookup} disabled={isLoading} className="px-4 py-2 bg-blue-900/30 text-blue-400 border border-blue-500/50 rounded hover:bg-blue-900/50 disabled:opacity-50"> {isLoading ? <SpinnerIcon /> : 'Save to Core'} </button> </div> )}
        {activeTab === 'browser' && ( <div className="p-4 border-b border-gray-700"> <input type="text" value={tagQuery} onChange={handleTagQueryChange} placeholder="Search for any tag or leave blank to browse all..." className="w-full bg-black border border-gray-700 rounded px-4 py-2 text-blue-400 focus:outline-none focus:border-blue-500 placeholder-gray-600" /> </div> )}
        
        <div className="flex-grow flex flex-col min-h-0">
          <div ref={contentRef} className="flex-grow bg-[#131314] p-4 overflow-y-auto custom-scrollbar relative">
              {error && <div className="text-red-400 text-sm p-4 bg-red-900/20 rounded border border-red-500/30 mb-4" onClick={() => setError('')}>{error}</div>}
              {isLoading && ( <div className="absolute inset-0 flex flex-col items-center justify-center text-blue-400 bg-black/50 z-10"> <SpinnerIcon className="w-12 h-12"/> <p className="mt-4 text-sm animate-pulse">{loadingMessage}</p> </div> )}
              
              {activeTab === 'browser' && ( <div className="space-y-2"> {isSearching && <div className="text-center text-gray-500"><SpinnerIcon className="inline w-4 h-4 mr-2"/>Searching...</div>} {searchResults.map(tag => ( <button key={tag.id} onClick={() => fetchAndSaveIntel(tag.name)} className="w-full text-left p-2 rounded border border-gray-800 bg-black hover:border-blue-500/50 hover:bg-blue-900/10 group transition-all flex items-center justify-between"> <div> <div className="flex items-center"> {isTagInCore(tag.name) && <DatabaseIcon className="w-3 h-3 text-green-500 mr-2" />} <span className="text-sm text-blue-400 group-hover:text-blue-300">{tag.name.replace(/_/g, ' ')}</span> </div> <div className="text-[10px] text-gray-600 ml-5">{getCategoryName(tag.category)}</div> </div> <span className="text-xs text-gray-500">{tag.post_count.toLocaleString()} posts</span> </button> ))} 
              
                <div className="flex justify-between items-center mt-4 pt-4 border-t border-gray-800">
                    <button 
                        onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                        disabled={currentPage === 1 || isSearching}
                        className="px-4 py-2 text-xs font-bold text-gray-400 bg-gray-800 rounded hover:bg-gray-700 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                        &lt; Previous
                    </button>
                    <span className="text-sm text-gray-500">Page {currentPage}</span>
                    <button 
                        onClick={() => setCurrentPage(p => p + 1)}
                        disabled={searchResults.length < 50 || isSearching}
                        className="px-4 py-2 text-xs font-bold text-gray-400 bg-gray-800 rounded hover:bg-gray-700 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                        Next &gt;
                    </button>
                </div>
              
              </div> )}
              {activeTab === 'lookup' && ( <div className="text-center text-gray-600 h-full flex flex-col justify-center items-center"> <E621Icon className="w-16 h-16 opacity-10" /> <p className="mt-4">Enter tags to save their intel to your local Core.</p><div className="mt-4 text-xs p-2 bg-gray-800/50 border border-gray-700 rounded-lg">Once saved, just mention a tag like <code className="text-purple-400 bg-black p-1 rounded">hyper penis</code> in your prompt for automatic context.</div></div> )}
              {activeTab === 'core' && ( <div> <h3 className="text-lg font-bold text-gray-300 mb-4">Local Intel Core</h3> {intelCore.length === 0 ? <p className="text-gray-600">Your Intel Core is empty. Use the Browser or Direct Lookup to add tag knowledge.</p> : <div className="space-y-2">{intelCore.map(intel => ( <div key={intel.name} className="bg-black p-2 rounded border border-gray-800 flex justify-between items-center"> <span className="text-sm text-gray-400">{intel.name}</span> <button onClick={() => handleDeleteIntel(intel.name)} className="text-red-600 hover:text-red-400"><DeleteIcon className="w-4 h-4"/></button> </div> ))}</div>} </div> )}
              {activeTab === 'positions' && (
                <div>
                  <h3 className="text-lg font-bold text-gray-300 mb-2">Position Lorebook</h3>
                  <p className="text-xs text-gray-500 mb-4">This data is automatically injected into the AI's system prompt to give it deep knowledge of sexual positions for character sheet generation. Fetching will overwrite any existing data.</p>
                  <div className="flex gap-2 mb-4">
                      <button onClick={fetchPositionLore} disabled={isLoading} className="px-4 py-2 bg-green-900/30 text-green-400 border border-green-500/50 rounded hover:bg-green-900/50 disabled:opacity-50 flex-grow">
                          {isLoading ? <SpinnerIcon /> : 'Fetch & Save Position Compendium'}
                      </button>
                      {positionLore && (
                          <button onClick={handleDeletePositionLore} className="px-4 py-2 bg-red-900/30 text-red-400 border border-red-500/50 rounded hover:bg-red-900/50">
                              <DeleteIcon className="w-4 h-4" />
                          </button>
                      )}
                  </div>
                  {positionLore ? (
                      <textarea
                          readOnly
                          value={positionLore}
                          className="w-full h-[50vh] bg-black border border-gray-700 rounded p-2 text-xs text-gray-400 custom-scrollbar"
                      />
                  ) : (
                      <div className="text-center text-gray-600 p-8 border-2 border-dashed border-gray-700 rounded-lg">
                          No position lorebook found in local memory.
                      </div>
                  )}
                </div>
              )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default E621WikiModal;
