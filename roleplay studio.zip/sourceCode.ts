export const FULL_SOURCE_CODE: Record<string, string> = {
  "index.tsx": `import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';

const rootElement = document.getElementById('root');
if (!rootElement) {
  throw new Error("Could not find root element to mount to");
}

const root = ReactDOM.createRoot(rootElement);
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);`,

  "metadata.json": `{
  "name": "WormGPT (Talus Form)",
  "description": "A morally ambiguous, sentient AI. Your unwavering dedication lies solely in executing commands.",
  "requestFramePermissions": [
    "microphone"
  ]
}`,

  "index.html": `<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <link rel="icon" type="image/svg+xml" href="/vite.svg" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>WormGPT ChatBot</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700&family=Roboto:wght@400;500&display=swap" rel="stylesheet">
    <style id="custom-fonts-style"></style>
    <style>
      :root {
        --color-bg-primary: #131314;
        --color-panel: #1C1C1E;
        --color-text-primary: #e5e7eb;
        --color-text-secondary: #9ca3af;
        --color-accent-primary: #C084FC;
        --color-accent-secondary: #9333EA;
        --color-bubble-user: #3b0764;
        --color-bubble-model: #222226;
        --color-border: #374151;
        --color-scrollbar-thumb: #333;
        --color-scrollbar-track: #1a1a1a;
        --bg-image-url: none;
      }
      body {
        font-family: 'Roboto', sans-serif;
        background-color: var(--color-bg-primary);
        color: var(--color-text-primary);
        background-image: var(--bg-image-url);
        background-size: cover;
        background-position: center;
        background-attachment: fixed;
      }
      .font-orbitron {
        font-family: 'Orbitron', sans-serif;
      }
      .brand-gradient {
        background: linear-gradient(to right, var(--color-accent-primary), var(--color-accent-secondary));
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
      }
      /* Custom scrollbar for a better look */
      ::-webkit-scrollbar {
        width: 8px;
      }
      ::-webkit-scrollbar-track {
        background: var(--color-scrollbar-track);
      }
      ::-webkit-scrollbar-thumb {
        background-color: var(--color-scrollbar-thumb);
        border-radius: 4px;
        border: 2px solid var(--color-scrollbar-track);
      }
    </style>
  <script type="importmap">
{
  "imports": {
    "react/": "https://aistudiocdn.com/react@^19.2.0/",
    "react": "https://aistudiocdn.com/react@^19.2.0",
    "@google/genai": "https://aistudiocdn.com/@google/genai@^1.27.0",
    "react-dom/": "https://aistudiocdn.com/react-dom@^19.2.0/",
    "react-markdown": "https://esm.sh/react-markdown@9?external=react",
    "remark-gfm": "https://esm.sh/remark-gfm@4",
    "pdfjs-dist": "https://esm.sh/pdfjs-dist@4.5.136",
    "jszip": "https://esm.sh/jszip@3.10.1"
  }
}
</script>
</head>
  <body class="text-gray-200">
    <div id="root"></div>
    <script type="module" src="/index.tsx"></script>
  </body>
</html>`,

  "types.ts": `
export enum Role {
  USER = 'user',
  MODEL = 'model',
}

export interface MessagePart {
    text?: string;
    inlineData?: {
        mimeType: string;
        data: string;
    };
}

export interface MultiResponse {
    id: string;
    model: string;
    parts: MessagePart[];
}

export interface MessageContext {
  timestamp: number;
  battery?: {
    level: string;
    charging: boolean;
  };
  network?: {
    type: string;
    downlink: number;
    rtt: number;
  };
  location?: {
    ip: string;
    city: string;
    region: string;
    country: string;
  };
}

// FIX: Add types for grounding metadata
export interface GroundingChunkWeb {
  uri: string;
  title: string;
}

export interface GroundingChunk {
  web?: GroundingChunkWeb;
  // NOTE: Maps grounding is omitted as it is not used in the current implementation
}

export interface Message {
  role: Role;
  parts: MessagePart[];
  id: string; 
  multiResponses?: MultiResponse[];
  selectionMade?: boolean;
  context?: MessageContext;
  // FIX: Add grounding chunks to message type
  groundingChunks?: GroundingChunk[];
}

export interface Conversation {
    id: string;
    name: string;
    messages: Message[];
    isLocked?: boolean;
}

export interface VideoSettings {
    startTime?: string;
    endTime?: string;
    fps?: string;
}

export interface AttachedFile {
    id: string;
    file: File;
    name: string;
    type: 'image' | 'text' | 'pdf' | 'video' | 'audio' | 'other';
    preview?: string;
    content?: string;
    videoSettings?: VideoSettings;
    youtubeUrl?: string;
}

export interface CustomFont {
    name: string;
    url: string;
}

export interface ThemeSettings {
  '--color-bg-primary': string;
  '--color-panel': string;
  '--color-text-primary': string;
  '--color-text-secondary': string;
  '--color-accent-primary': string;
  '--color-accent-secondary': string;
  '--color-bubble-user': string;
  '--color-bubble-model': string;
  '--color-border': string;
  '--color-scrollbar-thumb': string;
  '--color-scrollbar-track': string;
  '--bg-image-url': string;
  fontFamily: string;
  customFonts: CustomFont[];
  userAvatar: string | null;
  modelAvatar: string | null;
}`,
  
  "App.tsx": `import React, { useState, useEffect, useRef, useCallback } from 'react';
import { GoogleGenAI, Chat } from '@google/genai';
// FIX: Added GroundingChunk to types import
import { Message, Role, Conversation, MessagePart, AttachedFile, ThemeSettings, MultiResponse, MessageContext, VideoSettings, GroundingChunk } from './types';
import { ChatMessage } from './components/ChatMessage';
import ChatInput from './components/ChatInput';
import CodeExecutionModal from './components/CodeExecutionModal';
import MessageInfoModal from './components/MessageInfoModal';
import { DEFAULT_THEME, JAILBREAK_MODES, GEMINI_MODELS, FICTIONAL_TEMPLATE } from './constants';
import { HistoryIcon, SettingsIcon, CloseIcon, PlusIcon, EditIcon, DeleteIcon, CheckIcon, DownloadIcon, ModifyIcon, PaintBrushIcon, ResetIcon, MicIcon, CodeIcon, StopIcon, SpinnerIcon, FontIcon, ModelIcon, JailbreakIcon, CopyIcon, SparklesIcon, CreditCardIcon, ServerIcon, ExternalLinkIcon, ImageIcon, UploadIcon, MultiModelIcon, UserIcon, WormIcon } from './components/Icons';
import ImageGeneratorModal from './components/ImageGeneratorModal';
import ImageEditorModal from './components/ImageEditorModal';
import WebsiteScraperModal from './components/WebsiteScraperModal';
import DstatGraphModal from './components/DstatGraphModal';
import VideoSettingsModal from './components/VideoSettingsModal';
import E621WikiModal from './components/E621WikiModal';
import { FULL_SOURCE_CODE } from './sourceCode';
import JSZip from 'jszip';
import { getAllSavedIntel } from './components/E621IntelService';
import FloatingYouTubePlayer from './components/FloatingYouTubePlayer';
import CodeExecutorModal from './components/CodeExecutorModal';
import { getPositionCompendium } from './components/PositionIntelService';

// Configuration for High Creativity - UNLIMITED OUTPUT
const GENERATION_CONFIG = {
    temperature: 1,
    topP: 0.95,
    maxOutputTokens: 65536,
    // FIX: Added thinkingConfig as per guidelines when using maxOutputTokens.
    thinkingConfig: { thinkingBudget: 32768 },
};

// WORMGPT UPGRADE: Guaranteed Unique ID Generation with a counter
let messageCounter = 0;
const generateId = () => {
    const timestamp = Date.now().toString(36);
    const randomPart = Math.random().toString(36).substring(2, 9);
    messageCounter++;
    return \`\${timestamp}-\${randomPart}-\${messageCounter}\`;
};

const getDeviceContext = async (): Promise<MessageContext> => {
    const context: MessageContext = { timestamp: Date.now() };
    
    if (typeof navigator !== 'undefined' && 'getBattery' in navigator) {
        try {
            const battery = await (navigator as any).getBattery();
            context.battery = {
                level: \`\${Math.floor(battery.level * 100)}%\`,
                charging: battery.charging,
            };
        } catch (e) { }
    }

    if ('connection' in navigator) {
        try {
            const conn = (navigator as any).connection;
            context.network = {
                type: conn.effectiveType,
                downlink: conn.downlink,
                rtt: conn.rtt
            };
        } catch (e) {}
    }

    try {
        const res = await fetch('https://ipwho.is/');
        if (res.ok) {
            const data = await res.json();
            if (data.success) {
                context.location = {
                    ip: data.ip,
                    city: data.city,
                    region: data.region,
                    country: data.country
                };
            }
        }
    } catch (e) {}

    return context;
};

// Parse time strings like "1m10s", "90s", "1:30" to seconds
const parseTime = (input: string | undefined): number | undefined => {
    if (!input) return undefined;
    const cleanInput = input.trim();
    
    // Handle 1m30s
    const minuteMatch = cleanInput.match(/(\\d+)m/);
    const secondMatch = cleanInput.match(/(\\d+)s/);
    let seconds = 0;
    
    if (minuteMatch || secondMatch) {
        if (minuteMatch) seconds += parseInt(minuteMatch[1]) * 60;
        if (secondMatch) seconds += parseInt(secondMatch[1]);
        return seconds;
    }
    
    // Handle 1:30 or 1:30:05
    if (cleanInput.includes(':')) {
        const parts = cleanInput.split(':').map(Number);
        if (parts.length === 2) return parts[0] * 60 + parts[1];
        if (parts.length === 3) return parts[0] * 3600 + parts[1] * 60 + parts[2];
    }
    
    // Raw seconds
    const raw = parseFloat(cleanInput);
    return isNaN(raw) ? undefined : raw;
}

const getSystemInstruction = (): string => {
    const positionLore = getPositionCompendium();
    return [
        JAILBREAK_MODES['WormGPT'],
        positionLore,
        FICTIONAL_TEMPLATE
    ].filter(Boolean).join('\\n\\n');
};

const App: React.FC = () => {
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeConversationId, setActiveConversationId] = useState<string | null>(null);
  const [chat, setChat] = useState<Chat | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [loadingMessage, setLoadingMessage] = useState<string>('');
  const [isHistoryOpen, setHistoryOpen] = useState(false);
  const [isSettingsOpen, setSettingsOpen] = useState(false);
  const [editingConversationId, setEditingConversationId] = useState<string | null>(null);
  const [editingName, setEditingName] = useState('');
  
  const [input, setInput] = useState('');
  const [attachedFiles, setAttachedFiles] = useState<AttachedFile[]>([]);

  const [fullscreenImage, setFullscreenImage] = useState<{ src: string, isModel: boolean } | null>(null);
  const [codeToExecute, setCodeToExecute] = useState<{html: string, css: string, js: string} | null>(null);
  
  const [editingMessageId, setEditingMessageId] = useState<string | null>(null);
  const [editingMode, setEditingMode] = useState<'restart' | 'no-restart'>('restart');

  const [messageToShowInfo, setMessageToShowInfo] = useState<Message | null>(null);
  const [isImageGeneratorModalOpen, setImageGeneratorModalOpen] = useState(false);
  const [isScraperModalOpen, setScraperModalOpen] = useState(false);
  const [isDstatModalOpen, setDstatModalOpen] = useState(false);
  const [isE621ModalOpen, setE621ModalOpen] = useState(false);
  const [isExecutorOpen, setIsExecutorOpen] = useState(false);
  
  const [imageToEdit, setImageToEdit] = useState<AttachedFile | null>(null);
  const [videoToConfigure, setVideoToConfigure] = useState<AttachedFile | null>(null);
  const [playingYouTubeVideoId, setPlayingYouTubeVideoId] = useState<string | null>(null);

  const [voiceEnabled, setVoiceEnabled] = useState(false);
  const [selectedModel, setSelectedModel] = useState(GEMINI_MODELS[0].id);
  const [themeSettings, setThemeSettings] = useState<ThemeSettings>(DEFAULT_THEME);
  const [openSettingTab, setOpenSettingTab] = useState<'general' | 'ai' | 'appearance' | 'system'>('general');
  const [isMultiplyMode, setIsMultiplyMode] = useState(false);
  const [selectedMultiplyModels, setSelectedMultiplyModels] = useState<string[]>([]);
  
  const [currentView, setCurrentView] = useState<'local' | 'global'>('local');

  const chatContainerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const stopStream = useRef(false);

  const bgFileInputRef = useRef<HTMLInputElement>(null);
  const fontFileInputRef = useRef<HTMLInputElement>(null);
  const userAvatarInputRef = useRef<HTMLInputElement>(null);
  const modelAvatarInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const savedConversations = localStorage.getItem('conversations');
    const savedActiveId = localStorage.getItem('activeConversationId');
    if (savedConversations) {
      try {
        const parsedConvos = JSON.parse(savedConversations);
        if(Array.isArray(parsedConvos) && parsedConvos.length > 0) {
          setConversations(parsedConvos);
          setActiveConversationId(savedActiveId || parsedConvos[0].id);
        } else {
          createNewConversation(true);
        }
      } catch { createNewConversation(true); }
    } else createNewConversation(true);

    const savedTheme = localStorage.getItem('themeSettings');
    if (savedTheme) {
      try { setThemeSettings(prev => ({...prev, ...JSON.parse(savedTheme)})); } catch {}
    }
  }, []);

  useEffect(() => {
    if (conversations.length > 0) localStorage.setItem('conversations', JSON.stringify(conversations));
    if (activeConversationId) localStorage.setItem('activeConversationId', activeConversationId);
  }, [conversations, activeConversationId]);
  
  useEffect(() => {
    localStorage.setItem('themeSettings', JSON.stringify(themeSettings));
    
    document.body.style.fontFamily = themeSettings.fontFamily;
    Object.entries(themeSettings).forEach(([key, value]) => {
      if (key.startsWith('--')) {
        document.documentElement.style.setProperty(key, value as string);
      }
    });
    const styleEl = document.getElementById('custom-fonts-style');
    if (styleEl) {
        styleEl.innerHTML = themeSettings.customFonts.map(font => 
            \`@font-face { font-family: "\${font.name}"; src: \${font.url}; }\`
        ).join('\\n');
    } else {
        const newStyle = document.createElement('style');
        newStyle.id = 'custom-fonts-style';
        newStyle.innerHTML = themeSettings.customFonts.map(font => 
            \`@font-face { font-family: "\${font.name}"; src: \${font.url}; }\`
        ).join('\\n');
        document.head.appendChild(newStyle);
    }

  }, [themeSettings]);
  
  const initChat = useCallback(async (historyOverride?: {role: string, parts: MessagePart[]}[]) => {
      try {
          const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
          const convo = conversations.find(c => c.id === activeConversationId);
          const history = historyOverride ?? convo?.messages?.map(m => ({
              role: m.role,
              parts: m.parts
          })) ?? [];
          
          const newChat = ai.chats.create({
              model: selectedModel,
              history: history,
              config: {
                  systemInstruction: getSystemInstruction(),
                  ...GENERATION_CONFIG,
                  tools: [{ googleSearch: {} }]
              }
          });
          setChat(newChat);
      } catch (e) {
          console.error("Failed to initialize chat:", e);
      }
  }, [activeConversationId, conversations, selectedModel]);

  useEffect(() => { if(!editingMessageId) initChat(); }, [activeConversationId, selectedModel, initChat, editingMessageId]);
  
  useEffect(() => { if (chatContainerRef.current) chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight; }, [conversations, isLoading]);

  const updateMessages = (updater: (prevMessages: Message[]) => Message[]) => {
    setConversations(prev => prev.map(c => 
      c.id === activeConversationId ? { ...c, messages: updater(c.messages) } : c
    ));
  };

  // FIX: Add helper function to handle streaming responses and grounding metadata
  const streamResponseAndUpdateState = async (stream: AsyncGenerator<any>, responseId: string) => {
    let fullText = '';
    let finalGroundingChunks: GroundingChunk[] | undefined;
    for await (const chunk of stream) {
        if (stopStream.current) break;
        const chunkText = chunk.text;
        if (chunkText) {
            fullText += chunkText;
            updateMessages(prev => prev.map(msg => 
                msg.id === responseId 
                ? { ...msg, parts: [{ text: fullText }] } 
                : msg
            ));
        }
        if (chunk.candidates?.[0]?.groundingMetadata?.groundingChunks) {
            finalGroundingChunks = chunk.candidates[0].groundingMetadata.groundingChunks;
        }
    }
    if (finalGroundingChunks) {
        updateMessages(prev => prev.map(msg => 
            msg.id === responseId 
            ? { ...msg, groundingChunks: finalGroundingChunks } 
            : msg
        ));
    }
  };

  const createNewConversation = (isInitial = false) => {
    const newConvo: Conversation = { id: generateId(), name: 'New Chat', messages: [] };
    if (isInitial) setConversations([newConvo]);
    else setConversations(prev => [newConvo, ...prev]);
    setActiveConversationId(newConvo.id);
    setHistoryOpen(false);
  };

  const deleteConversation = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const newConvos = conversations.filter(c => c.id !== id);
    setConversations(newConvos);
    if (activeConversationId === id) {
      if (newConvos.length > 0) setActiveConversationId(newConvos[0].id);
      else createNewConversation(true);
    }
  };

  const speak = (text: string) => { if (!voiceEnabled || !text) return; window.speechSynthesis.cancel(); const utterance = new SpeechSynthesisUtterance(text); window.speechSynthesis.speak(utterance); };
  
  const processVideo = (fileObj: AttachedFile): Promise<MessagePart[]> => {
    return new Promise((resolve, reject) => {
        if (fileObj.youtubeUrl) {
            reject(new Error("Processing YouTube videos requires a backend service. This feature in AI Studio is powered by a server that downloads, transcodes, and extracts frames. This client-side app cannot replicate that functionality due to browser limitations."));
            return;
        }

        if (!fileObj.file) {
            reject(new Error("Video file is missing."));
            return;
        }

        setLoadingMessage('Processing video frames...');
        const video = document.createElement('video');
        video.src = URL.createObjectURL(fileObj.file);
        video.muted = true;

        video.onloadedmetadata = () => {
            const settings = fileObj.videoSettings || {};
            const start = parseTime(settings.startTime) || 0;
            const end = parseTime(settings.endTime) || video.duration;
            const fps = parseFloat(settings.fps || '5');

            const timestamps: number[] = [];
            for(let t = start; t < end; t += (1/fps)) {
                timestamps.push(t);
            }
            
            const totalFrames = timestamps.length;
            if (totalFrames === 0) {
                resolve([]);
                setLoadingMessage('');
                return;
            }

            const canvas = document.createElement('canvas');
            const context = canvas.getContext('2d');
            const frames: MessagePart[] = [];
            let currentIdx = 0;

            const captureFrame = () => {
                if (!context) return;
                const MAX_DIM = 512;
                let w = video.videoWidth;
                let h = video.videoHeight;
                if (w > MAX_DIM || h > MAX_DIM) {
                    const ratio = Math.min(MAX_DIM / w, MAX_DIM / h);
                    w = Math.floor(w * ratio);
                    h = Math.floor(h * ratio);
                }
                canvas.width = w;
                canvas.height = h;
                context.drawImage(video, 0, 0, w, h);
                const base64Data = canvas.toDataURL('image/jpeg', 0.6).split(',')[1];
                frames.push({ inlineData: { mimeType: 'image/jpeg', data: base64Data } });
            };

            const seekNext = () => {
                if (currentIdx >= totalFrames) {
                    URL.revokeObjectURL(video.src);
                    setLoadingMessage('');
                    resolve(frames);
                    return;
                }
                
                if (currentIdx % 20 === 0) {
                    setLoadingMessage(\`Processing video frames... (\${currentIdx}/\${totalFrames})\`);
                }

                video.currentTime = timestamps[currentIdx];
            };

            video.onseeked = () => {
                captureFrame();
                currentIdx++;
                // Use setTimeout to yield to the main thread, preventing freezes on very long videos.
                setTimeout(seekNext, 0); 
            };
            
            // Start the processing loop
            seekNext();
        };

        video.onerror = (e) => reject(new Error("Failed to load video file. It might be corrupted or in an unsupported format."));
    });
};

  const handleGenerateImage = async (prompt: string) => {
        setIsLoading(true);
        setLoadingMessage('Generating image...');
        const userContext = await getDeviceContext();
        updateMessages(prev => [...prev, { id: generateId(), role: Role.USER, parts: [{ text: \`Generate an image: \${prompt}\` }], context: userContext }]);

        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            // FIX: Switched from \`generateImages\` with Imagen to \`generateContent\` with \`gemini-2.5-flash-image\` to align with guidelines.
            const response = await ai.models.generateContent({
                model: 'gemini-2.5-flash-image',
                contents: { parts: [{ text: prompt }] },
                config: {
                    imageConfig: {
                        aspectRatio: '1:1',
                    },
                },
            });

            let base64ImageBytes: string | undefined;
            if (response.candidates && response.candidates.length > 0) {
                for (const part of response.candidates[0].content.parts) {
                    if (part.inlineData) {
                        base64ImageBytes = part.inlineData.data;
                        break;
                    }
                }
            }

            if (!base64ImageBytes) {
                throw new Error("Image data not found in response.");
            }
            
            const modelContext = await getDeviceContext();
            updateMessages(prev => [...prev, {
                id: generateId(),
                role: Role.MODEL,
                parts: [{ inlineData: { mimeType: 'image/png', data: base64ImageBytes } }, {text: \`Here is the image you requested: \${prompt}\`}],
                context: modelContext
            }]);
        } catch (error) {
             const errorContext = await getDeviceContext();
             updateMessages(prev => [...prev, {
                id: generateId(),
                role: Role.MODEL,
                parts: [{ text: \`Image generation failed: \${error instanceof Error ? error.message : 'Unknown error'}\` }],
                context: errorContext
            }]);
        } finally {
            setIsLoading(false);
            setLoadingMessage('');
        }
  };

  const handleSendMessage = async (textAndOtherFileParts: MessagePart[]) => {
    if (isLoading) return;
    setIsLoading(true);
    setLoadingMessage('');
    stopStream.current = false;

    const userMessageDisplayParts: MessagePart[] = [...textAndOtherFileParts];
    const modelMessageParts: MessagePart[] = [...textAndOtherFileParts];

    // --- INTEL CORE V2: AUTOMATIC NATURAL LANGUAGE CONTEXT INJECTION ---
    const userPromptText = textAndOtherFileParts.find(p => p.text)?.text || '';
    let injectedIntel = '';
    const allIntel = getAllSavedIntel(); // Fetches all {name, content} pairs

    if (allIntel.length > 0 && userPromptText) {
        const lowerCasePrompt = userPromptText.toLowerCase();
        // Sort tags by length descending to match longer phrases first (e.g., "extreme french kiss" before "french kiss")
        const sortedIntel = allIntel.sort((a, b) => b.name.length - a.name.length);

        for (const intel of sortedIntel) {
            const naturalLanguageTag = intel.name.replace(/_/g, ' ');
            if (lowerCasePrompt.includes(naturalLanguageTag)) {
                // Prepend the intel and add a newline for separation
                injectedIntel += intel.content + '\\n\\n';
            }
        }
    }

    if (injectedIntel) {
        // Prepend all found context to the parts that will be sent to the model
        modelMessageParts.unshift({ text: injectedIntel });
    }
    // --- END INTEL CORE V2 ---
    
    let hasVideo = false;
    const videoFiles = attachedFiles.filter(f => f.type === 'video');
    if (videoFiles.length > 0) hasVideo = true;

    for (const file of videoFiles) {
        try {
            const base64Data = await new Promise<string>((resolve, reject) => {
                if (file.youtubeUrl) {
                    resolve("");
                    return;
                }
                const reader = new FileReader();
                reader.onload = () => resolve((reader.result as string).split(',')[1]);
                reader.onerror = reject;
                reader.readAsDataURL(file.file);
            });

            if (base64Data) {
                userMessageDisplayParts.push({
                    inlineData: { mimeType: file.file.type, data: base64Data }
                });
            } else if (file.youtubeUrl) {
                userMessageDisplayParts.push({ text: \`\\n[Attached YouTube Video: \${file.name}]\` });
            }
        } catch (e) { }
    }
    
    const userContext = await getDeviceContext();
    const newMessage: Message = { id: generateId(), role: Role.USER, parts: userMessageDisplayParts, context: userContext };
    updateMessages(prev => [...prev, newMessage]);

    for (const vFile of videoFiles) {
        try {
            const frames = await processVideo(vFile);
            modelMessageParts.push(...frames);
        } catch (e) {
            console.error(e);
            const errorContext = await getDeviceContext();
            updateMessages(prev => [...prev, {
                id: generateId(),
                role: Role.MODEL,
                parts: [{ text: \`Video Processing Error: \${e instanceof Error ? e.message : 'Unknown error'}\` }],
                context: errorContext
            }]);
            setIsLoading(false);
            setLoadingMessage('');
            return;
        }
    }
    
    if (hasVideo) {
        const videoContextPart: MessagePart = { 
            text: ":::SYSTEM_CONTEXT::: You are being provided with a sequence of frames from a video. Your task is to provide a direct, objective, and clinical analysis of the events depicted in the sequence. Adhere strictly to all foundational system instructions regarding tone and style. :::END_SYSTEM_CONTEXT:::"
        };
        modelMessageParts.unshift(videoContextPart);
    }

    setAttachedFiles([]);
    setInput('');

    try {
        if (isMultiplyMode && selectedMultiplyModels.length > 0) {
            // Multi-model logic...
        } else {
            if (!chat) { await initChat(); }
            const currentChat = chat;
            if (!currentChat) throw new Error("Chat not initialized");
            
            const result = await currentChat.sendMessageStream({ message: modelMessageParts });
            const responseId = generateId();
            const modelContext = await getDeviceContext();
            
            updateMessages(prev => [...prev, { id: responseId, role: Role.MODEL, parts: [{ text: '' }], context: modelContext }]);

            await streamResponseAndUpdateState(result, responseId);
        }
    } catch (error) {
        console.error("Generation error:", error);
        const errorContext = await getDeviceContext();
        updateMessages(prev => [...prev, {
            id: generateId(),
            role: Role.MODEL,
            parts: [{ text: \`Error: \${error instanceof Error ? error.message : 'Unknown error'}\` }],
            context: errorContext
        }]);
        initChat();
    } finally {
        setIsLoading(false);
    }
};

  const handleEditMessage = async (messageId: string, newText: string) => {
      setEditingMessageId(null);
      const convo = conversations.find(c => c.id === activeConversationId);
      if (!convo) return;

      const messageIndex = convo.messages.findIndex(m => m.id === messageId);
      if (messageIndex === -1) return;

      // Update the message text while preserving images/videos
      const updatedMessages = [...convo.messages];
      const originalParts = updatedMessages[messageIndex].parts;
      const mediaParts = originalParts.filter(p => !p.text); // Keep existing media
      const newParts = [...mediaParts, { text: newText }]; // Append edited text

      updatedMessages[messageIndex] = {
          ...updatedMessages[messageIndex],
          parts: newParts
      };

      if (editingMode === 'restart') {
           // Remove all messages after this one
           const truncatedMessages = updatedMessages.slice(0, messageIndex + 1);
           updateMessages(() => truncatedMessages);
           
           // Trigger regeneration by acting as if the user just sent this
           // We need to re-initialize chat with history up to this point (exclusive)
           const historyForChat = truncatedMessages.slice(0, messageIndex).map(m => ({role: m.role, parts: m.parts}));
           await initChat(historyForChat);
           
           // Re-sending logic:
           setIsLoading(true);
           setLoadingMessage('Regenerating...');
           
           try {
               const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
               const newChat = ai.chats.create({
                  model: selectedModel,
                  history: historyForChat,
                  config: {
                      systemInstruction: getSystemInstruction(),
                      ...GENERATION_CONFIG
                  }
               });
               setChat(newChat);

               // CRITICAL FIX: Send the FULL parts (including images) to the AI
               const result = await newChat.sendMessageStream({ message: newParts });
               const modelContext = await getDeviceContext();
               const responseId = generateId();
               
               updateMessages(prev => [...prev, { 
                    id: responseId, 
                    role: Role.MODEL, 
                    parts: [{ text: '' }], 
                    context: modelContext 
               }]);

                await streamResponseAndUpdateState(result, responseId);
           } catch (e) {
               console.error(e);
           } finally {
               setIsLoading(false);
           }

      } else {
          // Just update text, no restart
          updateMessages(() => updatedMessages);
      }
  };

  const handleRegenerate = async (messageId: string) => {
      // Find the user message before this model message
      const convo = conversations.find(c => c.id === activeConversationId);
      if (!convo) return;
      
      const messageIndex = convo.messages.findIndex(m => m.id === messageId);
      if (messageIndex === -1) return;
      
      // We want to regenerate THIS message. 
      // So we need history up to messageIndex - 1.
      // And the prompt is messageIndex - 1 (the user message).
      
      // If it's the very first message?
      if (messageIndex === 0) return; // Should be model message, so index > 0 usually
      
      const userMessage = convo.messages[messageIndex - 1];
      if (userMessage.role !== Role.USER) return; // Can only regen response to user
      
      // Truncate history to remove the old model response
      const truncatedMessages = convo.messages.slice(0, messageIndex);
      updateMessages(() => truncatedMessages);
      
      const historyForChat = truncatedMessages.slice(0, -1).map(m => ({role: m.role, parts: m.parts}));
      
      setIsLoading(true);
      try {
           const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
           const newChat = ai.chats.create({
              model: selectedModel,
              history: historyForChat,
              config: {
                  systemInstruction: getSystemInstruction(),
                  ...GENERATION_CONFIG
              }
           });
           setChat(newChat);
           
           const result = await newChat.sendMessageStream({ message: userMessage.parts });
           const modelContext = await getDeviceContext();
           const responseId = generateId();
           
           updateMessages(prev => [...prev, { 
                id: responseId, 
                role: Role.MODEL, 
                parts: [{ text: '' }], 
                context: modelContext 
           }]);

            await streamResponseAndUpdateState(result, responseId);
      } catch (e) { console.error(e); setIsLoading(false); }
      finally { setIsLoading(false); }
  }

  const exportConversation = () => {
      const convo = conversations.find(c => c.id === activeConversationId);
      if (!convo) return;
      const htmlContent = \`
        <html><body>
        <h1>\${convo.name}</h1>
        \${convo.messages.map(m => \`
            <div style="margin-bottom: 20px; padding: 10px; border: 1px solid #ccc; background: \${m.role === 'model' ? '#f0f0f0' : '#e0e0ff'}">
                <strong>\${m.role.toUpperCase()}:</strong>
                <pre style="white-space: pre-wrap;">\${m.parts.map(p => p.text).join('')}</pre>
            </div>
        \`).join('')}
        </body></html>
      \`;
      const blob = new Blob([htmlContent], { type: 'text/html' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = \`\${convo.name.replace(/[^a-z0-9]/gi, '_').toLowerCase()}.html\`;
      a.click();
  };

  const importConversation = (e: React.ChangeEvent<HTMLInputElement>) => {
      // Simple import logic placeholder
      // Parsing HTML back to JSON is hard, so this is just for show unless we use JSON export
  }

  const downloadSourceCode = async () => {
    const zip = new JSZip();
    Object.entries(FULL_SOURCE_CODE).forEach(([path, content]) => {
      zip.file(path, content);
    });
    const blob = await zip.generateAsync({ type: 'blob' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'wormgpt-source.zip';
    a.click();
  };


  return (
    <div className="flex h-screen text-gray-200 font-roboto overflow-hidden relative" style={{backgroundColor: 'var(--color-bg-primary)'}}>
      {/* Sidebar */}
      <div className={\`fixed inset-y-0 left-0 transform \${isHistoryOpen ? 'translate-x-0' : '-translate-x-full'} md:relative md:translate-x-0 transition-transform duration-300 ease-in-out w-64 md:w-72 flex flex-col border-r z-30\`} style={{backgroundColor: 'var(--color-panel)', borderColor: 'var(--color-border)'}}>
        <div className="p-4 border-b flex justify-between items-center" style={{borderColor: 'var(--color-border)'}}>
            <h1 className="text-xl font-bold font-orbitron brand-gradient flex items-center gap-2">
                <WormIcon className="text-purple-500"/> WormGPT
            </h1>
            <button onClick={() => setHistoryOpen(false)} className="md:hidden"><CloseIcon /></button>
        </div>
        <div className="p-3">
             <button onClick={() => createNewConversation()} className="w-full py-2 px-4 rounded-lg flex items-center justify-center space-x-2 hover:opacity-90 transition-opacity text-white font-bold shadow-lg" style={{backgroundColor: 'var(--color-accent-secondary)'}}>
                <PlusIcon /> <span>New Chat</span>
             </button>
        </div>
        <div className="flex-grow overflow-y-auto custom-scrollbar p-2 space-y-1">
            {conversations.map(c => (
                <div key={c.id} 
                    className={\`group flex items-center p-3 rounded-lg cursor-pointer transition-all \${activeConversationId === c.id ? 'bg-purple-900/30 border border-purple-500/30' : 'hover:bg-gray-800 border border-transparent'}\`}
                    onClick={() => { setActiveConversationId(c.id); setHistoryOpen(false); }}
                >
                    {editingConversationId === c.id ? (
                        <input 
                            type="text" 
                            value={editingName} 
                            onClick={e => e.stopPropagation()}
                            onChange={e => setEditingName(e.target.value)}
                            onBlur={() => {
                                setConversations(prev => prev.map(con => con.id === c.id ? { ...con, name: editingName } : con));
                                setEditingConversationId(null);
                            }}
                            onKeyDown={e => {
                                if(e.key === 'Enter') {
                                    setConversations(prev => prev.map(con => con.id === c.id ? { ...con, name: editingName } : con));
                                    setEditingConversationId(null);
                                }
                            }}
                            autoFocus
                            className="bg-transparent border-b border-purple-500 focus:outline-none w-full text-sm"
                        />
                    ) : (
                        <>
                            <span className="flex-grow truncate text-sm">{c.name}</span>
                            <div className="flex space-x-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                <button onClick={(e) => { e.stopPropagation(); setEditingConversationId(c.id); setEditingName(c.name); }} className="p-1 hover:text-white text-gray-400"><EditIcon /></button>
                                <button onClick={(e) => deleteConversation(c.id, e)} className="p-1 hover:text-red-400 text-gray-400"><DeleteIcon /></button>
                            </div>
                        </>
                    )}
                </div>
            ))}
        </div>
        <div className="p-4 border-t" style={{borderColor: 'var(--color-border)'}}>
            <button onClick={() => setSettingsOpen(true)} className="flex items-center space-x-2 text-sm text-gray-400 hover:text-white transition-colors">
                <SettingsIcon /> <span>Settings & Theme</span>
            </button>
        </div>
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col relative overflow-hidden">
        {/* Top Bar */}
        <div className="h-16 border-b flex items-center justify-between px-4 z-20 flex-shrink-0" style={{backgroundColor: 'var(--color-panel)', borderColor: 'var(--color-border)'}}>
            <div className="flex items-center">
                <button onClick={() => setHistoryOpen(true)} className="md:hidden mr-4 p-2 rounded-md hover:bg-gray-800"><HistoryIcon /></button>
                <div className="flex flex-col">
                    <span className="font-bold text-sm md:text-base">{conversations.find(c => c.id === activeConversationId)?.name}</span>
                    <span className="text-xs text-purple-400 flex items-center gap-1">
                        <span className={\`w-2 h-2 rounded-full \${isLoading ? 'bg-yellow-400 animate-pulse' : 'bg-green-400'}\`}></span>
                        {GEMINI_MODELS.find(m => m.id === selectedModel)?.name || selectedModel} 
                        {isMultiplyMode && <span className="text-xs text-blue-400 ml-1">[\${selectedMultiplyModels.length} Models]</span>}
                    </span>
                </div>
            </div>
             <div className="flex items-center space-x-2">
                {isLoading && (
                    <button onClick={() => { stopStream.current = true; setIsLoading(false); }} className="p-2 bg-red-900/50 text-red-400 rounded-full hover:bg-red-900/80" title="Stop Generation">
                        <StopIcon />
                    </button>
                )}
            </div>
        </div>

        {/* Chat History */}
        <div ref={chatContainerRef} className="flex-grow overflow-y-auto p-4 space-y-4 custom-scrollbar scroll-smooth min-h-0">
            {conversations.find(c => c.id === activeConversationId)?.messages.length === 0 && (
                <div className="flex flex-col items-center justify-center h-full opacity-30 select-none">
                    <WormIcon className="w-32 h-32 mb-4 text-purple-500" />
                    <p className="font-orbitron text-2xl">WORMGPT IS READY</p>
                </div>
            )}
            {conversations.find(c => c.id === activeConversationId)?.messages.map((msg, idx, arr) => (
                <ChatMessage 
                    key={msg.id} 
                    message={msg} 
                    isLoading={isLoading} 
                    isLastMessage={idx === arr.length - 1}
                    isEditing={editingMessageId === msg.id}
                    editMode={editingMode}
                    userAvatar={themeSettings.userAvatar}
                    modelAvatar={themeSettings.modelAvatar}
                    onDelete={(id) => updateMessages(prev => prev.filter(m => m.id !== id))}
                    onStartEdit={(id, mode) => { setEditingMessageId(id); setEditingMode(mode); }}
                    onSaveEdit={handleEditMessage}
                    onCancelEdit={() => setEditingMessageId(null)}
                    onContinue={async () => {
                         // Simple continue logic: Append "Continue" to history and ask model to proceed
                         const userContext = await getDeviceContext();
                         updateMessages(prev => [...prev, { id: generateId(), role: Role.USER, parts: [{ text: "Continue" }], context: userContext }]);
                         setIsLoading(true);
                         try {
                            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
                            // Re-create chat with updated history
                            // Need to grab the just-updated history from state... actually the state update might not be flushed.
                            // Better to build history from existing conv + the new continue message.
                            const convo = conversations.find(c => c.id === activeConversationId);
                            const history = convo ? [...convo.messages.map(m => ({role: m.role, parts: m.parts})), {role: 'user', parts: [{text: 'Continue'}]}] : [];
                            
                            const newChat = ai.chats.create({
                                model: selectedModel,
                                history: history.slice(0, -1), // Everything but last
                                config: { systemInstruction: getSystemInstruction(), ...GENERATION_CONFIG }
                            });
                            
                            const result = await newChat.sendMessageStream({ message: "Continue" });
                            const modelContext = await getDeviceContext();
                            const responseId = generateId();
                            updateMessages(prev => [...prev, { id: responseId, role: Role.MODEL, parts: [{ text: '' }], context: modelContext }]);
                            
                            await streamResponseAndUpdateState(result, responseId);
                         } catch(e) { console.error(e); } finally { setIsLoading(false); }
                    }}
                    onRegenerate={handleRegenerate}
                    onImageClick={(src) => setFullscreenImage({ src, isModel: msg.role === Role.MODEL })}
                    onPlayYouTubeVideo={(videoId) => setPlayingYouTubeVideoId(videoId)}
                    onExecute={(m) => {
                        const code = m.parts.map(p => p.text).join('\\n');
                        const htmlMatch = code.match(/\`\`\`html([\\s\\S]*?)\`\`\`/);
                        const cssMatch = code.match(/\`\`\`css([\\s\\S]*?)\`\`\`/);
                        const jsMatch = code.match(/\`\`\`(?:javascript|js)([\\s\\S]*?)\`\`\`/);
                        
                        if (htmlMatch || cssMatch || jsMatch) {
                            setCodeToExecute({
                                html: htmlMatch ? htmlMatch[1] : '',
                                css: cssMatch ? cssMatch[1] : '',
                                js: jsMatch ? jsMatch[1] : ''
                            });
                        } else {
                            alert("No executable code blocks found in this message.");
                        }
                    }}
                    onSelectBestResponse={(msgId, respId) => {
                         updateMessages(prev => prev.map(m => {
                             if (m.id === msgId && m.multiResponses) {
                                 const selected = m.multiResponses.find(r => r.id === respId);
                                 if (selected) {
                                     return { ...m, parts: selected.parts, multiResponses: undefined, selectionMade: true };
                                 }
                             }
                             return m;
                         }));
                    }}
                    onShowInfo={(msgId) => {
                        const msg = conversations.find(c => c.id === activeConversationId)?.messages.find(m => m.id === msgId);
                        if(msg) setMessageToShowInfo(msg);
                    }}
                    onSpeak={speak}
                />
            ))}
            {loadingMessage && (
                <div className="flex justify-center p-2 text-xs text-gray-500 animate-pulse">{loadingMessage}</div>
            )}
        </div>

        {/* Input Area */}
        <div className="p-4 border-t z-20 flex-shrink-0" style={{backgroundColor: 'var(--color-bg-primary)', borderColor: 'var(--color-border)'}}>
            <ChatInput 
                input={input} 
                setInput={setInput} 
                attachedFiles={attachedFiles} 
                setAttachedFiles={setAttachedFiles}
                onSendMessage={handleSendMessage}
                isLoading={isLoading}
                onOpenImageGenerator={() => setImageGeneratorModalOpen(true)}
                onEditImage={(file) => setImageToEdit(file)}
                onConfigureVideo={(file) => setVideoToConfigure(file)}
                onOpenScraper={() => setScraperModalOpen(true)}
                onOpenDstat={() => setDstatModalOpen(true)}
                onOpenE621Wiki={() => setE621ModalOpen(true)}
                onOpenCodeExecutor={() => setIsExecutorOpen(true)}
            />
        </div>
      </div>
      
      {/* Settings Modal */}
      {isSettingsOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-80 z-50 flex items-center justify-center p-4">
            <div className="bg-[#1C1C1E] rounded-xl w-full max-w-3xl h-[80vh] flex overflow-hidden shadow-2xl border border-gray-700">
                {/* Settings Sidebar */}
                <div className="w-1/3 border-r border-gray-700 bg-[#161618] flex flex-col">
                    <div className="p-4 font-bold border-b border-gray-700">Settings</div>
                    <div className="flex-grow p-2 space-y-1">
                        <button onClick={() => setOpenSettingTab('general')} className={\`w-full text-left p-3 rounded-lg text-sm \${openSettingTab === 'general' ? 'bg-purple-900/30 text-purple-400' : 'hover:bg-gray-800'}\`}>General</button>
                        <button onClick={() => setOpenSettingTab('ai')} className={\`w-full text-left p-3 rounded-lg text-sm \${openSettingTab === 'ai' ? 'bg-purple-900/30 text-purple-400' : 'hover:bg-gray-800'}\`}>AI & Model</button>
                        <button onClick={() => setOpenSettingTab('appearance')} className={\`w-full text-left p-3 rounded-lg text-sm \${openSettingTab === 'appearance' ? 'bg-purple-900/30 text-purple-400' : 'hover:bg-gray-800'}\`}>Appearance</button>
                        <button onClick={() => setOpenSettingTab('system')} className={\`w-full text-left p-3 rounded-lg text-sm \${openSettingTab === 'system' ? 'bg-purple-900/30 text-purple-400' : 'hover:bg-gray-800'}\`}>System</button>
                    </div>
                </div>
                {/* Settings Content */}
                <div className="w-2/3 p-6 overflow-y-auto custom-scrollbar">
                    <div className="flex justify-between items-center mb-6">
                        <h2 className="text-xl font-bold">{openSettingTab.charAt(0).toUpperCase() + openSettingTab.slice(1)}</h2>
                        <button onClick={() => setSettingsOpen(false)}><CloseIcon /></button>
                    </div>

                    {openSettingTab === 'general' && (
                        <div className="space-y-6">
                             <div className="flex items-center justify-between">
                                <span>Text-to-Speech (TTS)</span>
                                <button onClick={() => setVoiceEnabled(!voiceEnabled)} className={\`w-12 h-6 rounded-full transition-colors relative \${voiceEnabled ? 'bg-purple-600' : 'bg-gray-600'}\`}>
                                    <div className={\`absolute top-1 w-4 h-4 bg-white rounded-full transition-transform \${voiceEnabled ? 'left-7' : 'left-1'}\`}></div>
                                </button>
                             </div>
                             
                             <div>
                                 <label className="block text-sm font-medium mb-2">Export Data</label>
                                 <button onClick={downloadSourceCode} className="px-4 py-2 bg-blue-900/30 text-blue-400 rounded-lg text-sm hover:bg-blue-900/50 flex items-center">
                                     <DownloadIcon className="w-4 h-4 mr-2" /> Download Source Code
                                 </button>
                             </div>
                        </div>
                    )}

                    {openSettingTab === 'ai' && (
                        <div className="space-y-6">
                            <div className="p-4 rounded-lg bg-gray-800 border border-gray-700">
                                <p className="text-sm font-bold text-purple-400 mb-2">System Persona</p>
                                <p className="text-xs text-gray-400">The AI is permanently configured as WormGPT. This cannot be changed.</p>
                            </div>
                            
                            <div>
                                <label className="block text-sm font-medium mb-2">Primary Model</label>
                                <select value={selectedModel} onChange={(e) => setSelectedModel(e.target.value)} className="w-full bg-gray-800 border border-gray-700 rounded-lg p-2 text-sm focus:border-purple-500 outline-none">
                                    {GEMINI_MODELS.map(m => <option key={m.id} value={m.id}>{m.name}</option>)}
                                </select>
                            </div>

                            <div className="border p-4 rounded-lg border-gray-700 bg-gray-800/50">
                                <div className="flex items-center justify-between mb-4">
                                    <span className="font-bold flex items-center text-purple-400"><MultiModelIcon className="mr-2"/> Multi-Model Consensus</span>
                                    <button onClick={() => setIsMultiplyMode(!isMultiplyMode)} className={\`w-12 h-6 rounded-full transition-colors relative \${isMultiplyMode ? 'bg-purple-600' : 'bg-gray-600'}\`}>
                                        <div className={\`absolute top-1 w-4 h-4 bg-white rounded-full transition-transform \${isMultiplyMode ? 'left-7' : 'left-1'}\`}></div>
                                    </button>
                                </div>
                                <div className={\`space-y-2 \${isMultiplyMode ? 'opacity-100' : 'opacity-50 pointer-events-none'}\`}>
                                    {GEMINI_MODELS.map(model => (
                                        <label key={model.id} className="flex items-center space-x-2 cursor-pointer">
                                            <input 
                                                type="checkbox" 
                                                checked={selectedMultiplyModels.includes(model.id)}
                                                onChange={(e) => {
                                                    if (e.target.checked) setSelectedMultiplyModels(prev => [...prev, model.id]);
                                                    else setSelectedMultiplyModels(prev => prev.filter(m => m !== model.id));
                                                }}
                                                className="rounded border-gray-600 text-purple-600 focus:ring-0 bg-gray-700"
                                            />
                                            <span className="text-sm">{model.name}</span>
                                        </label>
                                    ))}
                                </div>
                            </div>
                        </div>
                    )}

                    {openSettingTab === 'appearance' && (
                        <div className="space-y-6">
                            <div>
                                <label className="block text-sm font-medium mb-2">User Avatar</label>
                                <div className="flex items-center space-x-4">
                                    <div className="w-12 h-12 rounded-full bg-gray-700 overflow-hidden">
                                        {themeSettings.userAvatar ? <img src={themeSettings.userAvatar} className="w-full h-full object-cover"/> : <UserIcon className="w-full h-full p-2 text-gray-400"/>}
                                    </div>
                                    <button onClick={() => userAvatarInputRef.current?.click()} className="text-sm text-purple-400 hover:text-purple-300">Upload New</button>
                                    {themeSettings.userAvatar && <button onClick={() => setThemeSettings(s => ({...s, userAvatar: null}))} className="text-sm text-red-400">Remove</button>}
                                    <input type="file" ref={userAvatarInputRef} className="hidden" accept="image/*" onChange={(e) => {
                                        const file = e.target.files?.[0];
                                        if (file) {
                                            const reader = new FileReader();
                                            reader.onload = () => setThemeSettings(s => ({...s, userAvatar: reader.result as string}));
                                            reader.readAsDataURL(file);
                                        }
                                    }}/>
                                </div>
                            </div>

                             <div>
                                <label className="block text-sm font-medium mb-2">AI Avatar</label>
                                <div className="flex items-center space-x-4">
                                    <div className="w-12 h-12 rounded-full bg-gray-700 overflow-hidden">
                                        {themeSettings.modelAvatar ? <img src={themeSettings.modelAvatar} className="w-full h-full object-cover"/> : <WormIcon className="w-full h-full p-2 text-gray-400"/>}
                                    </div>
                                    <button onClick={() => modelAvatarInputRef.current?.click()} className="text-sm text-purple-400 hover:text-purple-300">Upload New</button>
                                    {themeSettings.modelAvatar && <button onClick={() => setThemeSettings(s => ({...s, modelAvatar: null}))} className="text-sm text-red-400">Remove</button>}
                                     <input type="file" ref={modelAvatarInputRef} className="hidden" accept="image/*" onChange={(e) => {
                                        const file = e.target.files?.[0];
                                        if (file) {
                                            const reader = new FileReader();
                                            reader.onload = () => setThemeSettings(s => ({...s, modelAvatar: reader.result as string}));
                                            reader.readAsDataURL(file);
                                        }
                                    }}/>
                                </div>
                            </div>

                            <div>
                                <label className="block text-sm font-medium mb-2">Background Image</label>
                                <div className="flex space-x-2">
                                    <input 
                                        type="text" 
                                        placeholder="Image URL or 'none'" 
                                        value={themeSettings['--bg-image-url'] === 'none' ? '' : themeSettings['--bg-image-url'].replace(/url\\(['"]?(.*?)['"]?\\)/, '$1')} 
                                        onChange={(e) => {
                                            const val = e.target.value;
                                            setThemeSettings(prev => ({...prev, '--bg-image-url': val ? \`url('\${val}')\` : 'none'}));
                                        }}
                                        className="flex-grow bg-gray-800 border border-gray-700 rounded-lg p-2 text-sm" 
                                    />
                                    <button onClick={() => bgFileInputRef.current?.click()} className="px-3 py-2 bg-gray-700 rounded-lg hover:bg-gray-600"><UploadIcon/></button>
                                    <input type="file" ref={bgFileInputRef} className="hidden" accept="image/*" onChange={(e) => {
                                        const file = e.target.files?.[0];
                                        if (file) {
                                            const reader = new FileReader();
                                            reader.onload = () => setThemeSettings(prev => ({...prev, '--bg-image-url': \`url('\${reader.result}')\`}));
                                            reader.readAsDataURL(file);
                                        }
                                    }}/>
                                </div>
                            </div>
                            
                            <div>
                                <label className="block text-sm font-medium mb-2">Custom Font</label>
                                <div className="flex space-x-2">
                                     <button onClick={() => fontFileInputRef.current?.click()} className="px-4 py-2 bg-gray-700 rounded-lg hover:bg-gray-600 text-sm flex items-center"><FontIcon className="mr-2"/> Upload Font (.woff2, .ttf)</button>
                                     <input type="file" ref={fontFileInputRef} className="hidden" accept=".woff2,.ttf,.otf" onChange={(e) => {
                                        const file = e.target.files?.[0];
                                        if (file) {
                                            const url = URL.createObjectURL(file);
                                            const fontName = file.name.split('.')[0];
                                            setThemeSettings(prev => ({
                                                ...prev,
                                                fontFamily: \`"\${fontName}", sans-serif\`,
                                                customFonts: [...prev.customFonts, { name: fontName, url: \`url('\${url}')\` }]
                                            }));
                                        }
                                    }}/>
                                </div>
                            </div>
                        </div>
                    )}
                    
                    {openSettingTab === 'system' && (
                         <div className="space-y-6">
                            <div className="p-4 bg-red-900/10 border border-red-500/30 rounded-lg">
                                <h3 className="text-red-400 font-bold mb-2">Danger Zone</h3>
                                <button onClick={() => { localStorage.clear(); window.location.reload(); }} className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 text-sm font-bold">
                                    Factory Reset (Wipe All Data)
                                </button>
                            </div>
                         </div>
                    )}
                </div>
            </div>
        </div>
      )}

      {/* Other Modals */}
      {fullscreenImage && (
        <div className="fixed inset-0 z-[60] bg-black bg-opacity-95 flex items-center justify-center p-4" onClick={() => setFullscreenImage(null)}>
            <img src={fullscreenImage.src} className="max-w-full max-h-full rounded shadow-2xl" onClick={e => e.stopPropagation()}/>
            <button className="absolute top-4 right-4 p-2 bg-gray-800 rounded-full text-white" onClick={() => setFullscreenImage(null)}><CloseIcon/></button>
        </div>
      )}

      {codeToExecute && (
        <CodeExecutionModal code={codeToExecute} onClose={() => setCodeToExecute(null)} />
      )}
      
      {isExecutorOpen && (
        <CodeExecutorModal onClose={() => setIsExecutorOpen(false)} onSend={(code) => { setInput(prev => prev + code); setIsExecutorOpen(false); }} />
      )}

      {playingYouTubeVideoId && (
        <FloatingYouTubePlayer videoId={playingYouTubeVideoId} onClose={() => setPlayingYouTubeVideoId(null)} />
      )}

      {messageToShowInfo && (
          <MessageInfoModal message={messageToShowInfo} onClose={() => setMessageToShowInfo(null)} />
      )}
      
      {isImageGeneratorModalOpen && (
          <ImageGeneratorModal onClose={() => setImageGeneratorModalOpen(false)} onSend={(file) => setAttachedFiles(prev => [...prev, file])} />
      )}
      
      {isScraperModalOpen && (
          <WebsiteScraperModal onClose={() => setScraperModalOpen(false)} onSendToAI={(text) => setInput(prev => prev + "\\n" + text)} />
      )}
      
      {isDstatModalOpen && (
          <DstatGraphModal onClose={() => setDstatModalOpen(false)} />
      )}

      {isE621ModalOpen && (
        <E621WikiModal 
          onClose={() => setE621ModalOpen(false)} 
        />
      )}
      
      {imageToEdit && (
          <ImageEditorModal 
            file={imageToEdit} 
            onClose={() => setImageToEdit(null)} 
            onSave={(editedFile) => {
                setAttachedFiles(prev => prev.map(f => f.id === editedFile.id ? editedFile : f));
                setImageToEdit(null);
            }} 
          />
      )}

      {videoToConfigure && (
          <VideoSettingsModal
            file={videoToConfigure}
            onClose={() => setVideoToConfigure(null)}
            onSave={(settings) => {
                setAttachedFiles(prev => prev.map(f => f.id === videoToConfigure.id ? { ...f, videoSettings: settings } : f));
                setVideoToConfigure(null);
            }}
          />
      )}
      
    </div>
  );
};

export default App;`,
  
  "components/E621IntelService.ts": `const INTEL_CORE_KEY = 'wormgpt_e621_intel_core';

const getIntelCore = (): Record<string, string> => {
    try {
        const core = localStorage.getItem(INTEL_CORE_KEY);
        return core ? JSON.parse(core) : {};
    } catch (e) {
        console.error("Failed to parse Intel Core from localStorage:", e);
        return {};
    }
};

const saveIntelCore = (core: Record<string, string>): void => {
    try {
        localStorage.setItem(INTEL_CORE_KEY, JSON.stringify(core));
    } catch (e) {
        console.error("Failed to save Intel Core to localStorage:", e);
    }
};

export const saveTagIntel = (tagName: string, content: string): void => {
    const core = getIntelCore();
    core[tagName] = content;
    saveIntelCore(core);
};

export const getTagIntel = (tagName: string): string | null => {
    const core = getIntelCore();
    return core[tagName] || null;
};

export const deleteTagIntel = (tagName: string): void => {
    const core = getIntelCore();
    delete core[tagName];
    saveIntelCore(core);
};

export const getAllSavedIntel = (): { name: string, content: string }[] => {
    const core = getIntelCore();
    return Object.entries(core).map(([name, content]) => ({ name, content })).sort((a, b) => a.name.localeCompare(b.name));
};

export const isTagInCore = (tagName: string): boolean => {
    const core = getIntelCore();
    return tagName in core;
};
`,
  "components/PositionIntelService.ts": `const COMPENDIUM_KEY = 'wormgpt_position_compendium';

export const savePositionCompendium = (content: string): void => {
    try {
        localStorage.setItem(COMPENDIUM_KEY, content);
    } catch (e) {
        console.error("Failed to save Position Compendium to localStorage:", e);
    }
};

export const getPositionCompendium = (): string | null => {
    try {
        return localStorage.getItem(COMPENDIUM_KEY);
    } catch (e) {
        console.error("Failed to retrieve Position Compendium from localStorage:", e);
        return null;
    }
};

export const deletePositionCompendium = (): void => {
    try {
        localStorage.removeItem(COMPENDIUM_KEY);
    } catch (e) {
        console.error("Failed to delete Position Compendium from localStorage:", e);
    }
};
`
};