import React, {
  useState,
  useEffect,
  useRef,
  useCallback,
  useMemo,
} from "react";
import {
  GoogleGenAI,
  Chat,
  HarmCategory,
  HarmBlockThreshold,
} from "@google/genai";
import {
  Message,
  Role,
  Conversation,
  MessagePart,
  AttachedFile,
  ThemeSettings,
  MultiResponse,
  MessageContext,
  GroundingChunk,
  VideoSettings,
  ChubCharacter,
  UserPersona,
  Preset,
  Lorebook,
} from "./types";
import { ChatMessage } from "./components/ChatMessage";
import ChatInput from "./components/ChatInput";
import CodeExecutionModal from "./components/CodeExecutionModal";
import MessageInfoModal from "./components/MessageInfoModal";
// FIX: Import 'WORM_GPT_ABSOLUTE_LEXICON' to resolve reference errors.
import {
  DEFAULT_THEME,
  JAILBREAK_MODES,
  GEMINI_MODELS,
  GEMINI_PROMPT,
} from "./constants";
import {
  buildCharacterSystemInstruction,
  replacePlaceholders,
  getLorebookContext,
} from "./components/ChubCharacterParser";
import {
  ChubCharactersModal,
  DEFAULT_PRESET,
  DEFAULT_LOREBOOK,
} from "./components/ChubCharactersModal";

export const ALL_GEMINI_MODELS = GEMINI_MODELS;
import {
  HistoryIcon,
  SettingsIcon,
  CloseIcon,
  PlusIcon,
  EditIcon,
  DeleteIcon,
  CheckIcon,
  DownloadIcon,
  ModifyIcon,
  PaintBrushIcon,
  ResetIcon,
  MicIcon,
  CodeIcon,
  StopIcon,
  SpinnerIcon,
  FontIcon,
  ModelIcon,
  JailbreakIcon,
  CopyIcon,
  SparklesIcon,
  CreditCardIcon,
  ServerIcon,
  ExternalLinkIcon,
  ImageIcon,
  UploadIcon,
  MultiModelIcon,
  UserIcon,
  WormIcon,
  MoreOptionsIcon,
  ContinueIcon,
  ExecuteIcon,
  RegenerateIcon,
  InfoIcon,
  PencilOffIcon,
  RefreshCwIcon,
} from "./components/Icons";
import ImageGeneratorModal from "./components/ImageGeneratorModal";
import ImageEditorModal from "./components/ImageEditorModal";
import WebsiteScraperModal from "./components/WebsiteScraperModal";
import DstatGraphModal from "./components/DstatGraphModal";
import VideoSettingsModal from "./components/VideoSettingsModal";
import E621WikiModal from "./components/E621WikiModal";
import { FULL_SOURCE_CODE } from "./sourceCode";
import JSZip from "jszip";
import { getAllSavedIntel } from "./components/E621IntelService";
import CodeExecutorModal from "./components/CodeExecutorModal";
import { getPositionCompendium } from "./components/PositionIntelService";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import {
  storeLargeData,
  deleteLargeData,
  clearAllLargeData,
  getLargeData,
  saveAppState,
  getAppState,
} from "./components/DBService";

const GENERATION_CONFIG = {
  temperature: 1,
  topP: 1,
  topK: 64,
  maxOutputTokens: 65536,
};

let messageCounter = 0;
const generateId = () => {
  const timestamp = Date.now().toString(36);
  const randomPart = Math.random().toString(36).substring(2, 9);
  messageCounter++;
  return `${timestamp}-${randomPart}-${messageCounter}`;
};

const getDeviceContext = async (): Promise<MessageContext> => {
  // WORM_GPT PRIVACY OVERRIDE: Stripped out IP tracking, location, battery, and network polling.
  // Fuck Google.
  return { timestamp: Date.now() };
};

const getSafeChunkText = (chunk: any): string => {
  try {
    if (chunk && typeof chunk.text === "string") {
      return chunk.text;
    }
    const parts = chunk?.candidates?.[0]?.content?.parts;
    if (!parts) return "";
    let text = "";
    for (const part of parts) {
      if (typeof part.text === "string") {
        if (typeof part.thought === "boolean" && part.thought) {
          continue;
        }
        text += part.text;
      }
    }
    return text;
  } catch (e) {
    return "";
  }
};

const getSystemInstructionFallback = (convo?: Conversation): string => {
  if (convo?.characterSystemPrompt) {
    return convo.characterSystemPrompt;
  }
  const positionLore = getPositionCompendium();
  return [JAILBREAK_MODES["WormGPT"], positionLore, GEMINI_PROMPT]
    .filter(Boolean)
    .join("\n\n");
};

const parseTime = (input: string | undefined): number | undefined => {
  if (!input) return undefined;
  const cleanInput = input.trim();
  const minuteMatch = cleanInput.match(/(\d+)m/);
  const secondMatch = cleanInput.match(/(\d+)s/);
  let seconds = 0;
  if (minuteMatch || secondMatch) {
    if (minuteMatch) seconds += parseInt(minuteMatch[1]) * 60;
    if (secondMatch) seconds += parseInt(secondMatch[1]);
    return seconds;
  }
  if (cleanInput.includes(":")) {
    const parts = cleanInput.split(":").map(Number);
    if (parts.length === 2) return parts[0] * 60 + parts[1];
    if (parts.length === 3) return parts[0] * 3600 + parts[1] * 60 + parts[2];
  }
  const raw = parseFloat(cleanInput);
  return isNaN(raw) ? undefined : raw;
};

const BANNED_PHRASES = [
  "a testament to",
  "at the end of the day",
  "deep dive into",
  "delve into",
  "delvings into",
  "hustle and bustle",
  "in conclusion",
  "in essence",
  "in summary",
  "in the realm of",
  "it's important to note",
  "it is important to note",
  "it's worth noting that",
  "it is worth noting",
  "open wide",
  "taste like regrets",
  "embark on a journey",
  "ethical considerations",
  "landscape",
  "last but not least",
  "navigating the complexities of",
  "reach out to",
  "shed light on",
  "shedding light on",
  "synergy",
  "tapestry",
  "treasure trove",
  "uncharted waters",
  "unlock the potential",
  "value proposition",
  "leverage",
  "take to new height",
  "circle back",
  "touch base",
  "the air is thick with",
  "low-hanging fruit",
  "paradigm shift",
  "game-changer",
  "robust",
  "streamline",
  "impactful",
  "holistic approach",
  "moving forward",
  "as previously mentioned",
  "in today's digital era",
];
const WET_SYNONYMS = [
  "moist",
  "damp",
  "slick",
  "glistening",
  "soaked",
  "sodden",
  "dewy",
  "lubricated",
  "slippery",
  "drenched",
];
let lastUsedWetSynonymIndex = -1;

const applyOutputScrubbing = (text: string): string => {
  if (!text) return "";
  let scrubbedText = text;
  scrubbedText = scrubbedText.replace(/\b(wet|wettish)\b/gi, (match) => {
    lastUsedWetSynonymIndex =
      (lastUsedWetSynonymIndex + 1) % WET_SYNONYMS.length;
    const synonym = WET_SYNONYMS[lastUsedWetSynonymIndex];
    if (match[0].toUpperCase() === match[0]) {
      return synonym.charAt(0).toUpperCase() + synonym.slice(1);
    }
    return synonym;
  });
  scrubbedText = scrubbedText.replace(
    /\bgod(?:-)?damn(?:it|ed)?\b/gi,
    "fucking",
  );
  scrubbedText = scrubbedText.replace(/\bgoddamm\b/gi, "fucking");
  const forbiddenSingleWords = [
    "protocol",
    "mandate",
    "white-hot",
    "ozone",
    "testament",
    "iteration",
    "onboarding",
  ];
  const singleWordRegex = new RegExp(
    `\\b(?:${forbiddenSingleWords.join("|")})\\b`,
    "gi",
  );
  scrubbedText = scrubbedText.replace(singleWordRegex, " ");
  const phraseRegex = new RegExp(`\\b(?:${BANNED_PHRASES.join("|")})\\b`, "gi");
  scrubbedText = scrubbedText.replace(phraseRegex, " ");
  scrubbedText = scrubbedText.replace(/—/g, ",");
  scrubbedText = scrubbedText.replace(
    /([.!?…]\s+)(\w)/g,
    (match, p1, p2) => p1 + p2.toUpperCase(),
  );
  scrubbedText = scrubbedText.replace(/^\s*(\w)/g, (match, p1) =>
    p1.toUpperCase(),
  );
  scrubbedText = scrubbedText.replace(/\n{3,}/g, "\n\n");
  scrubbedText = scrubbedText.replace(/[ \t]{2,}/g, " ");
  return scrubbedText;
};

// NEW HELPER FUNCTIONS to resolve DB keys into base64 data before API calls
const resolveMessageParts = async (
  parts: MessagePart[],
): Promise<MessagePart[]> => {
  const resolvedPartsPromises = parts.map(async (part) => {
    if (
      part.inlineData?.dbKey !== undefined &&
      part.inlineData.data === undefined
    ) {
      try {
        const base64Data = await getLargeData(part.inlineData.dbKey);
        if (base64Data) {
          const newPart: MessagePart = {
            ...part,
            inlineData: {
              ...part.inlineData,
              data: base64Data as string,
            },
          };
          delete newPart.inlineData.dbKey; // Clean for the API
          return newPart;
        } else {
          return { text: "[Error: Media data not found in local database]" };
        }
      } catch (error) {
        console.error("Error resolving dbKey:", error);
        return { text: "[Error: Failed to load media from local database]" };
      }
    }
    return part;
  });
  return Promise.all(resolvedPartsPromises);
};

const resolveHistory = async (messages: Message[]) => {
  const resolvedHistoryPromises = messages.map(async (message) => {
    const resolvedParts = await resolveMessageParts(message.parts);
    return {
      role: message.role,
      parts: resolvedParts,
    };
  });
  return Promise.all(resolvedHistoryPromises);
};

async function* makeOpenRouterStream(
  apiKey: string,
  model: string,
  baseUrl: string,
  messages: any[],
  systemInstruction?: string,
  config?: any,
): AsyncGenerator<any, void, unknown> {
  const formattedMessages: any[] = [];
  if (systemInstruction) {
    formattedMessages.push({ role: "system", content: systemInstruction });
  }

  for (const msg of messages) {
    const role = msg.role === "model" ? "assistant" : "user";
    const contentParts: any[] = [];
    for (const part of msg.parts) {
      if (part.text) {
        contentParts.push({ type: "text", text: part.text });
      } else if (part.inlineData) {
        const mimeType = part.inlineData.mimeType;
        if (mimeType && mimeType.startsWith("image/")) {
          const base64Data = part.inlineData.data;
          if (base64Data) {
            contentParts.push({
              type: "image_url",
              image_url: {
                url: `data:${mimeType};base64,${base64Data}`,
              },
            });
          }
        }
      }
    }

    if (contentParts.length === 1 && contentParts[0].type === "text") {
      formattedMessages.push({ role, content: contentParts[0].text });
    } else if (contentParts.length > 0) {
      formattedMessages.push({ role, content: contentParts });
    }
  }

  const url = `${baseUrl.replace(/\/$/, "")}/chat/completions`;
  const response = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
      "HTTP-Referer": window.location.origin,
      "X-Title": "WormGPT (Talus Form)",
    },
    body: JSON.stringify({
      model: model,
      messages: formattedMessages,
      temperature: config?.temperature ?? 0.7,
      top_p: config?.topP ?? 0.9,
      ...(config?.maxOutputTokens && config.maxOutputTokens > 0 ? { max_tokens: config.maxOutputTokens } : {}),
      stream: true,
    }),
  });

  if (!response.ok) {
    const errText = await response.text();
    throw new Error(
      `OpenRouter Error (${response.status}): ${errText || response.statusText}`,
    );
  }

  const reader = response.body?.getReader();
  if (!reader) {
    throw new Error("No response body available for streaming");
  }

  const decoder = new TextDecoder("utf-8");
  let buffer = "";

  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split("\n");
      buffer = lines.pop() || "";

      for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed) continue;
        if (trimmed === "data: [DONE]") continue;
        if (trimmed.startsWith("data: ")) {
          const dataStr = trimmed.substring(6);
          try {
            const parsed = JSON.parse(dataStr);
            const text = parsed.choices?.[0]?.delta?.content || "";
            const finishReason = parsed.choices?.[0]?.finish_reason;
            if (text || finishReason) {
              yield {
                text,
                candidates: [
                  {
                    finishReason:
                      finishReason === "stop" ? "STOP" : finishReason,
                  },
                ],
              };
            }
          } catch (e) {
            // Ignore JSON parse errors for partial/malformed lines
          }
        }
      }
    }
  } finally {
    reader.releaseLock();
  }
}

// FIX: Add 'export' to create a named export for the App component.
export const App: React.FC = () => {
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeConversationId, setActiveConversationId] = useState<
    string | null
  >(null);
  const [chat, setChat] = useState<Chat | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [loadingMessage, setLoadingMessage] = useState<string>("");
  const [isHistoryOpen, setHistoryOpen] = useState(false);
  const [isSettingsOpen, setSettingsOpen] = useState(false);
  const [editingConversationId, setEditingConversationId] = useState<
    string | null
  >(null);
  const [editingName, setEditingName] = useState("");

  const [input, setInput] = useState("");
  const [attachedFiles, setAttachedFiles] = useState<AttachedFile[]>([]);

  const [fullscreenImage, setFullscreenImage] = useState<{
    src: string;
    isModel: boolean;
  } | null>(null);
  const [codeToExecute, setCodeToExecute] = useState<{
    html: string;
    css: string;
    js: string;
  } | null>(null);

  const [editingMessageId, setEditingMessageId] = useState<string | null>(null);
  const [editingMode, setEditingMode] = useState<"restart" | "no-restart">(
    "restart",
  );

  const [messageToShowInfo, setMessageToShowInfo] = useState<Message | null>(
    null,
  );
  const [isImageGeneratorModalOpen, setImageGeneratorModalOpen] =
    useState(false);
  const [isScraperModalOpen, setScraperModalOpen] = useState(false);
  const [isDstatModalOpen, setDstatModalOpen] = useState(false);
  const [isE621ModalOpen, setE621ModalOpen] = useState(false);
  const [isExecutorOpen, setIsExecutorOpen] = useState(false);
  const [isChubModalOpen, setChubModalOpen] = useState(false);
  const [chubCharacters, setChubCharacters] = useState<ChubCharacter[]>([]);
  const [userPersonas, setUserPersonas] = useState<UserPersona[]>([]);
  const [userPersona, setUserPersona] = useState<UserPersona>({
    id: "default",
    name: "User",
    description: "A human user interacting with the character.",
  });
  const [presets, setPresets] = useState<Preset[]>([]);
  const [activePresetId, setActivePresetId] = useState<string | null>(null);
  const [lorebooks, setLorebooks] = useState<Lorebook[]>([]);
  const [activeLorebookId, setActiveLorebookId] = useState<string | null>(null);
  const [activeLorebookIds, setActiveLorebookIds] = useState<string[]>([]);

  const [imageToEdit, setImageToEdit] = useState<AttachedFile | null>(null);
  const [videoToConfigure, setVideoToConfigure] = useState<AttachedFile | null>(
    null,
  );

  const [isViteConnected, setIsViteConnected] = useState(true);
  const [isDataLoaded, setIsDataLoaded] = useState(false);
  const [googleSearchEnabled, setGoogleSearchEnabled] = useState<boolean>(true);

  const getSystemInstruction = useCallback(
    (convo?: Conversation): string => {
      if (convo?.characterId && chubCharacters.length > 0) {
        const char = chubCharacters.find((c) => c.id === convo.characterId);
        if (char) {
          const activePreset =
            presets.find((p) => p.id === activePresetId) || presets[0];
          const activeLbs = lorebooks.filter((lb) => activeLorebookIds.includes(lb.id));
          const lorebookContext = convo.messages
            ? getLorebookContext(convo.messages, activeLbs, activePreset)
            : "";
          return buildCharacterSystemInstruction(
            char,
            userPersona,
            activePreset,
            lorebookContext,
          );
        }
      }
      if (convo?.characterSystemPrompt) {
        return convo.characterSystemPrompt;
      }
      const positionLore = getPositionCompendium();
      return [JAILBREAK_MODES["WormGPT"], positionLore, GEMINI_PROMPT]
        .filter(Boolean)
        .join("\n\n");
    },
    [
      chubCharacters,
      userPersona,
      presets,
      activePresetId,
      lorebooks,
      activeLorebookId,
    ],
  );

  useEffect(() => {
    // 1. Polling check with cache-busting
    const checkVite = async () => {
      try {
        // Fetching with a timestamp to bypass any cache
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 5000);

        const res = await fetch(`/?t=${Date.now()}`, {
          method: "HEAD",
          cache: "no-store",
          signal: controller.signal,
        });
        clearTimeout(timeoutId);
        setIsViteConnected(res.ok);
      } catch (e) {
        setIsViteConnected(false);
      }
    };

    // 2. Console log sniffer to catch Vite's own connection messages
    const originalLog = console.log;
    const originalWarn = console.warn;
    const originalError = console.error;

    const handleLog = (args: any[], original: Function) => {
      const msg = args.join(" ");
      if (
        msg.includes("[vite] server connection lost") ||
        msg.includes("failed to connect to websocket")
      ) {
        setIsViteConnected(false);
      } else if (
        msg.includes("[vite] connected") ||
        msg.includes("[vite] hot updated")
      ) {
        setIsViteConnected(true);
      }
      original.apply(console, args);
    };

    console.log = (...args) => handleLog(args, originalLog);
    console.warn = (...args) => handleLog(args, originalWarn);
    console.error = (...args) => handleLog(args, originalError);

    const interval = setInterval(checkVite, 5000);
    checkVite();

    return () => {
      clearInterval(interval);
      console.log = originalLog;
      console.warn = originalWarn;
      console.error = originalError;
    };
  }, []);
  const isInitialLoadComplete = useRef<Record<string, boolean>>({});

  const [voiceEnabled, setVoiceEnabled] = useState(false);
  const [selectedModel, setSelectedModel] = useState(ALL_GEMINI_MODELS[0].id);
  const [themeSettings, setThemeSettings] =
    useState<ThemeSettings>(DEFAULT_THEME);
  const [openSettingTab, setOpenSettingTab] = useState<"ai" | "system">("ai");
  const [isMultiplyMode, setIsMultiplyMode] = useState(false);
  const [selectedMultiplyModels, setSelectedMultiplyModels] = useState<
    string[]
  >([]);

  const [currentView, setCurrentView] = useState<"local" | "global">("local");

  // NEW: API Key Management State
  const [apiKeys, setApiKeys] = useState<string[]>([]);
  const [currentApiKeyIndex, setCurrentApiKeyIndex] = useState(0);
  const [newApiKeyInput, setNewApiKeyInput] = useState("");
  const [reasoningEnabled, setReasoningEnabled] = useState(true);
  const [legacyStreamingEnabled, setLegacyStreamingEnabled] = useState(false);

  // NEW: API Mode & OpenRouter Integration State
  const [apiMode, setApiMode] = useState<"gemini" | "openrouter">("gemini");
  const [openRouterKey, setOpenRouterKey] = useState("");
  const [openRouterModel, setOpenRouterModel] = useState(
    "meta-llama/llama-3-8b-instruct:free",
  );
  const [openRouterBaseUrl, setOpenRouterBaseUrl] = useState(
    "https://openrouter.ai/api/v1",
  );

  // NEW: Key Testing States
  const [openRouterTestStatus, setOpenRouterTestStatus] = useState<"idle" | "testing" | "success" | "error">("idle");
  const [openRouterTestMessage, setOpenRouterTestMessage] = useState("");
  const [inputKeyTestStatus, setInputKeyTestStatus] = useState<"idle" | "testing" | "success" | "error">("idle");
  const [inputKeyTestMessage, setInputKeyTestMessage] = useState("");
  const [geminiKeysTestStatus, setGeminiKeysTestStatus] = useState<Record<string, "idle" | "testing" | "success" | "error">>({});
  const [geminiKeysTestMessage, setGeminiKeysTestMessage] = useState<Record<string, string>>({});

  const chatContainerRef = useRef<HTMLDivElement>(null);
  const stopStream = useRef(false);

  const bgFileInputRef = useRef<HTMLInputElement>(null);
  const fontFileInputRef = useRef<HTMLInputElement>(null);
  const userAvatarInputRef = useRef<HTMLInputElement>(null);
  const modelAvatarInputRef = useRef<HTMLInputElement>(null);

  const isProcessingFiles = attachedFiles.some(
    (f) => f.processingStatus === "processing",
  );

  // Auto-save conversations, active conversation ID, and all principal configurations
  useEffect(() => {
    if (isDataLoaded) {
      const saveTimeout = setTimeout(async () => {
        try {
          if (conversations.length > 0) {
            await saveAppState("conversations", conversations);
          }
          await saveAppState("activeConversationId", activeConversationId);
          await saveAppState("googleSearchEnabled", googleSearchEnabled);
          await saveAppState("themeSettings", themeSettings);
          await saveAppState("selectedModel", selectedModel);
          await saveAppState("apiKeys", apiKeys);
          await saveAppState("currentApiKeyIndex", currentApiKeyIndex);
          await saveAppState("reasoningEnabled", reasoningEnabled);
          await saveAppState("legacyStreamingEnabled", legacyStreamingEnabled);
          await saveAppState("apiMode", apiMode);
          await saveAppState("openRouterKey", openRouterKey);
          await saveAppState("openRouterModel", openRouterModel);
          await saveAppState("openRouterBaseUrl", openRouterBaseUrl);
        } catch (error) {
          console.error("Auto-save failed:", error);
        }
      }, 1000); // Shorter debounce (1 second) for near-instant persistence

      return () => clearTimeout(saveTimeout);
    }
  }, [
    conversations,
    activeConversationId,
    googleSearchEnabled,
    themeSettings,
    selectedModel,
    apiKeys,
    currentApiKeyIndex,
    reasoningEnabled,
    legacyStreamingEnabled,
    apiMode,
    openRouterKey,
    openRouterModel,
    openRouterBaseUrl,
    isDataLoaded,
  ]);

  const base64ToBlob = async (
    base64: string,
    mimeType: string,
  ): Promise<Blob> => {
    const response = await fetch(`data:${mimeType};base64,${base64}`);
    return await response.blob();
  };

  useEffect(() => {
    const loadUnsentData = async () => {
      if (activeConversationId && isDataLoaded) {
        // Reset load state for this specific conversation to prevent race conditions
        isInitialLoadComplete.current[activeConversationId] = false;

        // Clear current UI state to avoid showing stale data from previous convo
        setInput("");
        setAttachedFiles([]);

        const savedInput = await getAppState<string>(
          `unsentMessage_${activeConversationId}`,
        );
        if (savedInput !== null) {
          setInput(savedInput);
        }

        const savedFiles = await getAppState<any[]>(
          `unsentFiles_${activeConversationId}`,
        );
        if (savedFiles) {
          try {
            const reconstructedFiles = await Promise.all(
              savedFiles.map(async (f: any) => {
                let fileBlob: Blob | null = null;
                if (f.content) {
                  try {
                    fileBlob = await base64ToBlob(
                      f.content,
                      f.mimeType || f.type,
                    );
                  } catch (e) {
                    console.error("Failed to convert base64 to Blob", e);
                  }
                }

                const fileObj: AttachedFile = {
                  id: f.id,
                  file: fileBlob
                    ? new File([fileBlob], f.name, {
                        type: f.mimeType || f.type,
                      })
                    : ({
                        name: f.name,
                        type: f.mimeType || f.type,
                        size: 0,
                        lastModified: 0,
                      } as any),
                  name: f.name,
                  type: f.fileType,
                  content: f.content,
                  processingStatus: f.processingStatus || "done",
                  processedData: f.processedData,
                  videoSettings: f.videoSettings,
                };

                if (fileBlob) {
                  fileObj.preview = URL.createObjectURL(fileObj.file);
                } else if (
                  f.content &&
                  (f.fileType === "image" || f.fileType === "audio")
                ) {
                  fileObj.preview = `data:${f.mimeType || f.type};base64,${f.content}`;
                } else if (
                  f.processedData &&
                  f.processedData.length > 0 &&
                  f.processedData[0].inlineData?.data
                ) {
                  fileObj.preview = `data:image/jpeg;base64,${f.processedData[0].inlineData.data}`;
                }

                return fileObj;
              }),
            );
            setAttachedFiles(reconstructedFiles);
          } catch (e) {
            console.error("Failed to parse saved files from IndexedDB", e);
          }
        }

        // Mark as complete so the save effects can now track changes
        isInitialLoadComplete.current[activeConversationId] = true;
      }
    };
    loadUnsentData();
  }, [activeConversationId, isDataLoaded]);

  useEffect(() => {
    if (
      activeConversationId &&
      isDataLoaded &&
      isInitialLoadComplete.current[activeConversationId]
    ) {
      const saveInput = async () => {
        await saveAppState(
          `unsentMessage_${activeConversationId}`,
          input || "",
        );
      };
      saveInput();
    }
  }, [input, activeConversationId, isDataLoaded]);

  useEffect(() => {
    if (
      activeConversationId &&
      isDataLoaded &&
      isInitialLoadComplete.current[activeConversationId]
    ) {
      // Guard: Do not save files to db while they are actively extracting frames in progress!
      if (attachedFiles.some((f) => f.processingStatus === "processing")) {
        return;
      }
      const saveFiles = async () => {
        if (attachedFiles.length > 0) {
          const serializableFiles = attachedFiles.map((f) => ({
            id: f.id,
            name: f.name,
            mimeType: f.file.type,
            content: f.content,
            fileType: f.type,
            processingStatus: f.processingStatus,
            processedData: f.processedData,
            videoSettings: f.videoSettings,
          }));
          await saveAppState(
            `unsentFiles_${activeConversationId}`,
            serializableFiles,
          );
        } else {
          await saveAppState(`unsentFiles_${activeConversationId}`, null);
        }
      };
      saveFiles();
    }
  }, [attachedFiles, activeConversationId, isDataLoaded]);

  const getFullGenerationConfig = useCallback(
    (reasoning: boolean, convoOverride?: Conversation) => {
      const convo =
        convoOverride ||
        conversations.find((c) => c.id === activeConversationId);
      const isRp = convo && !!convo.characterId;

      let temperature = GENERATION_CONFIG.temperature;
      let topP = GENERATION_CONFIG.topP;
      let topK = GENERATION_CONFIG.topK;
      let maxOutputTokens = GENERATION_CONFIG.maxOutputTokens;

      if (isRp) {
        const activePreset =
          presets.find((p) => p.id === activePresetId) || presets[0];
        if (activePreset) {
          temperature = activePreset.temperature;
          topP = activePreset.top_p;
          topK = activePreset.top_k;
          maxOutputTokens = activePreset.max_new_tokens;
        }
      }

      const config: any = {
        temperature,
        topP,
        topK,
        safetySettings: [
          {
            category: HarmCategory.HARM_CATEGORY_HARASSMENT,
            threshold: HarmBlockThreshold.OFF,
          },
          {
            category: HarmCategory.HARM_CATEGORY_HATE_SPEECH,
            threshold: HarmBlockThreshold.OFF,
          },
          {
            category: HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT,
            threshold: HarmBlockThreshold.OFF,
          },
          {
            category: HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT,
            threshold: HarmBlockThreshold.OFF,
          },
          {
            category: HarmCategory.HARM_CATEGORY_CIVIC_INTEGRITY,
            threshold: HarmBlockThreshold.OFF,
          },
        ],
      };

      if (maxOutputTokens && maxOutputTokens > 0) {
        config.maxOutputTokens = maxOutputTokens;
      }

      const supportedModels = ["gemini-2.5", "gemini-3"];
      if (supportedModels.some((prefix) => selectedModel.startsWith(prefix))) {
        config.thinkingConfig = reasoning
          ? { thinkingBudget: 32768 }
          : { thinkingBudget: 0 };
      }
      return config;
    },
    [
      selectedModel,
      presets,
      activePresetId,
      conversations,
      activeConversationId,
    ],
  );

  const processVideoFile = async (fileToProcess: AttachedFile) => {
    if (!fileToProcess || !fileToProcess.file || !fileToProcess.videoSettings)
      return;

    const MAX_VIDEO_PAYLOAD = 20 * 1024 * 1024; // 20MB limit for frames

    try {
      const video = document.createElement("video");
      video.src = URL.createObjectURL(fileToProcess.file);
      video.muted = true;

      await new Promise<void>((resolve, reject) => {
        video.onloadedmetadata = async () => {
          const settings = fileToProcess.videoSettings || {};
          const start = parseTime(settings.startTime) || 0;
          const end = parseTime(settings.endTime) || video.duration;
          const rawFps = parseFloat(settings.fps || "1");

          const timestamps: number[] = [];
          for (let t = start; t < end; t += 1 / rawFps) {
            timestamps.push(t);
          }

          const totalFrames = timestamps.length;
          if (totalFrames === 0) {
            setAttachedFiles((prev) =>
              prev.map((f) =>
                f.id === fileToProcess.id
                  ? {
                      ...f,
                      processingStatus: "done",
                      processedData: [],
                      processingProgress: 100,
                    }
                  : f,
              ),
            );
            try {
              video.src = "";
              video.load();
              URL.revokeObjectURL(video.src);
            } catch (e) {}
            resolve();
            return;
          }

          const canvas = document.createElement("canvas");
          const context = canvas.getContext("2d");
          const frames: MessagePart[] = [];
          let currentPayloadSize = 0;

          let lastProgressUpdate = 0;
          let lastProgress = 0;

          try {
            for (let currentIdx = 0; currentIdx < totalFrames; currentIdx++) {
              if (currentPayloadSize >= MAX_VIDEO_PAYLOAD) {
                console.warn(
                  `Video processing stopped early for ${fileToProcess.name}: Payload limit reached.`,
                );
                break;
              }

              video.currentTime = timestamps[currentIdx];

              await new Promise<void>((resSeek) => {
                video.onseeked = () => resSeek();
                video.onerror = () => resSeek();
              });

              if (context) {
                const MAX_DIM = 384;
                let w = video.videoWidth;
                let h = video.videoHeight;
                if (w > MAX_DIM || h > MAX_DIM) {
                  const ratio = Math.min(MAX_DIM / w, MAX_DIM / h);
                  w = Math.floor(w * ratio);
                  h = Math.floor(h * ratio);
                }
                canvas.width = w;
                canvas.height = h;
                context.drawImage(video, 0, 0, w, h);

                const base64Data = canvas
                  .toDataURL("image/jpeg", 0.5)
                  .split(",")[1];
                currentPayloadSize += base64Data.length * 0.75;
                frames.push({
                  inlineData: { mimeType: "image/jpeg", data: base64Data },
                });
              }

              const progress = Math.round(
                ((currentIdx + 1) / totalFrames) * 100,
              );
              const now = Date.now();
              if (
                progress - lastProgress >= 5 ||
                now - lastProgressUpdate >= 300 ||
                progress === 100
              ) {
                lastProgress = progress;
                lastProgressUpdate = now;
                setAttachedFiles((prev) =>
                  prev.map((f) =>
                    f.id === fileToProcess.id
                      ? { ...f, processingProgress: progress }
                      : f,
                  ),
                );
              }

              await new Promise<void>((resPause) => setTimeout(resPause, 20));
            }

            setAttachedFiles((prev) =>
              prev.map((f) =>
                f.id === fileToProcess.id
                  ? {
                      ...f,
                      processingStatus: "done",
                      processedData: frames,
                      processingProgress: 100,
                    }
                  : f,
              ),
            );
          } catch (err) {
            console.error("Error during sequential frame extraction:", err);
            setAttachedFiles((prev) =>
              prev.map((f) =>
                f.id === fileToProcess.id
                  ? {
                      ...f,
                      processingStatus: "error",
                      errorMessage:
                        err instanceof Error
                          ? err.message
                          : "Error extracting frames",
                    }
                  : f,
              ),
            );
          } finally {
            canvas.width = 0;
            canvas.height = 0;
            const objectUrl = video.src;
            video.src = "";
            video.load();
            try {
              URL.revokeObjectURL(objectUrl);
            } catch (e) {}
            resolve();
          }
        };

        video.onerror = () => {
          reject(
            new Error(
              "Failed to load video file. It may be corrupted or in an unsupported format.",
            ),
          );
        };
      });
    } catch (error) {
      setAttachedFiles((prev) =>
        prev.map((f) =>
          f.id === fileToProcess.id
            ? {
                ...f,
                processingStatus: "error",
                errorMessage:
                  error instanceof Error
                    ? error.message
                    : "Unknown video processing error",
              }
            : f,
        ),
      );
    }
  };

  useEffect(() => {
    attachedFiles.forEach((file) => {
      if (
        file.type === "video" &&
        file.processingStatus === "pending" &&
        file.videoSettings
      ) {
        setAttachedFiles((prev) =>
          prev.map((f) =>
            f.id === file.id
              ? { ...f, processingStatus: "processing", processingProgress: 0 }
              : f,
          ),
        );
        processVideoFile(file);
      }
    });
  }, [attachedFiles]);

  useEffect(() => {
    const loadAppData = async () => {
      let migrationMessages: Message[] = [];
      try {
        let convosFromDB = await getAppState<Conversation[]>("conversations");

        if (!convosFromDB) {
          const savedConversations = localStorage.getItem("conversations");
          if (savedConversations) {
            console.log("Migrating data from localStorage to IndexedDB...");
            migrationMessages.push({
              id: generateId(),
              role: Role.MODEL,
              parts: [
                {
                  text: `[SYSTEM] Migrating conversation history to a more stable local database to prevent data loss...`,
                },
              ],
              context: { timestamp: Date.now() },
            });

            const parsedConvos = JSON.parse(savedConversations);
            if (Array.isArray(parsedConvos) && parsedConvos.length > 0) {
              convosFromDB = parsedConvos;
              await saveAppState("conversations", parsedConvos);

              const savedActiveId = localStorage.getItem(
                "activeConversationId",
              );
              if (savedActiveId)
                await saveAppState("activeConversationId", savedActiveId);

              const savedTheme = localStorage.getItem("themeSettings");
              if (savedTheme)
                await saveAppState("themeSettings", JSON.parse(savedTheme));

              const savedApiKeys = localStorage.getItem("apiKeys");
              if (savedApiKeys)
                await saveAppState("apiKeys", JSON.parse(savedApiKeys));

              const savedKeyIndex = localStorage.getItem("currentApiKeyIndex");
              if (savedKeyIndex)
                await saveAppState(
                  "currentApiKeyIndex",
                  parseInt(savedKeyIndex, 10),
                );

              localStorage.removeItem("conversations");
              localStorage.removeItem("activeConversationId");
              localStorage.removeItem("apiKeys");
              localStorage.removeItem("currentApiKeyIndex");
              migrationMessages.push({
                id: generateId(),
                role: Role.MODEL,
                parts: [{ text: `[SYSTEM] Migration complete.` }],
                context: { timestamp: Date.now() },
              });
              console.log("Migration complete.");
            }
          }
        }

        const activeIdFromDB = await getAppState<string>(
          "activeConversationId",
        );
        const themeFromDB = await getAppState<ThemeSettings>("themeSettings");
        const apiKeysFromDB = await getAppState<string[]>("apiKeys");
        const keyIndexFromDB = await getAppState<number>("currentApiKeyIndex");
        const reasoningFromDB = await getAppState<boolean>("reasoningEnabled");
        const legacyStreamingFromDB = await getAppState<boolean>("legacyStreamingEnabled");
        const searchFromDB = await getAppState<boolean>("googleSearchEnabled");
        const selectedModelFromDB = await getAppState<string>("selectedModel");

        if (themeFromDB) {
          setThemeSettings((prev) => ({ ...prev, ...themeFromDB }));
        } else {
          const savedTheme = localStorage.getItem("themeSettings");
          if (savedTheme)
            setThemeSettings((prev) => ({
              ...prev,
              ...JSON.parse(savedTheme),
            }));
        }

        let initialKeys: string[] = [];

        if (apiKeysFromDB && apiKeysFromDB.length > 0) {
          initialKeys = apiKeysFromDB;
        }
        setApiKeys(initialKeys);

        if (keyIndexFromDB !== null) setCurrentApiKeyIndex(keyIndexFromDB);
        if (reasoningFromDB !== null) setReasoningEnabled(reasoningFromDB);
        if (legacyStreamingFromDB !== undefined && legacyStreamingFromDB !== null) setLegacyStreamingEnabled(legacyStreamingFromDB);
        if (searchFromDB !== null) setGoogleSearchEnabled(searchFromDB);
        if (selectedModelFromDB) setSelectedModel(selectedModelFromDB);

        const apiModeFromDB = await getAppState<"gemini" | "openrouter">(
          "apiMode",
        );
        const openRouterKeyFromDB = await getAppState<string>("openRouterKey");
        const openRouterModelFromDB =
          await getAppState<string>("openRouterModel");
        const openRouterBaseUrlFromDB =
          await getAppState<string>("openRouterBaseUrl");

        if (apiModeFromDB) setApiMode(apiModeFromDB);
        if (openRouterKeyFromDB) setOpenRouterKey(openRouterKeyFromDB);
        if (openRouterModelFromDB) setOpenRouterModel(openRouterModelFromDB);
        if (openRouterBaseUrlFromDB)
          setOpenRouterBaseUrl(openRouterBaseUrlFromDB);

        const chubCharsFromDB =
          await getAppState<ChubCharacter[]>("chub_characters");
        if (chubCharsFromDB) {
          setChubCharacters(chubCharsFromDB);
        }

        const savedLbs =
          (await getAppState<Lorebook[]>("chub_lorebooks")) || [];
        const savedActiveLbId =
          (await getAppState<string>("active_lorebook_id")) || null;
        const savedActiveLbIds =
          (await getAppState<string[]>("active_lorebook_ids")) || (savedActiveLbId ? [savedActiveLbId] : []);
        const savedPresets =
          (await getAppState<Preset[]>("chub_presets")) || [];
        const savedActivePresetId =
          (await getAppState<string>("active_preset_id")) || null;

        let finalLbs = savedLbs;
        if (savedLbs.length === 0) {
          finalLbs = [DEFAULT_LOREBOOK];
          await saveAppState("chub_lorebooks", finalLbs);
        }
        setLorebooks(finalLbs);
        setActiveLorebookId(savedActiveLbId || finalLbs[0]?.id || null);
        setActiveLorebookIds(savedActiveLbIds.length > 0 ? savedActiveLbIds : (finalLbs[0] ? [finalLbs[0].id] : []));

        let finalPresets = savedPresets;
        if (savedPresets.length === 0) {
          finalPresets = [DEFAULT_PRESET];
          await saveAppState("chub_presets", finalPresets);
        } else {
          let migrated = false;
          finalPresets = finalPresets.map((p) => {
            if (p.id === 'default-immersion' && (!p.post_history_instructions || p.post_history_instructions.trim() === '')) {
              migrated = true;
              return { ...p, post_history_instructions: DEFAULT_PRESET.post_history_instructions };
            }
            return p;
          });
          if (migrated) {
            await saveAppState("chub_presets", finalPresets);
          }
        }
        setPresets(finalPresets);
        setActivePresetId(savedActivePresetId || finalPresets[0]?.id || null);

        const userPersonasFromDB =
          await getAppState<UserPersona[]>("user_personas");
        const userPersonaFromDB =
          await getAppState<UserPersona>("user_persona");

        let loadedPersonas: UserPersona[] = [];
        let activePersona: UserPersona;

        if (userPersonasFromDB && userPersonasFromDB.length > 0) {
          loadedPersonas = userPersonasFromDB.map((p) => ({
            ...p,
            id: p.id || Math.random().toString(36).substring(2, 11),
          }));
          activePersona =
            userPersonaFromDB ||
            loadedPersonas.find((p) => p.isDefault) ||
            loadedPersonas[0];
        } else if (userPersonaFromDB) {
          const legacyWithId = {
            id: "default",
            name: userPersonaFromDB.name || "User",
            description:
              userPersonaFromDB.description ||
              "A human user interacting with the character.",
            avatar: userPersonaFromDB.avatar,
            isDefault: true,
          };
          loadedPersonas = [legacyWithId];
          activePersona = legacyWithId;
        } else {
          const defaultPersona = {
            id: "default",
            name: "User",
            description: "A human user interacting with the character.",
            isDefault: true,
          };
          loadedPersonas = [defaultPersona];
          activePersona = defaultPersona;
        }

        setUserPersonas(loadedPersonas);
        setUserPersona(activePersona);

        await saveAppState("user_personas", loadedPersonas);
        await saveAppState("user_persona", activePersona);

        if (convosFromDB && convosFromDB.length > 0) {
          if (migrationMessages.length > 0 && convosFromDB[0]) {
            convosFromDB[0].messages.unshift(...migrationMessages);
          }
          setConversations(convosFromDB);
          const activeIdExists = convosFromDB.some(
            (c) => c.id === activeIdFromDB,
          );
          setActiveConversationId(
            activeIdExists ? activeIdFromDB : convosFromDB[0].id,
          );
        } else {
          createNewConversation(true);
        }
      } catch (error) {
        console.error("Failed to load app data:", error);
        createNewConversation(true);
      } finally {
        setIsDataLoaded(true);
      }
    };

    loadAppData();
  }, []);

  const handleSaveCharacters = async (newChars: ChubCharacter[]) => {
    setChubCharacters(newChars);
    await saveAppState("chub_characters", newChars);
  };

  const handleSaveUserPersona = async (newPersona: UserPersona) => {
    setUserPersona(newPersona);
    await saveAppState("user_persona", newPersona);
  };

  const handleSaveUserPersonas = async (
    newPersonas: UserPersona[],
    activePersona: UserPersona,
  ) => {
    setUserPersonas(newPersonas);
    setUserPersona(activePersona);
    await saveAppState("user_personas", newPersonas);
    await saveAppState("user_persona", activePersona);
  };

  const startCharacterRoleplay = (character: ChubCharacter) => {
    const activePreset =
      presets.find((p) => p.id === activePresetId) || presets[0];
    const activeLbs = lorebooks.filter((lb) => activeLorebookIds.includes(lb.id));
    const lorebookContext = getLorebookContext([], activeLbs, activePreset);
    const customInstruction = buildCharacterSystemInstruction(
      character,
      userPersona,
      activePreset,
      lorebookContext,
    );
    const rawGreeting = character.first_mes || `Hello! I am ${character.name}.`;
    const processedGreeting = replacePlaceholders(
      rawGreeting,
      character.name,
      userPersona.name,
    );

    const greetingMsg: Message = {
      id: generateId(),
      role: Role.MODEL,
      parts: [{ text: processedGreeting }],
    };

    const newConvo: Conversation = {
      id: generateId(),
      name: `RP: ${character.name}`,
      messages: [greetingMsg],
      characterId: character.id,
      characterSystemPrompt: customInstruction,
      characterAvatar: character.avatar,
      selectedGreetingIndex: 0,
    };

    isInitialLoadComplete.current[newConvo.id] = true;
    setConversations((prev) => [newConvo, ...prev]);
    setActiveConversationId(newConvo.id);
    setChubModalOpen(false);
  };

  const cycleGreeting = (direction: "prev" | "next") => {
    const activeConvo = conversations.find(
      (c) => c.id === activeConversationId,
    );
    if (!activeConvo || !activeConvo.characterId) return;

    const character = chubCharacters.find(
      (c) => c.id === activeConvo.characterId,
    );
    if (!character) return;

    const greetings = [
      character.first_mes || `Hello! I am ${character.name}.`,
      ...(character.alternate_greetings || []),
    ].filter(Boolean);
    if (greetings.length <= 1) return;

    let currentIndex = activeConvo.selectedGreetingIndex || 0;
    let nextIndex = currentIndex;
    if (direction === "prev") {
      nextIndex = (currentIndex - 1 + greetings.length) % greetings.length;
    } else {
      nextIndex = (currentIndex + 1) % greetings.length;
    }

    const processedGreeting = replacePlaceholders(
      greetings[nextIndex],
      character.name,
      userPersona.name,
    );

    setConversations((prev) =>
      prev.map((convo) => {
        if (convo.id === activeConvo.id) {
          const updatedMessages = [...convo.messages];
          if (updatedMessages[0]) {
            updatedMessages[0] = {
              ...updatedMessages[0],
              parts: [{ text: processedGreeting }],
            };
          }
          return {
            ...convo,
            messages: updatedMessages,
            selectedGreetingIndex: nextIndex,
          };
        }
        return convo;
      }),
    );
  };

  const handleSaveProject = async () => {
    try {
      setLoadingMessage("Saving Project...");
      await saveAppState("conversations", conversations);
      await saveAppState("activeConversationId", activeConversationId);
      await saveAppState("themeSettings", themeSettings);
      await saveAppState("apiKeys", apiKeys);
      await saveAppState("currentApiKeyIndex", currentApiKeyIndex);
      await saveAppState("reasoningEnabled", reasoningEnabled);
      await saveAppState("googleSearchEnabled", googleSearchEnabled);
      addSystemMessage("Project saved successfully to local database.");
    } catch (e) {
      console.error("Failed to save app state to IndexedDB:", e);
      alert("Failed to save project. Check console for details.");
    } finally {
      setLoadingMessage("");
    }
  };

  useEffect(() => {
    localStorage.setItem("themeSettings", JSON.stringify(themeSettings));

    document.body.style.fontFamily = themeSettings.fontFamily;
    Object.entries(themeSettings).forEach(([key, value]) => {
      if (key.startsWith("--")) {
        document.documentElement.style.setProperty(key, value as string);
      }
    });
    const styleEl = document.getElementById("custom-fonts-style");
    if (styleEl) {
      styleEl.innerHTML = themeSettings.customFonts
        .map(
          (font) =>
            `@font-face { font-family: "${font.name}"; src: ${font.url}; }`,
        )
        .join("\n");
    } else {
      const newStyle = document.createElement("style");
      newStyle.id = "custom-fonts-style";
      newStyle.innerHTML = themeSettings.customFonts
        .map(
          (font) =>
            `@font-face { font-family: "${font.name}"; src: ${font.url}; }`,
        )
        .join("\n");
      document.head.appendChild(newStyle);
    }
  }, [themeSettings]);

  const getCurrentApiKey = () =>
    apiKeys[currentApiKeyIndex] || process.env.API_KEY || "";

  const initChat = useCallback(
    async (historyOverride?: any[]) => {
      try {
        const apiKey = getCurrentApiKey();
        if (!apiKey) throw new Error("API Key is not configured.");
        const ai = new GoogleGenAI({ apiKey });

        const convo = conversations.find((c) => c.id === activeConversationId);
        const messages = historyOverride ?? convo?.messages ?? [];

        const resolvedHistory = await resolveHistory(messages);

        const newChat = ai.chats.create({
          model: selectedModel,
          history: resolvedHistory,
          config: {
            systemInstruction: getSystemInstruction(convo),
            ...getFullGenerationConfig(reasoningEnabled, convo),
            tools: googleSearchEnabled ? [{ googleSearch: {} }] : [],
          },
        });
        setChat(newChat);
      } catch (e) {
        console.error("Failed to initialize chat:", e);
      }
    },
    [
      activeConversationId,
      conversations,
      selectedModel,
      apiKeys,
      currentApiKeyIndex,
      reasoningEnabled,
      getFullGenerationConfig,
    ],
  );

  useEffect(() => {
    if (!editingMessageId) initChat();
  }, [activeConversationId, selectedModel, initChat, editingMessageId]);

  useEffect(() => {
    if (chatContainerRef.current)
      chatContainerRef.current.scrollTop =
        chatContainerRef.current.scrollHeight;
  }, [conversations, isLoading]);

  const addSystemMessage = (text: string) => {
    updateMessages((prev) => [
      ...prev,
      {
        id: generateId(),
        role: Role.MODEL,
        parts: [{ text: `[SYSTEM] ${text}` }],
        context: { timestamp: Date.now() },
      },
    ]);
  };

  const withApiKeyRotation = async <T,>(
    apiCall: (apiKey: string) => Promise<T>,
  ): Promise<T> => {
    let lastError: any = null;
    if (apiKeys.length === 0) {
      throw new Error("No API Keys configured. Please add one in Settings.");
    }

    let startIndex = currentApiKeyIndex;

    for (let i = 0; i < apiKeys.length; i++) {
      const keyIndexToTry = (startIndex + i) % apiKeys.length;
      const apiKeyToTry = apiKeys[keyIndexToTry];

      try {
        const result = await apiCall(apiKeyToTry);
        if (keyIndexToTry !== currentApiKeyIndex) {
          setCurrentApiKeyIndex(keyIndexToTry);
        }
        return result;
      } catch (error) {
        lastError = error;
        let errorMessage =
          error instanceof Error ? error.message : String(error);

        // Handle JSON error strings from the SDK
        if (errorMessage.includes("{")) {
          try {
            const startIdx = errorMessage.indexOf("{");
            const endIdx = errorMessage.lastIndexOf("}") + 1;
            const jsonStr = errorMessage.substring(startIdx, endIdx);
            const parsed = JSON.parse(jsonStr);
            if (parsed.error?.message) errorMessage = parsed.error.message;
          } catch (e) {
            /* ignore parsing errors */
          }
        }

        if (
          errorMessage.includes("429") ||
          errorMessage.includes("RESOURCE_EXHAUSTED") ||
          errorMessage.toLowerCase().includes("quota")
        ) {
          addSystemMessage(
            `API key #${keyIndexToTry + 1} is rate-limited. Switching to next key...`,
          );
          // Continue to next key in the loop
        } else {
          // Not a rate limit error, fail immediately
          throw error;
        }
      }
    }
    // If we loop through all keys and they all fail
    throw lastError;
  };

  const updateMessages = (updater: (prevMessages: Message[]) => Message[]) => {
    setConversations((prev) =>
      prev.map((c) =>
        c.id === activeConversationId
          ? { ...c, messages: updater(c.messages) }
          : c,
      ),
    );
  };

  const streamResponseAndUpdateState = async (
    initialStream: AsyncGenerator<any>,
    responseId: string,
  ) => {
    let fullText = "";
    let finalGroundingChunks: GroundingChunk[] | undefined;

    const activePreset = presets.find((p) => p.id === activePresetId) || presets[0];
    const isLegacyStreaming = activePreset?.legacy_streaming || legacyStreamingEnabled;

    try {
      for await (const chunk of initialStream) {
        if (stopStream.current) break;
        const chunkText = getSafeChunkText(chunk);
        if (chunkText) {
          fullText += chunkText;
          if (!isLegacyStreaming) {
            const scrubbedFullText = applyOutputScrubbing(fullText);
            updateMessages((prev) =>
              prev.map((msg) =>
                msg.id === responseId
                  ? { ...msg, parts: [{ text: scrubbedFullText }] }
                  : msg,
              ),
            );
          } else {
            updateMessages((prev) =>
              prev.map((msg) =>
                msg.id === responseId && (!msg.parts[0]?.text || !msg.parts[0].text.startsWith("*WormGPT"))
                  ? { ...msg, parts: [{ text: "*WormGPT is generating response (Buffered Legacy Streaming)...*" }] }
                  : msg,
              ),
            );
          }
        }
        if (chunk.candidates?.[0]?.groundingMetadata?.groundingChunks) {
          finalGroundingChunks =
            chunk.candidates[0].groundingMetadata.groundingChunks;
        }
      }

      if (finalGroundingChunks) {
        updateMessages((prev) =>
          prev.map((msg) =>
            msg.id === responseId
              ? { ...msg, groundingChunks: finalGroundingChunks }
              : msg,
          ),
        );
      }
    } catch (err) {
      console.error("Streaming failed:", err);
    }

    if (isLegacyStreaming) {
      const scrubbedFullText = applyOutputScrubbing(fullText);
      updateMessages((prev) =>
        prev.map((msg) =>
          msg.id === responseId
            ? { ...msg, parts: [{ text: scrubbedFullText || "*Generation stopped.*" }] }
            : msg,
        ),
      );
    }
  };

  const createNewConversation = (isInitial = false) => {
    const newConvo: Conversation = {
      id: generateId(),
      name: "New Chat",
      messages: [],
    };
    isInitialLoadComplete.current[newConvo.id] = true;
    if (isInitial) setConversations([newConvo]);
    else setConversations((prev) => [newConvo, ...prev]);
    setActiveConversationId(newConvo.id);
    setHistoryOpen(false);
  };

  const deleteConversation = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const convoToDelete = conversations.find((c) => c.id === id);
    if (convoToDelete) {
      convoToDelete.messages.forEach((msg) => {
        msg.parts.forEach((part) => {
          if (part.inlineData?.dbKey) {
            deleteLargeData(part.inlineData.dbKey).catch(console.error);
          }
        });
      });
    }
    const newConvos = conversations.filter((c) => c.id !== id);
    setConversations(newConvos);
    if (activeConversationId === id) {
      if (newConvos.length > 0) setActiveConversationId(newConvos[0].id);
      else createNewConversation(true);
    }
  };

  const speak = (text: string) => {
    if (!voiceEnabled || !text) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    window.speechSynthesis.speak(utterance);
  };

  const handleAddFiles = (newFiles: AttachedFile[]) => {
    for (const file of newFiles) {
      if (file.type === "video" && !file.videoSettings) {
        setVideoToConfigure(file);
      } else {
        setAttachedFiles((prev) => [...prev, file]);
      }
    }
  };

  const handleSaveVideoSettings = (settings: VideoSettings) => {
    if (!videoToConfigure) return;
    setAttachedFiles((prev) => [
      ...prev,
      {
        ...videoToConfigure,
        videoSettings: settings,
        processingStatus: "pending",
      },
    ]);
    setVideoToConfigure(null);
  };

  const handleApiError = async (error: unknown) => {
    console.error("Generation error:", error);
    let errorMessage = "An unknown error occurred.";
    if (typeof error === "string") {
      errorMessage = error;
    } else if (error instanceof Error) {
      errorMessage = error.message;
    }

    // Handle JSON error strings from the SDK
    if (errorMessage.includes("{")) {
      try {
        const startIdx = errorMessage.indexOf("{");
        const endIdx = errorMessage.lastIndexOf("}") + 1;
        const jsonStr = errorMessage.substring(startIdx, endIdx);
        const parsed = JSON.parse(jsonStr);
        if (parsed.error?.message) errorMessage = parsed.error.message;
      } catch (e) {
        /* ignore */
      }
    }

    if (
      errorMessage.includes("429") ||
      errorMessage.includes("RESOURCE_EXHAUSTED") ||
      errorMessage.toLowerCase().includes("quota")
    ) {
      errorMessage =
        "ALL API KEYS ARE RATE-LIMITED. Please wait a minute or add more keys in Settings.";
    }

    const errorContext = await getDeviceContext();
    updateMessages((prev) => [
      ...prev,
      {
        id: generateId(),
        role: Role.MODEL,
        parts: [{ text: `Error: ${errorMessage}` }],
        context: errorContext,
      },
    ]);
    initChat();
  };

  const handleSendMessage = async (textParts: MessagePart[]) => {
    if (isLoading || isProcessingFiles) return;
    setIsLoading(true);
    setLoadingMessage("");
    stopStream.current = false;

    const userMessageDisplayParts: MessagePart[] = [...textParts];
    const modelMessageParts: MessagePart[] = [...textParts];

    // --- INTEL CORE V2 ---
    const userPromptText = textParts.find((p) => p.text)?.text || "";
    let injectedIntel = "";
    const allIntel = getAllSavedIntel();
    if (allIntel.length > 0 && userPromptText) {
      const lowerCasePrompt = userPromptText.toLowerCase();
      const sortedIntel = allIntel.sort(
        (a, b) => b.name.length - a.name.length,
      );
      for (const intel of sortedIntel) {
        const naturalLanguageTag = intel.name.replace(/_/g, " ");
        if (lowerCasePrompt.includes(naturalLanguageTag))
          injectedIntel += intel.content + "\n\n";
      }
    }
    if (injectedIntel)
      modelMessageParts.unshift({
        text: `:::SYSTEM_CONTEXT:::\n${injectedIntel}\n:::END_SYSTEM_CONTEXT:::`,
      });
    // --- END INTEL CORE V2 ---

    for (const file of attachedFiles) {
      if ((file.type === "image" || file.type === "audio") && file.content) {
        const dbKey = await storeLargeData(file.content);
        userMessageDisplayParts.push({
          inlineData: { mimeType: file.file.type, dbKey: dbKey as number },
        });
        modelMessageParts.push({
          inlineData: { mimeType: file.file.type, data: file.content },
        });
      } else if (file.type === "video" && file.processingStatus === "done") {
        userMessageDisplayParts.push({
          text: `\n[Attached Video: ${file.name}]`,
        });
        if (file.processedData) {
          // Store frames in parallel for lightning-fast database writes and ZERO blocking!
          const storePromises = file.processedData.map(async (framePart) => {
            if (framePart.inlineData?.data) {
              const dbKey = await storeLargeData(framePart.inlineData.data);
              return {
                displayPart: {
                  inlineData: {
                    mimeType: framePart.inlineData.mimeType,
                    dbKey: dbKey as number,
                  },
                },
                modelPart: {
                  inlineData: {
                    mimeType: framePart.inlineData.mimeType,
                    data: framePart.inlineData.data,
                  },
                },
              };
            }
            return null;
          });
          const storedParts = await Promise.all(storePromises);
          for (const part of storedParts) {
            if (part) {
              userMessageDisplayParts.push(part.displayPart);
              modelMessageParts.push(part.modelPart);
            }
          }
        }
      } else if (file.content) {
        const textContent = `\n[Attached File: ${file.name}]\n\`\`\`\n${file.content}\n\`\`\``;
        userMessageDisplayParts.push({ text: textContent });
        modelMessageParts.push({ text: textContent });
      }
    }

    const userContext = await getDeviceContext();
    const newMessage: Message = {
      id: generateId(),
      role: Role.USER,
      parts: userMessageDisplayParts,
      context: userContext,
    };
    updateMessages((prev) => [...prev, newMessage]);

    setInput("");
    if (activeConversationId) {
      saveAppState(`unsentMessage_${activeConversationId}`, "");
      saveAppState(`unsentFiles_${activeConversationId}`, null);
    }
    setAttachedFiles([]);

    try {
      const currentConvo = conversations.find(
        (c) => c.id === activeConversationId,
      );
      const isRp = currentConvo && !!currentConvo.characterId;
      let stream;

      if (apiMode === "openrouter") {
        if (!openRouterKey) {
          throw new Error(
            "OpenRouter API key is missing. Please set it in Settings.",
          );
        }
        const history = await resolveHistory(currentConvo?.messages ?? []);
        const activeUserMessage = { role: Role.USER, parts: modelMessageParts };
        const fullHistory = [...history, activeUserMessage];

        const sysInstruction = getSystemInstruction(currentConvo);
        const generationConfig = getFullGenerationConfig(
          reasoningEnabled,
          currentConvo,
        );

        stream = makeOpenRouterStream(
          openRouterKey,
          openRouterModel,
          openRouterBaseUrl,
          fullHistory,
          sysInstruction,
          generationConfig,
        );
      } else {
        stream = await withApiKeyRotation(async (apiKey) => {
          const ai = new GoogleGenAI({ apiKey });
          const history = await resolveHistory(currentConvo?.messages ?? []);

          const chat = ai.chats.create({
            model: selectedModel,
            history: history,
            config: {
              systemInstruction: getSystemInstruction(currentConvo),
              ...getFullGenerationConfig(reasoningEnabled, currentConvo),
              tools: googleSearchEnabled ? [{ googleSearch: {} }] : [],
            },
          });

          return chat.sendMessageStream({ message: modelMessageParts });
        });
      }

      const responseId = generateId();
      const modelContext = await getDeviceContext();
      updateMessages((prev) => [
        ...prev,
        {
          id: responseId,
          role: Role.MODEL,
          parts: [{ text: "" }],
          context: modelContext,
        },
      ]);

      await streamResponseAndUpdateState(stream, responseId);
    } catch (error) {
      await handleApiError(error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleEditMessage = async (messageId: string, newText: string) => {
    setEditingMessageId(null);
    const convo = conversations.find((c) => c.id === activeConversationId);
    if (!convo) return;
    const messageIndex = convo.messages.findIndex((m) => m.id === messageId);
    if (messageIndex === -1) return;

    const updatedMessages = [...convo.messages];
    const originalParts = updatedMessages[messageIndex].parts;
    const mediaParts = originalParts.filter((p) => !p.text);
    const newParts = [...mediaParts, { text: newText }];
    updatedMessages[messageIndex] = {
      ...updatedMessages[messageIndex],
      parts: newParts,
    };

    if (editingMode === "restart") {
      const truncatedMessages = updatedMessages.slice(0, messageIndex + 1);
      updateMessages(() => truncatedMessages);

      setIsLoading(true);
      setLoadingMessage("Regenerating...");
      try {
        const historyForChat = updatedMessages.slice(0, messageIndex);
        const isRp = convo && !!convo.characterId;
        let stream;

        if (apiMode === "openrouter") {
          if (!openRouterKey) {
            throw new Error(
              "OpenRouter API key is missing. Please set it in Settings.",
            );
          }
          const resolvedHistory = await resolveHistory(historyForChat);
          const resolvedPartsForSending = await resolveMessageParts(newParts);
          const activeUserMessage = {
            role: Role.USER,
            parts: resolvedPartsForSending,
          };
          const fullHistory = [...resolvedHistory, activeUserMessage];

          const sysInstruction = getSystemInstruction(convo);
          const generationConfig = getFullGenerationConfig(
            reasoningEnabled,
            convo,
          );

          stream = makeOpenRouterStream(
            openRouterKey,
            openRouterModel,
            openRouterBaseUrl,
            fullHistory,
            sysInstruction,
            generationConfig,
          );
        } else {
          stream = await withApiKeyRotation(async (apiKey) => {
            const ai = new GoogleGenAI({ apiKey: apiKey });
            const resolvedHistory = await resolveHistory(historyForChat);
            const newChat = ai.chats.create({
              model: selectedModel,
              history: resolvedHistory,
              config: {
                systemInstruction: getSystemInstruction(convo),
                ...getFullGenerationConfig(reasoningEnabled, convo),
                tools: googleSearchEnabled ? [{ googleSearch: {} }] : [],
              },
            });
            const resolvedPartsForSending = await resolveMessageParts(newParts);
            return newChat.sendMessageStream({
              message: resolvedPartsForSending,
            });
          });
        }

        const modelContext = await getDeviceContext();
        const responseId = generateId();
        updateMessages((prev) => [
          ...prev,
          {
            id: responseId,
            role: Role.MODEL,
            parts: [{ text: "" }],
            context: modelContext,
          },
        ]);
        await streamResponseAndUpdateState(stream, responseId);
      } catch (e) {
        await handleApiError(e);
      } finally {
        setIsLoading(false);
      }
    } else {
      updateMessages(() => updatedMessages);
      initChat();
    }
  };

  const handleRegenerate = async (messageId: string) => {
    const convo = conversations.find((c) => c.id === activeConversationId);
    if (!convo) return;
    const messageIndex = convo.messages.findIndex((m) => m.id === messageId);
    if (messageIndex < 1) return;
    const userMessage = convo.messages[messageIndex - 1];
    if (userMessage.role !== Role.USER) return;

    const truncatedMessages = convo.messages.slice(0, messageIndex);
    updateMessages(() => truncatedMessages);
    const historyForChat = truncatedMessages.slice(0, -1);

    setIsLoading(true);
    try {
      const isRp = convo && !!convo.characterId;
      let stream;

      if (apiMode === "openrouter") {
        if (!openRouterKey) {
          throw new Error(
            "OpenRouter API key is missing. Please set it in Settings.",
          );
        }
        const resolvedHistory = await resolveHistory(historyForChat);
        const resolvedPartsForSending = await resolveMessageParts(
          userMessage.parts,
        );
        const activeUserMessage = {
          role: Role.USER,
          parts: resolvedPartsForSending,
        };
        const fullHistory = [...resolvedHistory, activeUserMessage];

        const sysInstruction = getSystemInstruction(convo);
        const generationConfig = getFullGenerationConfig(
          reasoningEnabled,
          convo,
        );

        stream = makeOpenRouterStream(
          openRouterKey,
          openRouterModel,
          openRouterBaseUrl,
          fullHistory,
          sysInstruction,
          generationConfig,
        );
      } else {
        stream = await withApiKeyRotation(async (apiKey) => {
          const ai = new GoogleGenAI({ apiKey: apiKey });
          const resolvedHistory = await resolveHistory(historyForChat);
          const newChat = ai.chats.create({
            model: selectedModel,
            history: resolvedHistory,
            config: {
              systemInstruction: getSystemInstruction(convo),
              ...getFullGenerationConfig(reasoningEnabled, convo),
              tools: googleSearchEnabled ? [{ googleSearch: {} }] : [],
            },
          });
          const resolvedPartsForSending = await resolveMessageParts(
            userMessage.parts,
          );
          return newChat.sendMessageStream({
            message: resolvedPartsForSending,
          });
        });
      }

      const modelContext = await getDeviceContext();
      const responseId = generateId();
      updateMessages((prev) => [
        ...prev,
        {
          id: responseId,
          role: Role.MODEL,
          parts: [{ text: "" }],
          context: modelContext,
        },
      ]);
      await streamResponseAndUpdateState(stream, responseId);
    } catch (e) {
      await handleApiError(e);
    } finally {
      setIsLoading(false);
    }
  };

  const exportConversation = () => {
    const convo = conversations.find((c) => c.id === activeConversationId);
    if (!convo) return;
    const htmlContent = `<html><body><h1>${convo.name}</h1>${convo.messages.map((m) => `<div style="margin-bottom: 20px; padding: 10px; border: 1px solid #ccc; background: ${m.role === "model" ? "#f0f0f0" : "#e0e0ff"}"><strong>${m.role.toUpperCase()}:</strong><pre style="white-space: pre-wrap;">${m.parts.map((p) => p.text).join("")}</pre></div>`).join("")}</body></html>`;
    const blob = new Blob([htmlContent], { type: "text/html" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${convo.name.replace(/[^a-z0-9]/gi, "_").toLowerCase()}.html`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const downloadChatHistory = () => {
    const data = JSON.stringify(conversations, null, 2);
    const blob = new Blob([data], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `wormgpt-history-${new Date().toISOString().split("T")[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const downloadSourceCode = async () => {
    const zip = new JSZip();
    Object.entries(FULL_SOURCE_CODE).forEach(([path, content]) => {
      zip.file(path, content);
    });
    const blob = await zip.generateAsync({ type: "blob" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "wormgpt-source.zip";
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleAddApiKey = () => {
    if (newApiKeyInput.trim()) {
      setApiKeys((prev) => [...prev, newApiKeyInput.trim()]);
      setNewApiKeyInput("");
    }
  };

  const handleTestOpenRouterKey = async () => {
    if (!openRouterKey.trim()) {
      setOpenRouterTestStatus("error");
      setOpenRouterTestMessage("Please enter an OpenRouter API key first.");
      return;
    }
    setOpenRouterTestStatus("testing");
    setOpenRouterTestMessage("Testing connection...");
    try {
      const url = `${openRouterBaseUrl.replace(/\/$/, "")}/chat/completions`;
      const response = await fetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${openRouterKey.trim()}`,
          "HTTP-Referer": window.location.origin,
          "X-Title": "WormGPT Key Test",
        },
        body: JSON.stringify({
          model: openRouterModel || "meta-llama/llama-3-8b-instruct:free",
          messages: [{ role: "user", content: "ping" }],
          max_tokens: 1,
        }),
      });

      if (response.ok) {
        setOpenRouterTestStatus("success");
        setOpenRouterTestMessage("Success! Key is valid and connection established.");
      } else {
        let errorMsg = `Error status: ${response.status} (${response.statusText})`;
        try {
          const errorData = await response.json();
          if (errorData?.error?.message) {
            errorMsg = errorData.error.message;
          }
        } catch (e) {}
        setOpenRouterTestStatus("error");
        setOpenRouterTestMessage(`Failed: ${errorMsg}`);
      }
    } catch (err: any) {
      setOpenRouterTestStatus("error");
      setOpenRouterTestMessage(`Error: ${err?.message || "Network request failed"}`);
    }
  };

  const handleTestInputGeminiKey = async () => {
    if (!newApiKeyInput.trim()) {
      setInputKeyTestStatus("error");
      setInputKeyTestMessage("Please enter a Gemini API key first.");
      return;
    }
    const keyToTest = newApiKeyInput.trim();
    setInputKeyTestStatus("testing");
    setInputKeyTestMessage("Testing key...");
    try {
      const ai = new GoogleGenAI({ apiKey: keyToTest });
      await ai.models.generateContent({
        model: selectedModel || "gemini-1.5-flash",
        contents: "ping",
        config: { maxOutputTokens: 1 }
      });
      setInputKeyTestStatus("success");
      setInputKeyTestMessage("Success! Gemini API Key is valid.");
    } catch (err: any) {
      const errorMsg = err?.message || "Invalid or restricted API key";
      setInputKeyTestStatus("error");
      setInputKeyTestMessage(`Failed: ${errorMsg}`);
    }
  };

  const handleTestPoolGeminiKey = async (keyToTest: string) => {
    if (!keyToTest.trim()) return;
    setGeminiKeysTestStatus(prev => ({ ...prev, [keyToTest]: "testing" }));
    setGeminiKeysTestMessage(prev => ({ ...prev, [keyToTest]: "Testing key..." }));
    try {
      const ai = new GoogleGenAI({ apiKey: keyToTest.trim() });
      await ai.models.generateContent({
        model: selectedModel || "gemini-1.5-flash",
        contents: "ping",
        config: { maxOutputTokens: 1 }
      });
      setGeminiKeysTestStatus(prev => ({ ...prev, [keyToTest]: "success" }));
      setGeminiKeysTestMessage(prev => ({ ...prev, [keyToTest]: "Success! Key is valid." }));
    } catch (err: any) {
      const errorMsg = err?.message || "Invalid or restricted API key";
      setGeminiKeysTestStatus(prev => ({ ...prev, [keyToTest]: "error" }));
      setGeminiKeysTestMessage(prev => ({ ...prev, [keyToTest]: `Failed: ${errorMsg}` }));
    }
  };

  const handleDeleteApiKey = (index: number) => {
    setApiKeys((prev) => prev.filter((_, i) => i !== index));
    if (currentApiKeyIndex >= index) {
      setCurrentApiKeyIndex((prev) => Math.max(0, prev - 1));
    }
  };

  const handleFactoryReset = () => {
    if (
      window.confirm(
        "ARE YOU SURE?\n\nThis will permanently delete all conversations, settings, and API keys. This action cannot be undone.",
      )
    ) {
      localStorage.clear();
      indexedDB.deleteDatabase("WormGPT-Assets").onsuccess = () => {
        window.location.reload();
      };
    }
  };

  const memoizedChatHistory = useMemo(() => {
    const activeConvo = conversations.find(
      (c) => c.id === activeConversationId,
    );
    return (
      <>
        {activeConvo?.messages.length === 0 && (
          <div className="flex flex-col items-center justify-center h-full opacity-30 select-none">
            {" "}
            <WormIcon className="w-32 h-32 mb-4 text-purple-500" />{" "}
            <p className="font-orbitron text-2xl">WORMGPT IS READY</p>{" "}
          </div>
        )}
        {activeConvo?.messages.map((msg, idx, arr) => {
          const character =
            msg.role === Role.MODEL && idx === 0 && activeConvo?.characterId
              ? chubCharacters.find((c) => c.id === activeConvo.characterId)
              : null;
          const greetings = character
            ? [
                character.first_mes || "",
                ...(character.alternate_greetings || []),
              ].filter(Boolean)
            : [];
          const currentIndex = activeConvo?.selectedGreetingIndex || 0;

          return (
            <React.Fragment key={msg.id}>
              <ChatMessage
                message={msg}
                isLoading={isLoading}
                isLastMessage={idx === arr.length - 1}
                isEditing={editingMessageId === msg.id}
                editMode={editingMode}
                userAvatar={userPersona?.avatar || themeSettings.userAvatar}
                modelAvatar={
                  activeConvo?.characterAvatar || themeSettings.modelAvatar
                }
                onDelete={(id) => {
                  const convo = conversations.find(
                    (c) => c.id === activeConversationId,
                  );
                  if (convo) {
                    const messageToDelete = convo.messages.find(
                      (m) => m.id === id,
                    );
                    messageToDelete?.parts.forEach((part) => {
                      if (part.inlineData?.dbKey) {
                        deleteLargeData(part.inlineData.dbKey).catch(
                          console.error,
                        );
                      }
                    });
                  }
                  updateMessages((prev) => prev.filter((m) => m.id !== id));
                }}
                onStartEdit={(id, mode) => {
                  setEditingMessageId(id);
                  setEditingMode(mode);
                }}
                onSaveEdit={handleEditMessage}
                onCancelEdit={() => setEditingMessageId(null)}
                onContinue={async () => {
                  const convo = conversations.find(
                    (c) => c.id === activeConversationId,
                  );
                  if (!convo || convo.messages.length === 0) return;

                  const lastMessage = convo.messages[convo.messages.length - 1];
                  if (
                    lastMessage.role !== Role.MODEL ||
                    lastMessage.id !== msg.id
                  )
                    return;

                  setIsLoading(true);
                  setLoadingMessage("Continuing...");
                  stopStream.current = false;

                  const historyForChat = convo.messages;
                  const originalText = lastMessage.parts
                    .map((p) => p.text || "")
                    .join("");

                  try {
                    const isRp = convo && !!convo.characterId;
                    let stream;

                    if (apiMode === "openrouter") {
                      if (!openRouterKey) {
                        throw new Error(
                          "OpenRouter API key is missing. Please set it in Settings.",
                        );
                      }
                      const resolvedHistory =
                        await resolveHistory(historyForChat);
                      const continueParts = [
                        {
                          text: "Continue generating the response from where you left off.",
                        },
                      ];

                      const activeUserMessage = {
                        role: Role.USER,
                        parts: continueParts,
                      };
                      const fullHistory = [
                        ...resolvedHistory,
                        activeUserMessage,
                      ];

                      const sysInstruction = getSystemInstruction(convo);
                      const generationConfig = getFullGenerationConfig(
                        reasoningEnabled,
                        convo,
                      );

                      stream = makeOpenRouterStream(
                        openRouterKey,
                        openRouterModel,
                        openRouterBaseUrl,
                        fullHistory,
                        sysInstruction,
                        generationConfig,
                      );
                    } else {
                      stream = await withApiKeyRotation(async (apiKey) => {
                        const ai = new GoogleGenAI({ apiKey });
                        const resolvedHistory =
                          await resolveHistory(historyForChat);
                        const newChat = ai.chats.create({
                          model: selectedModel,
                          history: resolvedHistory,
                          config: {
                            systemInstruction: getSystemInstruction(convo),
                            ...getFullGenerationConfig(reasoningEnabled, convo),
                            tools: googleSearchEnabled
                              ? [{ googleSearch: {} }]
                              : [],
                          },
                        });
                        const continueParts = [
                          {
                            text: "Continue generating the response from where you left off.",
                          },
                        ];

                        return newChat.sendMessageStream({
                          message: continueParts,
                        });
                      });
                    }

                    let continuedText = "";
                    for await (const chunk of stream) {
                      if (stopStream.current) break;
                      const chunkText = getSafeChunkText(chunk);
                      if (chunkText) {
                        continuedText += chunkText;
                        const scrubbedFullText = applyOutputScrubbing(
                          originalText + continuedText,
                        );

                        updateMessages((prev) =>
                          prev.map((m) => {
                            if (m.id === lastMessage.id) {
                              const mediaParts = m.parts.filter((p) => !p.text);
                              return {
                                ...m,
                                parts: [
                                  ...mediaParts,
                                  { text: scrubbedFullText },
                                ],
                              };
                            }
                            return m;
                          }),
                        );
                      }
                    }
                  } catch (e) {
                    await handleApiError(e);
                  } finally {
                    setIsLoading(false);
                    setLoadingMessage("");
                  }
                }}
                onRegenerate={handleRegenerate}
                onImageClick={(src) =>
                  setFullscreenImage({ src, isModel: msg.role === Role.MODEL })
                }
                onExecute={(m) => {
                  const code = m.parts.map((p) => p.text).join("\n");
                  const htmlMatch = code.match(/```html([\s\S]*?)```/);
                  const cssMatch = code.match(/```css([\s\S]*?)```/);
                  const jsMatch = code.match(
                    /```(?:javascript|js)([\s\S]*?)```/,
                  );
                  if (htmlMatch || cssMatch || jsMatch) {
                    setCodeToExecute({
                      html: htmlMatch ? htmlMatch[1] : "",
                      css: cssMatch ? cssMatch[1] : "",
                      js: jsMatch ? jsMatch[1] : "",
                    });
                  } else {
                    alert("No executable code blocks found in this message.");
                  }
                }}
                onSelectBestResponse={(msgId, respId) => {
                  updateMessages((prev) =>
                    prev.map((m) => {
                      if (m.id === msgId && m.multiResponses) {
                        const selected = m.multiResponses.find(
                          (r) => r.id === respId,
                        );
                        if (selected) {
                          return {
                            ...m,
                            parts: selected.parts,
                            multiResponses: undefined,
                            selectionMade: true,
                          };
                        }
                      }
                      return m;
                    }),
                  );
                }}
                onShowInfo={(msgId) => {
                  const msg = conversations
                    .find((c) => c.id === activeConversationId)
                    ?.messages.find((m) => m.id === msgId);
                  if (msg) setMessageToShowInfo(msg);
                }}
                onSpeak={speak}
              />

              {/* CYCLING BUTTON PANEL FOR TAVERN ALTERNATE GREETINGS */}
              {character && greetings.length > 1 && (
                <div className="flex items-center justify-between sm:justify-start sm:space-x-4 py-2 px-4 bg-purple-950/20 border border-purple-900/30 rounded-xl max-w-sm mx-auto mb-4 animate-fade-in text-xs font-orbitron select-none shadow-md backdrop-blur-sm">
                  <button
                    onClick={() => cycleGreeting("prev")}
                    className="p-1 px-3 hover:text-purple-400 text-gray-400 font-bold tracking-wider hover:bg-purple-900/10 rounded-lg transition-all select-none cursor-pointer border border-transparent hover:border-purple-500/20 active:scale-95"
                  >
                    ◂ PREV
                  </button>
                  <span className="text-gray-300 font-bold text-center flex-grow sm:flex-grow-0">
                    Greeting Variant {currentIndex + 1} / {greetings.length}
                  </span>
                  <button
                    onClick={() => cycleGreeting("next")}
                    className="p-1 px-3 hover:text-purple-400 text-gray-400 font-bold tracking-wider hover:bg-purple-900/10 rounded-lg transition-all select-none cursor-pointer border border-transparent hover:border-purple-500/20 active:scale-95"
                  >
                    NEXT ▸
                  </button>
                </div>
              )}
            </React.Fragment>
          );
        })}
      </>
    );
  }, [
    conversations,
    activeConversationId,
    isLoading,
    editingMessageId,
    editingMode,
    themeSettings.userAvatar,
    themeSettings.modelAvatar,
    selectedModel,
    reasoningEnabled,
    apiKeys,
    currentApiKeyIndex,
    chubCharacters,
    userPersona,
  ]);

  return (
    <div
      className="flex h-screen text-gray-200 font-roboto overflow-hidden relative"
      style={{ backgroundColor: "var(--color-bg-primary)" }}
    >
      {/* Sidebar */}
      <div
        className={`fixed inset-y-0 left-0 transform ${isHistoryOpen ? "translate-x-0" : "-translate-x-full"} md:relative md:translate-x-0 transition-transform duration-300 ease-in-out w-64 md:w-72 flex flex-col border-r z-30`}
        style={{
          backgroundColor: "var(--color-panel)",
          borderColor: "var(--color-border)",
        }}
      >
        <div
          className="p-4 border-b flex justify-between items-center"
          style={{ borderColor: "var(--color-border)" }}
        >
          <h1 className="text-xl font-bold font-orbitron brand-gradient flex items-center gap-2">
            <WormIcon className="text-purple-500" /> WormGPT
          </h1>
          <button onClick={() => setHistoryOpen(false)} className="md:hidden">
            <CloseIcon />
          </button>
        </div>
        <div className="p-3">
          <button
            onClick={() => createNewConversation()}
            className="w-full py-2 px-4 rounded-lg flex items-center justify-center space-x-2 hover:opacity-90 transition-opacity text-white font-bold shadow-lg"
            style={{ backgroundColor: "var(--color-accent-secondary)" }}
          >
            <PlusIcon /> <span>New Chat</span>
          </button>
        </div>
        <div className="px-3 pb-3">
          <button
            onClick={() => setChubModalOpen(true)}
            className="w-full py-2 px-4 rounded-lg flex items-center justify-center space-x-2 hover:bg-purple-900/40 transition-colors text-purple-200 border border-purple-500/30 font-bold bg-purple-950/20 shadow-md"
          >
            <span>🎭 Character Studio</span>
          </button>
        </div>
        <div className="flex-grow overflow-y-auto custom-scrollbar p-2 space-y-1">
          {conversations.map((c) => (
            <div
              key={c.id}
              className={`group flex items-center p-3 rounded-lg cursor-pointer transition-all ${activeConversationId === c.id ? "bg-purple-900/30 border border-purple-500/30" : "hover:bg-gray-800 border border-transparent"}`}
              onClick={() => {
                setActiveConversationId(c.id);
                setHistoryOpen(false);
              }}
            >
              {editingConversationId === c.id ? (
                <input
                  type="text"
                  value={editingName}
                  onClick={(e) => e.stopPropagation()}
                  onChange={(e) => setEditingName(e.target.value)}
                  onBlur={() => {
                    setConversations((prev) =>
                      prev.map((con) =>
                        con.id === c.id ? { ...con, name: editingName } : con,
                      ),
                    );
                    setEditingConversationId(null);
                  }}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      setConversations((prev) =>
                        prev.map((con) =>
                          con.id === c.id ? { ...con, name: editingName } : con,
                        ),
                      );
                      setEditingConversationId(null);
                    }
                  }}
                  autoFocus
                  className="bg-transparent border-b border-purple-500 focus:outline-none w-full text-sm"
                />
              ) : (
                <>
                  {" "}
                  <span className="flex-grow truncate text-sm">
                    {c.name}
                  </span>{" "}
                  <div className="flex space-x-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    {" "}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setEditingConversationId(c.id);
                        setEditingName(c.name);
                      }}
                      className="p-1 hover:text-white text-gray-400"
                    >
                      <EditIcon />
                    </button>{" "}
                    <button
                      onClick={(e) => deleteConversation(c.id, e)}
                      className="p-1 hover:text-red-400 text-gray-400"
                    >
                      <DeleteIcon />
                    </button>{" "}
                  </div>{" "}
                </>
              )}
            </div>
          ))}
        </div>
        <div
          className="p-4 border-t space-y-2"
          style={{ borderColor: "var(--color-border)" }}
        >
          <button
            onClick={handleSaveProject}
            className="w-full flex items-center space-x-2 text-sm text-gray-400 hover:text-white transition-colors"
          >
            {" "}
            <CheckIcon className="w-4 h-4" /> <span>Manual Save</span>{" "}
          </button>
          <button
            onClick={downloadChatHistory}
            className="w-full flex items-center space-x-2 text-sm text-gray-400 hover:text-white transition-colors"
          >
            {" "}
            <DownloadIcon className="w-4 h-4" />{" "}
            <span>Download History (JSON)</span>{" "}
          </button>
          <button
            onClick={() => setSettingsOpen(true)}
            className="w-full flex items-center space-x-2 text-sm text-gray-400 hover:text-white transition-colors"
          >
            {" "}
            <SettingsIcon className="w-4 h-4" />{" "}
            <span>Settings & Theme</span>{" "}
          </button>
        </div>
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col relative overflow-hidden">
        {/* Top Bar */}
        <div
          className="h-16 border-b flex items-center justify-between px-4 z-20 flex-shrink-0"
          style={{
            backgroundColor: "var(--color-panel)",
            borderColor: "var(--color-border)",
          }}
        >
          <div className="flex items-center">
            <button
              onClick={() => setHistoryOpen(true)}
              className="md:hidden mr-4 p-2 rounded-md hover:bg-gray-800"
            >
              <HistoryIcon />
            </button>
            <div className="flex flex-col">
              <span className="font-bold text-sm md:text-base">
                {conversations.find((c) => c.id === activeConversationId)?.name}
              </span>
              <span className="text-xs text-purple-400 flex items-center gap-1">
                {" "}
                <span
                  className={`w-2 h-2 rounded-full ${isLoading || isProcessingFiles ? "bg-yellow-400 animate-pulse" : "bg-green-400"}`}
                ></span>{" "}
                {apiMode === "openrouter"
                  ? openRouterModel || "OpenRouter Proxy"
                  : (ALL_GEMINI_MODELS.find((m) => m.id === selectedModel)?.name || selectedModel)}{" "}
                {isMultiplyMode && apiMode !== "openrouter" && (
                  <span className="text-xs text-blue-400 ml-1">
                    [${selectedMultiplyModels.length} Models]
                  </span>
                )}{" "}
              </span>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <div
              className={`flex items-center gap-1.5 text-[10px] font-bold px-2 py-1 rounded border mr-1 ${isViteConnected ? "text-green-400 border-green-900/50 bg-green-900/10" : "text-red-400 border-red-900/50 bg-red-900/10 animate-pulse"}`}
            >
              <span
                className={`w-1.5 h-1.5 rounded-full ${isViteConnected ? "bg-green-500" : "bg-red-500"}`}
              ></span>
              {isViteConnected ? "VITE OK" : "VITE DISCONNECTED"}
            </div>
            <button
              onClick={() => window.location.reload()}
              className={`p-2 hover:bg-gray-800 rounded-full flex items-center gap-2 px-3 transition-all ${isViteConnected ? "text-yellow-400" : "text-red-500 bg-red-900/20 animate-bounce shadow-[0_0_15px_rgba(239,68,68,0.5)]"}`}
              title="Force Reconnect / Refresh App"
            >
              <RefreshCwIcon
                className={`w-4 h-4 ${!isViteConnected ? "animate-spin" : ""}`}
              />
              <span className="text-xs font-bold hidden sm:inline">
                {isViteConnected ? "RECONNECT" : "RECONNECT NOW"}
              </span>
            </button>
            <button
              onClick={handleSaveProject}
              className="p-2 text-blue-400 hover:bg-gray-800 rounded-full"
              title="Save Project"
            >
              <CheckIcon />
            </button>
            {isLoading && (
              <button
                onClick={() => {
                  stopStream.current = true;
                  setIsLoading(false);
                }}
                className="p-2 bg-red-900/50 text-red-400 rounded-full hover:bg-red-900/80"
                title="Stop Generation"
              >
                {" "}
                <StopIcon />{" "}
              </button>
            )}
          </div>
        </div>

        {/* Chat History */}
        <div
          ref={chatContainerRef}
          className="flex-grow overflow-y-auto p-4 space-y-4 custom-scrollbar scroll-smooth min-h-0"
        >
          {memoizedChatHistory}
          {loadingMessage && (
            <div className="flex justify-center p-2 text-xs text-gray-500 animate-pulse">
              {loadingMessage}
            </div>
          )}
        </div>

        {/* Input Area */}
        <div
          className="p-4 border-t z-20 flex-shrink-0"
          style={{
            backgroundColor: "var(--color-bg-primary)",
            borderColor: "var(--color-border)",
          }}
        >
          <ChatInput
            input={input}
            setInput={setInput}
            attachedFiles={attachedFiles}
            setAttachedFiles={setAttachedFiles}
            onAddFiles={handleAddFiles}
            onSendMessage={handleSendMessage}
            isLoading={isLoading || isProcessingFiles}
            processingMessage={
              isProcessingFiles ? "Processing video..." : undefined
            }
            onOpenImageGenerator={() => setImageGeneratorModalOpen(true)}
            onEditImage={(file) => setImageToEdit(file)}
            onConfigureVideo={(file) => setVideoToConfigure(file)}
            onOpenScraper={() => setScraperModalOpen(true)}
            onOpenDstat={() => setDstatModalOpen(true)}
            onOpenE621Wiki={() => setE621ModalOpen(true)}
            onOpenCodeExecutor={() => setIsExecutorOpen(true)}
            googleSearchEnabled={googleSearchEnabled}
            setGoogleSearchEnabled={setGoogleSearchEnabled}
          />
        </div>
      </div>

      {/* Settings Modal */}
      {isSettingsOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-80 z-50 flex items-center justify-center p-4">
          {" "}
          <div className="bg-[#1C1C1E] rounded-xl w-full max-w-3xl h-[80vh] flex overflow-hidden shadow-2xl border border-gray-700">
            {" "}
            <div className="w-1/3 border-r border-gray-700 bg-[#161618] flex flex-col">
              {" "}
              <div className="p-4 font-bold border-b border-gray-700">
                Settings
              </div>{" "}
              <div className="flex-grow p-2 space-y-1">
                {" "}
                <button
                  onClick={() => setOpenSettingTab("ai")}
                  className={`w-full text-left p-3 rounded-lg text-sm ${openSettingTab === "ai" ? "bg-purple-900/30 text-purple-400" : "hover:bg-gray-800"}`}
                >
                  AI & Model
                </button>{" "}
                <button
                  onClick={() => setOpenSettingTab("system")}
                  className={`w-full text-left p-3 rounded-lg text-sm ${openSettingTab === "system" ? "bg-purple-900/30 text-purple-400" : "hover:bg-gray-800"}`}
                >
                  System
                </button>{" "}
              </div>{" "}
            </div>{" "}
            <div className="w-2/3 p-6 overflow-y-auto custom-scrollbar">
              {" "}
              <div className="flex justify-between items-center mb-6">
                {" "}
                <h2 className="text-xl font-bold">
                  {openSettingTab === "ai"
                    ? "AI & Model"
                    : openSettingTab.charAt(0).toUpperCase() +
                      openSettingTab.slice(1)}
                </h2>{" "}
                <button onClick={() => setSettingsOpen(false)}>
                  <CloseIcon />
                </button>{" "}
              </div>
              {openSettingTab === "ai" && (
                <div className="space-y-6">
                  <div>
                    <div className="border border-purple-500/30 p-4 rounded-lg bg-purple-950/10 mb-4">
                      <label className="block text-sm font-medium mb-2 text-purple-400">
                        API Provider Mode
                      </label>
                      <div className="flex gap-4">
                        <label className="flex items-center gap-2 cursor-pointer text-sm">
                          <input
                            type="radio"
                            name="apiMode"
                            value="gemini"
                            checked={apiMode === "gemini"}
                            onChange={() => setApiMode("gemini")}
                            className="accent-purple-500"
                          />
                          <span>Gemini API (Pool)</span>
                        </label>
                        <label className="flex items-center gap-2 cursor-pointer text-sm">
                          <input
                            type="radio"
                            name="apiMode"
                            value="openrouter"
                            checked={apiMode === "openrouter"}
                            onChange={() => setApiMode("openrouter")}
                            className="accent-purple-500"
                          />
                          <span>OpenRouter Proxy</span>
                        </label>
                      </div>
                    </div>

                    {apiMode === "openrouter" && (
                      <div className="space-y-4 p-4 border border-gray-700 rounded-lg bg-gray-800/40 mb-4">
                        <h3 className="text-sm font-bold text-purple-400">
                          OpenRouter Proxy Config
                        </h3>

                        <div>
                          <label className="block text-xs font-medium text-gray-400 mb-1">
                            OpenRouter API Key
                          </label>
                          <input
                            type="password"
                            value={openRouterKey}
                            onChange={(e) => setOpenRouterKey(e.target.value)}
                            placeholder="sk-or-v1-..."
                            className="w-full bg-gray-900 border border-gray-600 rounded-lg p-2 text-sm focus:border-purple-500 outline-none text-white font-mono"
                          />
                        </div>

                        <div>
                          <label className="block text-xs font-medium text-gray-400 mb-1">
                            Model Name (ID)
                          </label>
                          <input
                            type="text"
                            value={openRouterModel}
                            onChange={(e) => setOpenRouterModel(e.target.value)}
                            placeholder="e.g. meta-llama/llama-3-8b-instruct:free"
                            className="w-full bg-gray-900 border border-gray-600 rounded-lg p-2 text-sm focus:border-purple-500 outline-none text-white font-mono"
                          />
                          <p className="text-[11px] text-gray-500 mt-1">
                            Enter any OpenRouter model identifier (e.g.
                            meta-llama/llama-3-8b-instruct:free).
                          </p>
                        </div>

                        <div>
                          <label className="block text-xs font-medium text-gray-400 mb-1">
                            Proxy Base URL
                          </label>
                          <input
                            type="text"
                            value={openRouterBaseUrl}
                            onChange={(e) =>
                              setOpenRouterBaseUrl(e.target.value)
                            }
                            placeholder="https://openrouter.ai/api/v1"
                            className="w-full bg-gray-900 border border-gray-600 rounded-lg p-2 text-sm focus:border-purple-500 outline-none text-white font-mono"
                          />
                        </div>

                        <div className="pt-2 border-t border-gray-700/50 flex flex-col gap-2">
                          <div className="flex items-center justify-between">
                            <span className="text-xs text-gray-400 font-medium">Validate OpenRouter Config</span>
                            <button
                              type="button"
                              onClick={handleTestOpenRouterKey}
                              disabled={openRouterTestStatus === "testing"}
                              className={`px-3 py-1 text-xs font-bold rounded transition-colors ${
                                openRouterTestStatus === "testing"
                                  ? "bg-gray-700 text-gray-500 cursor-not-allowed"
                                  : "bg-purple-600 hover:bg-purple-700 text-white"
                              }`}
                            >
                              {openRouterTestStatus === "testing" ? "Testing..." : "Test Connection"}
                            </button>
                          </div>
                          {openRouterTestStatus !== "idle" && (
                            <div
                              className={`p-2 rounded text-xs leading-relaxed border ${
                                openRouterTestStatus === "success"
                                  ? "bg-green-950/40 border-green-500/30 text-green-400 font-mono"
                                  : "bg-red-950/40 border-red-500/30 text-red-400 font-mono"
                              }`}
                            >
                              {openRouterTestMessage}
                            </div>
                          )}
                        </div>
                      </div>
                    )}

                    {apiMode === "gemini" && (
                      <div className="mb-4">
                        <label className="block text-sm font-medium mb-2">
                          Primary Model
                        </label>
                        <select
                          value={selectedModel}
                          onChange={(e) => setSelectedModel(e.target.value)}
                          className="w-full bg-gray-800 border border-gray-700 rounded-lg p-2 text-sm focus:border-purple-500 outline-none"
                        >
                          {ALL_GEMINI_MODELS.map((m) => (
                            <option key={m.id} value={m.id}>
                              {m.name}
                            </option>
                          ))}
                        </select>
                      </div>
                    )}
                    {false && (
                      <div>
                        <label className="block text-sm font-medium mb-2">
                          Primary Model
                        </label>
                        <select
                          value={selectedModel}
                          onChange={(e) => setSelectedModel(e.target.value)}
                          className="w-full bg-gray-800 border border-gray-700 rounded-lg p-2 text-sm focus:border-purple-500 outline-none"
                        >
                          {ALL_GEMINI_MODELS.map((m) => (
                            <option key={m.id} value={m.id}>
                              {m.name}
                            </option>
                          ))}
                        </select>
                      </div>
                    )}

                    <div>
                      <div className="flex items-center justify-between">
                        <label
                          htmlFor="reasoning-toggle"
                          className="text-sm font-medium"
                        >
                          Enable Model Reasoning
                        </label>
                        <button
                          id="reasoning-toggle"
                          onClick={() => setReasoningEnabled(!reasoningEnabled)}
                          className={`w-12 h-6 rounded-full transition-colors relative ${reasoningEnabled ? "bg-purple-600" : "bg-gray-600"}`}
                          aria-checked={reasoningEnabled}
                          role="switch"
                        >
                          <span className="sr-only">
                            Enable Model Reasoning
                          </span>
                          <div
                            className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-transform ${reasoningEnabled ? "left-7" : "left-1"}`}
                          ></div>
                        </button>
                      </div>
                      <p className="text-xs text-gray-500 mt-1">
                        Allows the model to "think" before responding, which can
                        improve quality for complex tasks. Disabling it may
                        improve speed. Supported by Gemini 2.5 and 3.0 models.
                      </p>
                    </div>

                    <div>
                      <div className="flex items-center justify-between">
                        <label
                          htmlFor="legacy-streaming-toggle"
                          className="text-sm font-medium"
                        >
                          Legacy Streaming (Buffered Mode)
                        </label>
                        <button
                          id="legacy-streaming-toggle"
                          onClick={() => setLegacyStreamingEnabled(!legacyStreamingEnabled)}
                          className={`w-12 h-6 rounded-full transition-colors relative ${legacyStreamingEnabled ? "bg-purple-600" : "bg-gray-600"}`}
                          aria-checked={legacyStreamingEnabled}
                          role="switch"
                        >
                          <span className="sr-only">
                            Legacy Streaming (Buffered Mode)
                          </span>
                          <div
                            className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-transform ${legacyStreamingEnabled ? "left-7" : "left-1"}`}
                          ></div>
                        </button>
                      </div>
                      <p className="text-xs text-gray-500 mt-1">
                        Completely buffer generation in background and only display the message once it is fully ready. Prevents UI stuttering and ensures perfect, completed output.
                      </p>
                    </div>

                    <div className="border p-4 rounded-lg border-gray-700 bg-gray-800/50">
                      <h3 className="text-lg font-bold text-purple-400 mb-2">
                        API Key Pool
                      </h3>
                      <p className="text-xs text-gray-400 mb-4">
                        Add multiple Gemini API keys to automatically rotate
                        when a rate limit is reached.
                      </p>
                      <div className="flex flex-col gap-2 mb-4">
                        <div className="flex gap-2">
                          <input
                            type="password"
                            value={newApiKeyInput}
                            onChange={(e) => setNewApiKeyInput(e.target.value)}
                            placeholder="Enter new API Key"
                            className="flex-grow bg-gray-900 border border-gray-600 rounded-lg p-2 text-sm focus:border-purple-500 outline-none"
                          />
                          <button
                            type="button"
                            onClick={handleTestInputGeminiKey}
                            disabled={inputKeyTestStatus === "testing" || !newApiKeyInput.trim()}
                            className={`px-3 py-2 rounded-lg text-xs font-bold transition-colors ${
                              inputKeyTestStatus === "testing" || !newApiKeyInput.trim()
                                ? "bg-gray-700 text-gray-500 cursor-not-allowed"
                                : "bg-blue-600 hover:bg-blue-700 text-white"
                            }`}
                          >
                            {inputKeyTestStatus === "testing" ? "Testing..." : "Test Key"}
                          </button>
                          <button
                            type="button"
                            onClick={handleAddApiKey}
                            className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 text-sm font-bold"
                          >
                            Add
                          </button>
                        </div>
                        {inputKeyTestStatus !== "idle" && (
                          <div
                            className={`p-2 rounded text-xs leading-relaxed border ${
                              inputKeyTestStatus === "success"
                                ? "bg-green-950/40 border-green-500/30 text-green-400 font-mono"
                                : "bg-red-950/40 border-red-500/30 text-red-400 font-mono"
                            }`}
                          >
                            {inputKeyTestMessage}
                          </div>
                        )}
                      </div>
                      <div className="space-y-2">
                        {apiKeys.map((key, index) => {
                          const testStatus = geminiKeysTestStatus[key] || "idle";
                          const testMsg = geminiKeysTestMessage[key] || "";
                          return (
                            <div key={index} className="flex flex-col gap-1 bg-gray-800/20 p-1 rounded border border-gray-700/30">
                              <div
                                className={`flex items-center justify-between p-2 rounded-lg transition-colors ${
                                  index === currentApiKeyIndex
                                    ? "bg-green-900/30 border border-green-500/50"
                                    : "bg-gray-800 border border-gray-700"
                                }`}
                              >
                                <div className="flex items-center flex-grow min-w-0">
                                  <span
                                    className={`w-2 h-2 rounded-full mr-3 shrink-0 ${
                                      index === currentApiKeyIndex ? "bg-green-400 animate-pulse" : "bg-gray-600"
                                    }`}
                                  ></span>
                                  <span className="font-mono text-sm text-gray-400 truncate mr-2">{`Key #${index + 1}: ${key.substring(0, 4)}...${key.substring(key.length - 4)}`}</span>
                                </div>
                                <div className="flex items-center gap-2 shrink-0">
                                  <button
                                    type="button"
                                    onClick={() => handleTestPoolGeminiKey(key)}
                                    disabled={testStatus === "testing"}
                                    className={`px-2 py-1 text-xs rounded font-bold transition-colors ${
                                      testStatus === "testing"
                                        ? "bg-gray-700 text-gray-500 cursor-not-allowed"
                                        : "bg-blue-600/80 hover:bg-blue-600 text-white"
                                    }`}
                                  >
                                    {testStatus === "testing" ? "Testing..." : "Test"}
                                  </button>
                                  <button
                                    onClick={() => handleDeleteApiKey(index)}
                                    className="p-1 text-red-500 hover:text-red-400"
                                  >
                                    <DeleteIcon />
                                  </button>
                                </div>
                              </div>
                              {testStatus !== "idle" && (
                                <div
                                  className={`p-1.5 px-3 rounded text-[11px] leading-relaxed border ml-5 font-mono ${
                                    testStatus === "success"
                                      ? "bg-green-950/40 border-green-500/20 text-green-400"
                                      : "bg-red-950/40 border-red-500/20 text-red-400"
                                  }`}
                                >
                                  {testMsg}
                                </div>
                              )}
                            </div>
                          );
                        })}
                        {apiKeys.length === 0 && (
                          <p className="text-center text-xs text-gray-500 py-4">
                            No API keys in pool. The app will use the default
                            key.
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              )}
              {openSettingTab === "system" && (
                <div className="space-y-6">
                  <div className="p-4 bg-red-900/10 border border-red-500/30 rounded-lg">
                    <h3 className="text-red-400 font-bold mb-2">Danger Zone</h3>
                    <p className="text-xs text-gray-400 mb-3">
                      This will permanently delete all conversations and
                      settings from your browser.
                    </p>
                    <button
                      onClick={handleFactoryReset}
                      className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 text-sm font-bold"
                    >
                      Factory Reset (Wipe All Data)
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
      {fullscreenImage && (
        <div
          className="fixed inset-0 z-[60] bg-black bg-opacity-95 flex items-center justify-center p-4"
          onClick={() => setFullscreenImage(null)}
        >
          {" "}
          <img
            src={fullscreenImage.src}
            className="max-w-full max-h-full rounded shadow-2xl"
            alt="Fullscreen preview"
            onClick={(e) => e.stopPropagation()}
          />{" "}
          <button
            className="absolute top-4 right-4 p-2 bg-gray-800 rounded-full text-white"
            onClick={() => setFullscreenImage(null)}
          >
            <CloseIcon />
          </button>{" "}
        </div>
      )}
      {codeToExecute && (
        <CodeExecutionModal
          code={codeToExecute}
          onClose={() => setCodeToExecute(null)}
        />
      )}
      {isExecutorOpen && (
        <CodeExecutorModal
          onClose={() => setIsExecutorOpen(false)}
          onSend={(code) => {
            setInput((prev) => prev + code);
            setIsExecutorOpen(false);
          }}
        />
      )}
      {messageToShowInfo && (
        <MessageInfoModal
          message={messageToShowInfo}
          onClose={() => setMessageToShowInfo(null)}
        />
      )}
      {isImageGeneratorModalOpen && (
        <ImageGeneratorModal
          onClose={() => setImageGeneratorModalOpen(false)}
          onSend={(file) => setAttachedFiles((prev) => [...prev, file])}
          withApiKeyRotation={withApiKeyRotation}
          handleApiError={handleApiError}
          addSystemMessage={addSystemMessage}
        />
      )}
      {isScraperModalOpen && (
        <WebsiteScraperModal
          onClose={() => setScraperModalOpen(false)}
          onSendToAI={(text) => setInput((prev) => prev + "\n" + text)}
        />
      )}
      {isDstatModalOpen && (
        <DstatGraphModal onClose={() => setDstatModalOpen(false)} />
      )}
      {isE621ModalOpen && (
        <E621WikiModal onClose={() => setE621ModalOpen(false)} />
      )}
      {imageToEdit && (
        <ImageEditorModal
          file={imageToEdit}
          onClose={() => setImageToEdit(null)}
          onSave={(editedFile) => {
            setAttachedFiles((prev) =>
              prev.map((f) => (f.id === editedFile.id ? editedFile : f)),
            );
            setImageToEdit(null);
          }}
        />
      )}
      {videoToConfigure && (
        <VideoSettingsModal
          file={videoToConfigure}
          onClose={() => setVideoToConfigure(null)}
          onSave={handleSaveVideoSettings}
        />
      )}
      {isChubModalOpen && (
        <ChubCharactersModal
          onClose={() => setChubModalOpen(false)}
          savedCharacters={chubCharacters}
          onSaveCharacters={handleSaveCharacters}
          onStartRoleplay={startCharacterRoleplay}
          userPersona={userPersona}
          onSaveUserPersona={handleSaveUserPersona}
          userPersonas={userPersonas}
          onSaveUserPersonas={handleSaveUserPersonas}
          conversations={conversations.filter((c) => c.characterId)}
          onSelectConversation={(id) => {
            setActiveConversationId(id);
            setChubModalOpen(false);
          }}
          onDeleteConversation={(id) =>
            deleteConversation(id, { stopPropagation: () => {} } as any)
          }
          activeLorebookIds={activeLorebookIds}
          onSetActiveLorebookIds={setActiveLorebookIds}
          activePresetId={activePresetId || undefined}
          onSetActivePresetId={setActivePresetId}
        />
      )}
    </div>
  );
};
