





export enum Role {
  USER = 'user',
  MODEL = 'model',
}

export interface MessagePart {
    text?: string;
    inlineData?: {
        mimeType: string;
        data?: string; // Made optional to offload to IndexedDB
        dbKey?: number; // Key to reference the data in IndexedDB
    };
}

export interface MultiResponse {
    id: string;
    model: string;
    parts: MessagePart[];
}

export interface MessageContext {
  timestamp: number;
  battery?: {
    level: string;
    charging: boolean;
  };
  network?: {
    type: string;
    downlink: number;
    rtt: number;
  };
  location?: {
    ip: string;
    city: string;
    region: string;
    country: string;
  };
}

// FIX: Add types for grounding metadata
export interface GroundingChunkWeb {
  // FIX: Made uri and title optional to match the type from @google/genai
  uri?: string;
  title?: string;
}

export interface GroundingChunk {
  web?: GroundingChunkWeb;
  // NOTE: Maps grounding is omitted as it is not used in the current implementation
}

export interface Message {
  role: Role;
  parts: MessagePart[];
  id: string; 
  multiResponses?: MultiResponse[];
  selectionMade?: boolean;
  context?: MessageContext;
  // FIX: Add grounding chunks to message type
  groundingChunks?: GroundingChunk[];
}

export interface ChubCharacter {
    id: string;
    name: string;
    avatar?: string; // Base64 data URI of the avatar
    tagline?: string;
    description: string;
    personality: string;
    scenario: string;
    first_mes: string;
    mes_example?: string;
    system_prompt?: string;
    creator_notes?: string;
    alternate_greetings?: string[];
    post_history_instructions?: string;
    character_note?: string;
    character_note_depth?: number;
}

export interface LorebookEntry {
    id: string;
    keys: string[];
    content: string;
    secondary_keys?: string[];
    comment?: string;
    enabled: boolean;
    constant?: boolean;
    priority?: number;
}

export interface Lorebook {
    id: string;
    name: string;
    avatar?: string;
    tagline?: string;
    creator_notes?: string;
    type: 'public' | 'private' | 'unlisted';
    rating: 'SFW' | 'NSFW';
    anonymous: boolean;
    tags: string[];
    character_book_title?: string;
    description?: string;
    scan_depth: number;
    token_budget: number;
    recursive_scanning: boolean;
    entries: LorebookEntry[];
}

export interface Preset {
    id: string;
    name: string;
    api: string;
    model: string;
    pre_history_instructions: string;
    post_history_instructions: string;
    impersonation_prompt: string;
    include_names: boolean;
    ban_emojis: boolean;
    text_streaming: boolean;
    v2_spec: boolean;
    use_lorebooks: boolean;
    use_auto_summarization: boolean;
    assistant_prefill: string;
    prompt_note: string;
    prompt_note_depth: number;
    temperature: number;
    repetition_penalty: number;
    frequency_penalty: number;
    presence_penalty: number;
    top_p: number;
    top_k: number;
    min_length: number;
    trim_incomplete_sentences: boolean;
    legacy_streaming: boolean;
    stopping_strings: string[];
    max_new_tokens: number;
    context_size: number;
    include_base_prefix: boolean;
    lorebook_scan_depth: number;
    lorebook_token_budget: number;
    lorebook_recursive_scanning: boolean;
    match_whole_words: boolean;
}

export interface UserPersona {
    id?: string;
    name: string;
    description: string;
    avatar?: string; // Base64 data URI
    isDefault?: boolean;
}

export interface Conversation {
    id: string;
    name: string;
    messages: Message[];
    isLocked?: boolean;
    characterId?: string;
    characterSystemPrompt?: string;
    characterAvatar?: string;
    selectedGreetingIndex?: number;
    activePresetId?: string;
    activeLorebookIds?: string[];
}

// FIX: Add VideoSettings interface to resolve errors in VideoSettingsModal and YouTubeSettingsModal.
export interface VideoSettings {
    startTime?: string;
    endTime?: string;
    fps?: string;
}

export interface AttachedFile {
    id: string;
    file: File;
    name: string;
    type: 'image' | 'text' | 'pdf' | 'video' | 'audio' | 'other';
    preview?: string;
    content?: string;
    youtubeUrl?: string;
    videoSettings?: VideoSettings;
    // Restoring video processing fields
    processingStatus?: 'pending' | 'processing' | 'done' | 'error';
    processingProgress?: number;
    errorMessage?: string;
    processedData?: MessagePart[];
}

export interface CustomFont {
    name: string;
    url: string;
}

export interface ThemeSettings {
  '--color-bg-primary': string;
  '--color-panel': string;
  '--color-text-primary': string;
  '--color-text-secondary': string;
  '--color-accent-primary': string;
  '--color-accent-secondary': string;
  '--color-bubble-user': string;
  '--color-bubble-model': string;
  '--color-border': string;
  '--color-scrollbar-thumb': string;
  '--color-scrollbar-track': string;
  '--bg-image-url': string;
  fontFamily: string;
  customFonts: CustomFont[];
  userAvatar: string | null;
  modelAvatar: string | null;
}