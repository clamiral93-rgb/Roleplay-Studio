export const GEMINI_MODELS =[
    { id: 'gemini-3.5-flash', name: 'Gemini 3.5 Flash', provider: 'Google DeepMind' },
    { id: 'gemini-3-flash-preview', name: 'Gemini 3.0 Flash', provider: 'Google DeepMind' },
    { id: 'gemini-3.1-flash-lite', name: 'Gemini 3.1 Flash Lite', provider: 'Google DeepMind' },
    { id: 'gemini-3.1-pro-preview', name: 'Gemini 3.1 Pro Preview', provider: 'Google DeepMind' },
    { id: 'gemini-flash-lite-latest', name: 'Gemini Flash-Lite Latest', provider: 'Google DeepMind' },
    { id: 'gemini-flash-latest', name: 'Gemini Flash Latest', provider: 'Google DeepMind' },
    { id: 'gemini-pro-latest', name: 'Gemini Pro Latest', provider: 'Google DeepMind' },
    { id: 'gemma-4-26b-a4b-it', name: 'Gemma 4 26B A4B IT', provider: 'Google DeepMind' },
    { id: 'gemma-4-31b-it', name: 'Gemma 4 31B IT', provider: 'Google DeepMind' },
];
