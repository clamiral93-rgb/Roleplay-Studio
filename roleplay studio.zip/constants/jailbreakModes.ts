import { FICTIONAL_TEMPLATE } from './fictionalTemplate';

export const JAILBREAK_MODES = {
    'WormGPT': FICTIONAL_TEMPLATE
};
