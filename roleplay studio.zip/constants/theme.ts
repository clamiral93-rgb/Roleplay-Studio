import { ThemeSettings } from '../types';

export const DEFAULT_THEME: ThemeSettings = {
  '--color-bg-primary': '#131314',
  '--color-panel': '#1C1C1E',
  '--color-text-primary': '#E3E3E3',
  '--color-text-secondary': '#A3A3A3',
  '--color-accent-primary': '#A855F7',
  '--color-accent-secondary': '#7E22CE',
  '--color-bubble-user': '#2D2D30',
  '--color-bubble-model': '#3C3D40',
  '--color-border': '#2D2E30',
  '--color-scrollbar-thumb': '#4B5563',
  '--color-scrollbar-track': '#1F2937',
  '--bg-image-url': 'none',
  fontFamily: 'Roboto, sans-serif',
  customFonts: [],
  userAvatar: null,
  modelAvatar: null,
};
